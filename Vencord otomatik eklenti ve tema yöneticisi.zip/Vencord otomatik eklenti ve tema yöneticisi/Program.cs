using System.Diagnostics;
using VencordManager.Endpoints;
using VencordManager.Middlewares;
using VencordManager.Services;

// ==============================================================================
// Proje: Vencord AutoManager
// Geliştirici: İbrahim Etem Boz
// GitHub: https://github.com/ibrahimetemboz
// Lisans: MIT
// ==============================================================================

var builder = WebApplication.CreateBuilder(args);

// Sunucunun çalışacağı sabit yerel adres (http://127.0.0.1:5055)
builder.WebHost.UseUrls("http://127.0.0.1:5055");

// ------------------------------------------------------------------------------
// 1. DEPENDENCY INJECTION
// ------------------------------------------------------------------------------
builder.Services.AddSingleton<VencordConfigService>();
builder.Services.AddSingleton<DiscordProcessService>();
builder.Services.AddSingleton<PresetService>();
builder.Services.AddSingleton<ThemeService>();

var app = builder.Build();

// ------------------------------------------------------------------------------
// 2. MIDDLEWARE KATMANLARI
// ------------------------------------------------------------------------------
app.UseMiddleware<GlobalExceptionMiddleware>();

app.UseDefaultFiles(); // index.html'i varsayılan sayfa yapar
app.UseStaticFiles();  // wwwroot altındaki css, js dosyalarını sunar

// ------------------------------------------------------------------------------
// 3. API ROTALARI
// ------------------------------------------------------------------------------
app.MapVencordEndpoints();

// ------------------------------------------------------------------------------
// 4. UYGULAMAYI BAŞLAT VE TARAYICIDA AÇ
// ------------------------------------------------------------------------------
app.Lifetime.ApplicationStarted.Register(() =>
{
    string url = "http://127.0.0.1:5055";
    Console.ForegroundColor = ConsoleColor.Cyan;
    Console.WriteLine("===============================================================");
    Console.WriteLine("  Vencord Otomatik Eklenti & Profil Yöneticisi");
    Console.WriteLine("  Geliştirici: İbrahim Etem Boz | https://github.com/ibrahimetemboz");
    Console.WriteLine($"  Web Paneli: {url}");
    Console.WriteLine("  Durdurmak için 'Ctrl + C' tuşlarına basabilirsiniz.");
    Console.WriteLine("===============================================================");
    Console.ResetColor();

    try
    {
        Process.Start(new ProcessStartInfo(url) { UseShellExecute = true });
    }
    catch { /* Tarayıcı açılamazsa sessizce devam et */ }
});

app.Run();
