# ⚡ Vencord AutoManager - Eklenti, Tema & QuickCSS Yöneticisi

Discord için popüler istemci modifikasyonu **Vencord** ayarlarını (`settings.json`), eklentilerini (plugins), temalarını ve QuickCSS kurallarını tek bir tıkla otomatik olarak yapılandırmanızı sağlayan modern, hibrit bir masaüstü kontrol panelidir.

![.NET 8](https://img.shields.io/badge/.NET-8.0-purple?style=for-the-badge&logo=dotnet)
![C#](https://img.shields.io/badge/C%23-239120?style=for-the-badge&logo=csharp&logoColor=white)
![HTML5](https://img.shields.io/badge/HTML5-E34F26?style=for-the-badge&logo=html5&logoColor=white)
![CSS3](https://img.shields.io/badge/CSS3-1572B6?style=for-the-badge&logo=css3&logoColor=white)
![JavaScript](https://img.shields.io/badge/JavaScript-F7DF1E?style=for-the-badge&logo=javascript&logoColor=black)
![License](https://img.shields.io/badge/License-MIT-green?style=for-the-badge)
![Developer](https://img.shields.io/badge/Developer-%C4%B0brahim%20Etem%20Boz-blue?style=for-the-badge)

---

## ✨ Öne Çıkan Özellikler

- ⚡ **Hazır Profil Paketleri (1-Click Presets):**
  - **⚡ Tam Teşekküllü (Güç Paketi):** FakeNitro, Spotify Controls, VolumeBooster, Translate, BetterSettings gibi tüm popüler eklentileri tek tıkla açar.
  - **🎮 Oyun & Performans:** Discord'un CPU ve RAM tüketimini azaltır; görsel ağırlıkları kapatıp yalnızca ses ve müzik araçlarını aktif tutar.
  - **💻 Yazılımcı & Kodlama:** Shiki renkli kod blokları, DevTools, URL izleme temizliği ve izin denetleyicileri.
  - **🛡️ Gizlilik & Güvenlik:** Takip parametrelerini temizler, 'yazıyor...' bildirimini gizler.
  - **🌱 Sade & Hafif (Minimalist):** Yalnızca temel ses ve bildirim konfor eklentilerini aktif eder.
  - **⭐ Özel Profil Kaydetme:** Kendi plugin listenizi özel bir profil olarak kaydedip dilediğiniz zaman tek tıkla geri yükleyebilirsiniz.
- 🎨 **Discord Temaları & QuickCSS Canlı Enjektörü:**
  - Discord'un klasik karanlık temasından sıkılanlar için popüler topluluk temalarını (ClearVision, Midnight, Catppuccin Mocha, AMOLED vb.) tek tıkla uygulama veya kaldırma.
  - Özel CSS kurallarını doğrudan Vencord'a enjekte eden yerleşik QuickCSS editörü ve hazır CSS kod parçacıkları (Round Avatars, Message Hover vb.).
- 🔄 **Profil İçe / Dışa Aktarma (JSON):**
  - Ayarlarınızı `.json` formatında dışa aktarabilir (Export) veya arkadaşlarınızın hazırladığı hazır profilleri içe aktarabilirsiniz (Import).
- 🛡️ **Güvenli Dosya İşlemleri (Defensive & Atomic Write):**
  - Vencord'un `settings.json` dosyasını atomik olarak günceller; diğer kullanıcı verilerini bozmaz ve her kayıttan önce otomatik `.backup` yedeği alır.
- 🚀 **Discord Süreç Yönetimi:**
  - Arka plandaki Discord sürecini (PID) otomatik tespit eder; değişiklikleri uyguladıktan sonra tek tıkla Discord'u sorunsuz şekilde kapatıp yeniden başlatır.

---

## 🏗️ Mimari Yapı (Hibrit Model)

```text
[ Modern Web Arayüzü (HTML5 + CSS3 + Vanilla ES6+ JS) ]
                          ↕ (HTTP REST API / JSON)
[ C# .NET 8 ASP.NET Core Minimal API (Hafif Kestrel Sunucusu) ]
       ├── VencordConfigService  --> %APPDATA%\Vencord\settings\settings.json
       ├── DiscordProcessService --> Process.GetProcessesByName("Discord")
       ├── PresetService         --> Hazır ve Özel Profiller (JSON)
       └── ThemeService          --> Topluluk Temaları & QuickCSS
```

1. **Frontend (İstemci):** 
   - Harici ağır kütüphaneler (React, Vue, Node.js) olmadan saf **HTML5, CSS3 ve modern Vanilla JavaScript**.
   - Discord'un koyu tema renk paleti (`#5865F2` Blurple, `#1e1f22`, `#2b2d31`), cam efekti (*glassmorphism*) ve akıcı mikro-animasyonlar.
   - Anlık arama (canlı filtreleme), kategori hapları, canlı durum göstergeleri ve yüzen alt kontrol barı.

2. **Backend (Sunucu & Mantık):**
   - **C# .NET 8 Minimal API** (Hafif ve hızlı yerel Kestrel HTTP sunucusu).
   - `settings.json` dosyasını `System.Text.Json.Nodes.JsonNode` ile okuyup diğer alanları bozmadan güvenli güncelleme.
   - Windows süreç yönetimi (`System.Diagnostics.Process`) ile Discord sürecini yönetme.

---

## 🚀 Kurulum & Çalıştırma

### Gereksinimler
- Windows 10 / 11
- [.NET 8.0 SDK](https://dotnet.microsoft.com/download/dotnet/8.0) (veya Runtime)

### 1. Pratik Başlatıcı (Önerilen)
Projeyi indirdikten sonra kök dizindeki **`run.bat`** dosyasına çift tıklayın.

### 2. Terminal / Konsol ile
```bash
# Projeyi klonlayın
git clone https://github.com/ibrahimetemboz/vencord-automanager.git

# Proje dizinine gidin
cd vencord-automanager

# Uygulamayı çalıştırın
dotnet run
```

Uygulama başladığında varsayılan tarayıcınızda otomatik olarak **`http://127.0.0.1:5055`** adresinde açılacaktır.

---

## 📁 Proje Dizin Yapısı

```text
├── Endpoints/
│   └── VencordEndpoints.cs      # Minimal API rota tanımlamaları
├── Middlewares/
│   └── GlobalExceptionMiddleware.cs  # Merkezi hata yakalama katmanı
├── Models/
│   └── PluginModels.cs          # İmmutable C# record veri modelleri
├── Services/
│   ├── VencordConfigService.cs  # Vencord settings.json okuma/yazma/yedekleme
│   ├── DiscordProcessService.cs # Discord sürecini bulma, kapatma ve başlatma
│   ├── PresetService.cs         # Hazır paketler ve özel preset yönetimi
│   └── ThemeService.cs          # CSS tema tanımları ve QuickCSS yönetimi
├── wwwroot/                     # Web Arayüzü
│   ├── css/
│   │   └── style.css            # Özel Glassmorphic Discord temalı stil dosyası
│   ├── js/
│   │   └── app.js               # Reaktif state yönetimi ve REST API katmanı
│   └── index.html               # Tek sayfa modern kontrol paneli
├── Program.cs                   # Kestrel sunucu yapılandırması & DI
├── run.bat                      # Tek tıkla derleme ve başlatma betiği
├── LICENSE                      # MIT Lisansı
└── README.md                    # Proje dokümantasyonu
```

---

## 👨‍💻 Geliştirici (Developer)

Proje **İbrahim Etem Boz** tarafından geliştirilmiştir.

- **GitHub:** [@ibrahimetemboz](https://github.com/ibrahimetemboz)
- **Lisans:** [MIT License](LICENSE)
