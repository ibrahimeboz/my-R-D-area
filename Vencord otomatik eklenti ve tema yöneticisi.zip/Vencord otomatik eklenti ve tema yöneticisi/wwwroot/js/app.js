/**
 * ==============================================================================
 * Vencord AutoManager - Modern Reactive Web Dashboard
 * Geliştirici (Developer): İbrahim Etem Boz
 * GitHub: https://github.com/ibrahimetemboz
 * Lisans: MIT
 * ==============================================================================
 */

// Developer Console Badge
console.log(
    '%c⚡ Vencord AutoManager %c Developed by İbrahim Etem Boz %c https://github.com/ibrahimetemboz ',
    'background: #5865F2; color: #fff; padding: 4px 8px; border-radius: 4px 0 0 4px; font-weight: bold;',
    'background: #2b2d31; color: #dbdee1; padding: 4px 8px; font-weight: 600;',
    'background: #1e1f22; color: #949ba4; padding: 4px 8px; border-radius: 0 4px 4px 0;'
);

// Application State
const AppState = {
    plugins: [],
    presets: [],
    themes: [],
    currentStates: {},
    initialStates: {},
    currentPluginOptions: {},   // { PluginId: { OptionKey: value } }
    activeCategory: 'ALL',
    searchQuery: '',
    selectedPresetId: null,
    editingPluginForOptions: null
};

// DOM Elements
const DOM = {
    // Tabs
    tabPluginsBtn: document.getElementById('tabPluginsBtn'),
    tabThemesBtn: document.getElementById('tabThemesBtn'),
    tabPlugins: document.getElementById('tabPlugins'),
    tabThemes: document.getElementById('tabThemes'),

    // Header & Status
    vencordStatusPill: document.getElementById('vencordStatusPill'),
    vencordStatusText: document.getElementById('vencordStatusText'),
    discordStatusPill: document.getElementById('discordStatusPill'),
    discordStatusText: document.getElementById('discordStatusText'),
    btnRestartDiscord: document.getElementById('btnRestartDiscord'),

    // Presets & Import/Export
    presetsGrid: document.getElementById('presetsGrid'),
    btnExportProfile: document.getElementById('btnExportProfile'),
    btnImportProfile: document.getElementById('btnImportProfile'),
    fileInputImport: document.getElementById('fileInputImport'),
    btnOpenSavePresetModal: document.getElementById('btnOpenSavePresetModal'),

    // Search & Plugins
    searchInput: document.getElementById('searchInput'),
    searchClear: document.getElementById('searchClear'),
    categoryPills: document.getElementById('categoryPills'),
    pluginGrid: document.getElementById('pluginGrid'),
    visiblePluginCount: document.getElementById('visiblePluginCount'),
    totalPluginCount: document.getElementById('totalPluginCount'),
    activePluginCount: document.getElementById('activePluginCount'),
    countAll: document.getElementById('countAll'),
    countActive: document.getElementById('countActive'),
    btnEnableAllFiltered: document.getElementById('btnEnableAllFiltered'),
    btnDisableAllFiltered: document.getElementById('btnDisableAllFiltered'),

    // Themes & QuickCSS
    themesGrid: document.getElementById('themesGrid'),
    btnResetTheme: document.getElementById('btnResetTheme'),
    quickCssTextarea: document.getElementById('quickCssTextarea'),
    btnSaveQuickCss: document.getElementById('btnSaveQuickCss'),

    // Bottom Dock
    pendingChangesCount: document.getElementById('pendingChangesCount'),
    chkAutoRestart: document.getElementById('chkAutoRestart'),
    btnApplyChanges: document.getElementById('btnApplyChanges'),
    btnRestoreBackup: document.getElementById('btnRestoreBackup'),

    // Modals
    savePresetModal: document.getElementById('savePresetModal'),
    btnCloseSavePresetModal: document.getElementById('btnCloseSavePresetModal'),
    btnCancelPresetModal: document.getElementById('btnCancelPresetModal'),
    btnConfirmSavePreset: document.getElementById('btnConfirmSavePreset'),
    presetNameInput: document.getElementById('presetNameInput'),
    presetDescInput: document.getElementById('presetDescInput'),

    subSettingsModal: document.getElementById('subSettingsModal'),
    subSettingsModalTitle: document.getElementById('subSettingsModalTitle'),
    subSettingsModalBody: document.getElementById('subSettingsModalBody'),
    btnCloseSubSettingsModal: document.getElementById('btnCloseSubSettingsModal'),
    btnSaveSubSettings: document.getElementById('btnSaveSubSettings'),

    toastContainer: document.getElementById('toastContainer')
};

// ==============================================================================
// 1. API COMMUNICATION LAYER
// ==============================================================================

async function apiGetStatus() {
    try {
        const res = await fetch('/api/status');
        const json = await res.json();
        if (json.success && json.data) {
            updateSystemStatusUI(json.data);
        }
    } catch (err) {
        console.error('Error fetching system status:', err);
    }
}

async function apiGetPlugins() {
    try {
        const res = await fetch('/api/plugins');
        const json = await res.json();
        if (json.success && json.data) {
            AppState.plugins = json.data;
            
            AppState.plugins.forEach(p => {
                AppState.initialStates[p.id] = p.enabled;
                AppState.currentStates[p.id] = p.enabled;
                if (p.currentOptions) {
                    AppState.currentPluginOptions[p.id] = { ...p.currentOptions };
                }
            });

            renderCategoryPills();
            renderPlugins();
            updateStatsAndPending();
        }
    } catch (err) {
        console.error('Error fetching plugins:', err);
        showToast('Failed to load plugins from server.', 'error');
    }
}

async function apiGetPresets() {
    try {
        const res = await fetch('/api/presets');
        const json = await res.json();
        if (json.success && json.data) {
            AppState.presets = json.data;
            renderPresets();
        }
    } catch (err) {
        console.error('Error fetching presets:', err);
    }
}

async function apiGetThemes() {
    try {
        const res = await fetch('/api/themes');
        const json = await res.json();
        if (json.success && json.data) {
            AppState.themes = json.data;
            renderThemes();
        }
    } catch (err) {
        console.error('Error fetching themes:', err);
    }
}

async function apiApplyTheme(themeUrl) {
    const restart = DOM.chkAutoRestart.checked;
    try {
        const res = await fetch('/api/themes/apply', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ themeUrl: themeUrl, restartDiscordAfterApply: restart })
        });
        const json = await res.json();
        showToast(json.message, json.success ? 'success' : 'error');
        await apiGetThemes();
        apiGetStatus();
    } catch (err) {
        showToast('Failed to apply theme.', 'error');
    }
}

async function apiGetQuickCss() {
    try {
        const res = await fetch('/api/quickcss');
        const json = await res.json();
        if (json.success) {
            DOM.quickCssTextarea.value = json.data || '';
        }
    } catch (err) {
        console.error('Error fetching QuickCSS:', err);
    }
}

async function apiSaveQuickCss() {
    const css = DOM.quickCssTextarea.value;
    try {
        const res = await fetch('/api/quickcss', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ cssContent: css })
        });
        const json = await res.json();
        showToast(json.message, json.success ? 'success' : 'error');
    } catch (err) {
        showToast('Failed to save QuickCSS.', 'error');
    }
}

async function apiApplyChanges() {
    const restart = DOM.chkAutoRestart.checked;
    setButtonLoading(DOM.btnApplyChanges, true, 'Applying...');

    try {
        const payload = {
            plugins: AppState.currentStates,
            pluginOptions: AppState.currentPluginOptions,
            restartDiscordAfterApply: restart
        };

        const res = await fetch('/api/apply', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });

        const json = await res.json();
        if (json.success) {
            showToast(json.message, 'success');
            Object.keys(AppState.currentStates).forEach(id => {
                AppState.initialStates[id] = AppState.currentStates[id];
            });
            updateStatsAndPending();
            apiGetStatus();
        } else {
            showToast(json.message, 'error');
        }
    } catch (err) {
        showToast('Failed to save settings.', 'error');
    } finally {
        setButtonLoading(DOM.btnApplyChanges, false, 'Apply to Discord');
    }
}

async function apiRestartDiscord() {
    setButtonLoading(DOM.btnRestartDiscord, true, 'Restarting...');
    try {
        const res = await fetch('/api/restart-discord', { method: 'POST' });
        const json = await res.json();
        showToast(json.message, json.success ? 'success' : 'info');
        setTimeout(apiGetStatus, 1500);
    } catch (err) {
        showToast('Failed to restart Discord.', 'error');
    } finally {
        setButtonLoading(DOM.btnRestartDiscord, false, 'Restart Discord');
    }
}

async function apiRestoreBackup() {
    if (!confirm('Are you sure you want to restore settings from the previous automatic backup?')) return;
    try {
        const res = await fetch('/api/restore-backup', { method: 'POST' });
        const json = await res.json();
        if (json.success) {
            showToast(json.message, 'success');
            await apiGetPlugins();
        } else {
            showToast(json.message, 'error');
        }
    } catch (err) {
        showToast('Backup restoration failed.', 'error');
    }
}

// ==============================================================================
// 2. PROFILE EXPORT & IMPORT (JSON)
// ==============================================================================

function exportCurrentProfile() {
    const activePluginsCount = Object.values(AppState.currentStates).filter(Boolean).length;
    const profileData = {
        name: "Custom Profile (" + new Date().toLocaleDateString('en-US') + ")",
        description: `Configuration with ${activePluginsCount} active plugins`,
        exportedAt: new Date().toISOString(),
        pluginStates: AppState.currentStates,
        pluginOptions: AppState.currentPluginOptions
    };

    const jsonStr = JSON.stringify(profileData, null, 2);
    const blob = new Blob([jsonStr], { type: "application/json" });
    const url = URL.createObjectURL(blob);

    const a = document.createElement('a');
    a.href = url;
    a.download = `vencord-profile-${Date.now()}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    showToast('Profile exported as .json successfully!', 'success');
}

function handleProfileFileImport(file) {
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async (e) => {
        try {
            const importedData = JSON.parse(e.target.result);
            if (!importedData.pluginStates) {
                showToast('Invalid profile file: missing pluginStates.', 'error');
                return;
            }

            const res = await fetch('/api/presets/import', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    id: 'imported_' + Date.now(),
                    name: importedData.name || file.name.replace('.json', ''),
                    description: importedData.description || 'Imported Profile',
                    icon: 'star',
                    color: '#FEE75C',
                    pluginStates: importedData.pluginStates
                })
            });

            const json = await res.json();
            if (json.success) {
                showToast(json.message, 'success');
                applyPresetToState({
                    id: 'imported_temp',
                    name: importedData.name,
                    pluginStates: importedData.pluginStates
                });
                await apiGetPresets();
            } else {
                showToast(json.message, 'error');
            }
        } catch (err) {
            showToast('Could not parse JSON profile file.', 'error');
        }
    };
    reader.readAsText(file);
}

// ==============================================================================
// 4. UI RENDERING
// ==============================================================================

function updateSystemStatusUI(status) {
    if (status.isVencordInstalled) {
        DOM.vencordStatusPill.className = 'status-pill online';
        DOM.vencordStatusText.textContent = `Vencord Ready (${status.enabledPlugins} active)`;
    } else {
        DOM.vencordStatusPill.className = 'status-pill offline';
        DOM.vencordStatusText.textContent = 'Vencord Not Found';
    }

    if (status.isDiscordRunning) {
        DOM.discordStatusPill.className = 'status-pill online';
        DOM.discordStatusText.textContent = `Discord Running (${status.discordProcessCount} procs)`;
    } else {
        DOM.discordStatusPill.className = 'status-pill';
        DOM.discordStatusText.textContent = 'Discord Closed';
    }
}

function renderPresets() {
    DOM.presetsGrid.innerHTML = '';
    AppState.presets.forEach(preset => {
        const card = document.createElement('div');
        card.className = `preset-card ${AppState.selectedPresetId === preset.id ? 'active' : ''}`;
        card.dataset.presetId = preset.id;

        const activeInPreset = Object.values(preset.pluginStates || {}).filter(Boolean).length;

        card.innerHTML = `
            <div>
                <div class="preset-card-top">
                    <div class="preset-icon-box" style="color: ${preset.color}">
                        ${getPresetEmoji(preset.icon)}
                    </div>
                    <div class="preset-name">${preset.name}</div>
                </div>
                <p class="preset-desc">${preset.description}</p>
            </div>
            <div class="preset-footer">
                <span class="preset-plugin-count">${activeInPreset} Plugins</span>
                <button class="btn-select-preset">Select &rarr;</button>
            </div>
        `;

        card.addEventListener('click', () => applyPresetToState(preset));
        DOM.presetsGrid.appendChild(card);
    });
}

function getPresetEmoji(icon) {
    switch (icon) {
        case 'bolt': return '⚡';
        case 'gamepad': return '🎮';
        case 'code': return '💻';
        case 'shield': return '🛡️';
        case 'leaf': return '🌱';
        case 'star': return '⭐';
        default: return '📦';
    }
}

function applyPresetToState(preset) {
    AppState.selectedPresetId = preset.id;
    if (preset.pluginStates) {
        Object.entries(preset.pluginStates).forEach(([pluginId, isEnabled]) => {
            AppState.currentStates[pluginId] = isEnabled;
        });
    }

    renderPresets();
    renderPlugins();
    updateStatsAndPending();
    showToast(`'${preset.name}' selected! Click 'Apply to Discord' to write changes.`, 'info');
}

function renderCategoryPills() {
    const categories = ['ALL', 'ACTIVE'];
    const uniqueCats = [...new Set(AppState.plugins.map(p => p.category))];
    categories.push(...uniqueCats);

    DOM.categoryPills.innerHTML = '';
    categories.forEach(cat => {
        const btn = document.createElement('button');
        btn.className = `pill-btn ${AppState.activeCategory === cat ? 'active' : ''}`;
        btn.dataset.category = cat;

        let label = cat;
        if (cat === 'ALL') label = 'All';
        else if (cat === 'ACTIVE') label = 'Active';

        btn.textContent = label;
        btn.addEventListener('click', () => {
            AppState.activeCategory = cat;
            document.querySelectorAll('.pill-btn').forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            renderPlugins();
        });

        DOM.categoryPills.appendChild(btn);
    });
}

function renderPlugins() {
    const query = AppState.searchQuery.toLowerCase().trim();
    const activeCat = AppState.activeCategory;

    const filtered = AppState.plugins.filter(p => {
        const isCurrentEnabled = AppState.currentStates[p.id];
        if (activeCat === 'ACTIVE' && !isCurrentEnabled) return false;
        if (activeCat !== 'ALL' && activeCat !== 'ACTIVE' && p.category !== activeCat) return false;

        if (query) {
            const inName = p.name.toLowerCase().includes(query) || p.id.toLowerCase().includes(query);
            const inDesc = p.description.toLowerCase().includes(query);
            const inTags = p.tags && p.tags.some(t => t.toLowerCase().includes(query));
            if (!inName && !inDesc && !inTags) return false;
        }

        return true;
    });

    DOM.pluginGrid.innerHTML = '';
    DOM.visiblePluginCount.textContent = filtered.length;

    if (filtered.length === 0) {
        DOM.pluginGrid.innerHTML = `
            <div style="grid-column: 1 / -1; text-align: center; padding: 48px; color: var(--text-muted);">
                <p style="font-size: 1.1rem; margin-bottom: 8px;">No plugins found matching your criteria.</p>
                <button class="btn btn-secondary btn-sm" onclick="clearSearchFilter()">Reset Filters</button>
            </div>
        `;
        return;
    }

    filtered.forEach(plugin => {
        const isEnabled = !!AppState.currentStates[plugin.id];
        const card = document.createElement('div');
        card.className = `plugin-card ${isEnabled ? 'enabled' : ''}`;
        card.id = `card-${plugin.id}`;

        const tagsHtml = (plugin.tags || []).map(t => `<span class="tag">#${t}</span>`).join('');
        const hasOptions = plugin.availableOptions && plugin.availableOptions.length > 0;

        card.innerHTML = `
            <div>
                <div class="plugin-card-header">
                    <div class="plugin-info-left">
                        <span class="plugin-category-badge">${plugin.category}</span>
                        <h4 class="plugin-title">
                            ${plugin.name}
                            ${plugin.isEssential ? '<span class="badge-essential">Recommended</span>' : ''}
                        </h4>
                    </div>
                    <div class="plugin-card-controls">
                        ${hasOptions ? `<button class="btn-gear" data-plugin-id="${plugin.id}" title="Customize Settings">⚙️</button>` : ''}
                        <label class="switch" title="${isEnabled ? 'Disable' : 'Enable'}">
                            <input type="checkbox" ${isEnabled ? 'checked' : ''} data-plugin-id="${plugin.id}">
                            <span class="slider"></span>
                        </label>
                    </div>
                </div>
                <p class="plugin-desc">${plugin.description}</p>
            </div>
            <div class="plugin-tags">
                ${tagsHtml}
            </div>
        `;

        const checkbox = card.querySelector('input[type="checkbox"]');
        checkbox.addEventListener('change', (e) => {
            const newState = e.target.checked;
            AppState.currentStates[plugin.id] = newState;
            card.classList.toggle('enabled', newState);
            AppState.selectedPresetId = null;
            updateStatsAndPending();
        });

        if (hasOptions) {
            const gearBtn = card.querySelector('.btn-gear');
            gearBtn.addEventListener('click', () => openSubSettingsModal(plugin));
        }

        DOM.pluginGrid.appendChild(card);
    });
}

function renderThemes() {
    DOM.themesGrid.innerHTML = '';
    AppState.themes.forEach(theme => {
        const card = document.createElement('div');
        card.className = `theme-card ${theme.isApplied ? 'applied' : ''}`;

        card.innerHTML = `
            <div class="theme-color-strip" style="background: ${theme.accentColor}"></div>
            <div>
                <div class="theme-header">
                    <div>
                        <h4 class="theme-name">${theme.name}</h4>
                        <span class="theme-author">By: ${theme.author}</span>
                    </div>
                    ${theme.isApplied ? '<span class="theme-applied-badge">Active</span>' : ''}
                </div>
                <p class="theme-desc">${theme.description}</p>
            </div>
            <div>
                ${theme.isApplied 
                    ? `<button class="btn btn-outline btn-sm" style="width:100%" onclick="apiApplyTheme(null)">Remove Theme</button>`
                    : `<button class="btn btn-primary btn-sm" style="width:100%" onclick="apiApplyTheme('${theme.cssUrl}')">Apply Theme</button>`
                }
            </div>
        `;

        DOM.themesGrid.appendChild(card);
    });
}

function updateStatsAndPending() {
    let activeCount = 0;
    let pendingChanges = 0;

    Object.keys(AppState.currentStates).forEach(id => {
        if (AppState.currentStates[id]) activeCount++;
        if (AppState.currentStates[id] !== AppState.initialStates[id]) {
            pendingChanges++;
        }
    });

    DOM.totalPluginCount.textContent = AppState.plugins.length;
    DOM.activePluginCount.textContent = activeCount;
    DOM.pendingChangesCount.textContent = pendingChanges;

    if (pendingChanges > 0) {
        DOM.pendingChangesCount.style.background = 'var(--yellow)';
        DOM.btnApplyChanges.classList.add('pulse');
    } else {
        DOM.pendingChangesCount.style.background = 'rgba(255,255,255,0.2)';
        DOM.btnApplyChanges.classList.remove('pulse');
    }
}

// ==============================================================================
// 5. SUB-SETTINGS MODAL
// ==============================================================================

function openSubSettingsModal(plugin) {
    AppState.editingPluginForOptions = plugin;
    DOM.subSettingsModalTitle.textContent = `⚙️ ${plugin.name} Options`;

    const currentOpts = AppState.currentPluginOptions[plugin.id] || {};
    DOM.subSettingsModalBody.innerHTML = '';

    plugin.availableOptions.forEach(opt => {
        const row = document.createElement('div');
        row.className = 'option-row';

        const val = currentOpts[opt.key] !== undefined ? currentOpts[opt.key] : opt.defaultValue;

        if (opt.type === 'boolean') {
            row.innerHTML = `
                <span class="option-label">${opt.label}</span>
                <label class="switch">
                    <input type="checkbox" id="opt_${opt.key}" ${val ? 'checked' : ''}>
                    <span class="slider"></span>
                </label>
            `;
        } else if (opt.type === 'number') {
            row.innerHTML = `
                <span class="option-label">${opt.label}</span>
                <input type="number" id="opt_${opt.key}" class="form-control" style="width: 80px" min="${opt.min || 1}" max="${opt.max || 10}" value="${val}">
            `;
        } else if (opt.type === 'select') {
            const optionsHtml = (opt.choices || []).map(c => `<option value="${c}" ${c === val ? 'selected' : ''}>${c.toUpperCase()}</option>`).join('');
            row.innerHTML = `
                <span class="option-label">${opt.label}</span>
                <select id="opt_${opt.key}" class="form-control" style="width: 110px">${optionsHtml}</select>
            `;
        }

        DOM.subSettingsModalBody.appendChild(row);
    });

    DOM.subSettingsModal.classList.add('open');
}

function saveSubSettingsFromModal() {
    const plugin = AppState.editingPluginForOptions;
    if (!plugin) return;

    if (!AppState.currentPluginOptions[plugin.id]) {
        AppState.currentPluginOptions[plugin.id] = {};
    }

    plugin.availableOptions.forEach(opt => {
        const el = document.getElementById(`opt_${opt.key}`);
        if (!el) return;

        if (opt.type === 'boolean') {
            AppState.currentPluginOptions[plugin.id][opt.key] = el.checked;
        } else if (opt.type === 'number') {
            AppState.currentPluginOptions[plugin.id][opt.key] = parseFloat(el.value);
        } else {
            AppState.currentPluginOptions[plugin.id][opt.key] = el.value;
        }
    });

    DOM.subSettingsModal.classList.remove('open');
    showToast(`${plugin.name} options updated. Click 'Apply to Discord' to save.`, 'info');
    updateStatsAndPending();
}

// ==============================================================================
// 6. HELPERS & EVENT LISTENERS
// ==============================================================================

function showToast(message, type = 'info') {
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    let icon = type === 'success' ? '✅' : (type === 'error' ? '❌' : 'ℹ️');
    toast.innerHTML = `<span>${icon}</span><span>${message}</span>`;
    DOM.toastContainer.appendChild(toast);

    setTimeout(() => {
        toast.style.opacity = '0';
        toast.style.transform = 'translateX(100%)';
        setTimeout(() => toast.remove(), 300);
    }, 4500);
}

function setButtonLoading(btn, isLoading, text) {
    if (isLoading) {
        btn.disabled = true;
        btn.dataset.originalHtml = btn.innerHTML;
        btn.innerHTML = `<span style="display:inline-block; animation:spin 1s linear infinite;">⏳</span> ${text}`;
    } else {
        btn.disabled = false;
        if (btn.dataset.originalHtml) btn.innerHTML = btn.dataset.originalHtml;
        else btn.textContent = text;
    }
}

function clearSearchFilter() {
    DOM.searchInput.value = '';
    AppState.searchQuery = '';
    DOM.searchClear.style.display = 'none';
    AppState.activeCategory = 'ALL';
    document.querySelectorAll('.pill-btn').forEach(b => b.classList.toggle('active', b.dataset.category === 'ALL'));
    renderPlugins();
}

// Tab Switching
DOM.tabPluginsBtn.addEventListener('click', () => {
    DOM.tabPluginsBtn.classList.add('active');
    DOM.tabThemesBtn.classList.remove('active');
    DOM.tabPlugins.classList.add('active');
    DOM.tabThemes.classList.remove('active');
});

DOM.tabThemesBtn.addEventListener('click', () => {
    DOM.tabThemesBtn.classList.add('active');
    DOM.tabPluginsBtn.classList.remove('active');
    DOM.tabThemes.classList.add('active');
    DOM.tabPlugins.classList.remove('active');
});

// Search & Batch
DOM.searchInput.addEventListener('input', (e) => {
    AppState.searchQuery = e.target.value;
    DOM.searchClear.style.display = AppState.searchQuery ? 'block' : 'none';
    renderPlugins();
});
DOM.searchClear.addEventListener('click', clearSearchFilter);

DOM.btnEnableAllFiltered.addEventListener('click', () => {
    document.querySelectorAll('.plugin-card input[type="checkbox"]').forEach(cb => {
        const id = cb.dataset.pluginId;
        cb.checked = true;
        AppState.currentStates[id] = true;
        document.getElementById(`card-${id}`)?.classList.add('enabled');
    });
    updateStatsAndPending();
});

DOM.btnDisableAllFiltered.addEventListener('click', () => {
    document.querySelectorAll('.plugin-card input[type="checkbox"]').forEach(cb => {
        const id = cb.dataset.pluginId;
        cb.checked = false;
        AppState.currentStates[id] = false;
        document.getElementById(`card-${id}`)?.classList.remove('enabled');
    });
    updateStatsAndPending();
});

// Import & Export
DOM.btnExportProfile.addEventListener('click', exportCurrentProfile);
DOM.btnImportProfile.addEventListener('click', () => DOM.fileInputImport.click());
DOM.fileInputImport.addEventListener('change', (e) => {
    if (e.target.files.length > 0) {
        handleProfileFileImport(e.target.files[0]);
        e.target.value = '';
    }
});

// Drag & drop JSON file onto the window
window.addEventListener('dragover', (e) => e.preventDefault());
window.addEventListener('drop', (e) => {
    e.preventDefault();
    if (e.dataTransfer.files.length > 0) {
        const file = e.dataTransfer.files[0];
        if (file.name.endsWith('.json')) {
            handleProfileFileImport(file);
        }
    }
});

// QuickCSS Snippets
document.querySelectorAll('.snippet-btn').forEach(btn => {
    btn.addEventListener('click', () => {
        const snippet = btn.dataset.snippet;
        DOM.quickCssTextarea.value += (DOM.quickCssTextarea.value ? '\n\n' : '') + snippet;
        showToast('CSS snippet inserted!', 'info');
    });
});

DOM.btnSaveQuickCss.addEventListener('click', apiSaveQuickCss);
DOM.btnResetTheme.addEventListener('click', () => apiApplyTheme(null));
DOM.btnApplyChanges.addEventListener('click', apiApplyChanges);
DOM.btnRestartDiscord.addEventListener('click', apiRestartDiscord);
DOM.btnRestoreBackup.addEventListener('click', apiRestoreBackup);

// Custom Preset Modal
DOM.btnOpenSavePresetModal.addEventListener('click', () => {
    DOM.presetNameInput.value = '';
    DOM.presetDescInput.value = '';
    DOM.savePresetModal.classList.add('open');
    DOM.presetNameInput.focus();
});
DOM.btnCloseSavePresetModal.addEventListener('click', () => DOM.savePresetModal.classList.remove('open'));
DOM.btnCancelPresetModal.addEventListener('click', () => DOM.savePresetModal.classList.remove('open'));
DOM.btnConfirmSavePreset.addEventListener('click', async () => {
    const name = DOM.presetNameInput.value.trim();
    if (!name) return showToast('Please enter a preset name.', 'error');

    try {
        const res = await fetch('/api/presets/save', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                id: 'custom_' + Date.now(),
                name: name,
                description: DOM.presetDescInput.value.trim(),
                icon: 'star',
                color: '#FEE75C',
                pluginStates: AppState.currentStates
            })
        });
        const json = await res.json();
        if (json.success) {
            showToast(json.message, 'success');
            DOM.savePresetModal.classList.remove('open');
            await apiGetPresets();
        }
    } catch (err) {
        showToast('Failed to save preset.', 'error');
    }
});

// Sub-settings Modal
DOM.btnCloseSubSettingsModal.addEventListener('click', () => DOM.subSettingsModal.classList.remove('open'));
DOM.btnSaveSubSettings.addEventListener('click', saveSubSettingsFromModal);

// Close Modals on Backdrop Click
DOM.savePresetModal.addEventListener('click', (e) => {
    if (e.target === DOM.savePresetModal) DOM.savePresetModal.classList.remove('open');
});
DOM.subSettingsModal.addEventListener('click', (e) => {
    if (e.target === DOM.subSettingsModal) DOM.subSettingsModal.classList.remove('open');
});

// ==============================================================================
// 7. INITIALIZATION
// ==============================================================================
async function initApp() {
    await apiGetStatus();
    await Promise.all([
        apiGetPlugins(),
        apiGetPresets(),
        apiGetThemes(),
        apiGetQuickCss()
    ]);
    setInterval(apiGetStatus, 10000);
}

document.addEventListener('DOMContentLoaded', initApp);
