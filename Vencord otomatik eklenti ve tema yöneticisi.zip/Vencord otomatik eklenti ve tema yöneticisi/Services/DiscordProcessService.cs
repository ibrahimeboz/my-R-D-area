using System.Diagnostics;

namespace VencordManager.Services;

/// <summary>
/// Windows işletim sisteminde çalışan Discord süreçlerini izler, sonlandırır ve yeniden başlatır.
/// Geliştirici: İbrahim Etem Boz
/// </summary>
public class DiscordProcessService
{
    private readonly ILogger<DiscordProcessService> _logger;
    private static readonly string[] DiscordProcessNames = { "Discord", "DiscordCanary", "DiscordPTB", "DiscordDevelopment" };

    public DiscordProcessService(ILogger<DiscordProcessService> logger)
    {
        _logger = logger;
    }

    /// <summary>
    /// Discord'un şu anda çalışıp çalışmadığını ve açık olan işlem sayısını tespit eder.
    /// (Discord Electron tabanlı olduğu için arka planda birden çok işlem/process çalıştırır).
    /// </summary>
    public (bool IsRunning, int ProcessCount) GetDiscordStatus()
    {
        int count = 0;
        foreach (var procName in DiscordProcessNames)
        {
            var processes = Process.GetProcessesByName(procName);
            count += processes.Length;
        }

        return (count > 0, count);
    }

    /// <summary>
    /// Çalışan tüm Discord işlemlerini güvenli bir şekilde kapatır.
    /// </summary>
    public async Task<bool> KillDiscordAsync()
    {
        return await Task.Run(() =>
        {
            bool anyKilled = false;
            foreach (var procName in DiscordProcessNames)
            {
                var processes = Process.GetProcessesByName(procName);
                foreach (var proc in processes)
                {
                    try
                    {
                        proc.Kill(entireProcessTree: true);
                        anyKilled = true;
                        _logger.LogInformation("Discord işlemi sonlandırıldı: PID {PID}", proc.Id);
                    }
                    catch (Exception ex)
                    {
                        _logger.LogWarning(ex, "Discord işlemi sonlandırılırken hata: PID {PID}", proc.Id);
                    }
                    finally
                    {
                        proc.Dispose();
                    }
                }
            }

            return anyKilled;
        });
    }

    /// <summary>
    /// Discord'un Windows üzerindeki başlatıcı (Update.exe veya doğrudan exe) yolunu bulur.
    /// </summary>
    public string? FindDiscordExecutablePath()
    {
        string localAppData = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);

        // Standart Discord kurulum yolları
        string[] candidatePaths = {
            Path.Combine(localAppData, "Discord", "Update.exe"),
            Path.Combine(localAppData, "DiscordCanary", "Update.exe"),
            Path.Combine(localAppData, "DiscordPTB", "Update.exe")
        };

        foreach (var path in candidatePaths)
        {
            if (File.Exists(path))
            {
                return path;
            }
        }

        return null;
    }

    /// <summary>
    /// Discord'u kapatıp yeniden başlatarak Vencord eklentilerinin anında yüklenmesini sağlar.
    /// </summary>
    public async Task<bool> RestartDiscordAsync()
    {
        _logger.LogInformation("Discord yeniden başlatma süreci başlatılıyor...");

        string? updateExe = FindDiscordExecutablePath();

        // 1. Çalışan süreçleri kapat
        await KillDiscordAsync();

        // İşletim sisteminin dosya kilitlerini serbest bırakması için kısa bekleme (500ms)
        await Task.Delay(600);

        // 2. Discord'u yeniden başlat
        if (!string.IsNullOrEmpty(updateExe) && File.Exists(updateExe))
        {
            try
            {
                var startInfo = new ProcessStartInfo
                {
                    FileName = updateExe,
                    Arguments = "--processStart Discord.exe",
                    UseShellExecute = true
                };

                Process.Start(startInfo);
                _logger.LogInformation("Discord başarıyla yeniden başlatıldı: {Path}", updateExe);
                return true;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Discord başlatılırken hata meydana geldi.");
                return false;
            }
        }

        _logger.LogWarning("Discord başlatıcı yolu bulunamadı.");
        return false;
    }
}
