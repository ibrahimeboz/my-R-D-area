using VencordManager.Models;

namespace VencordManager.Services;

/// <summary>
/// Discord Vencord istemcisine tema (CSS) enjeksiyonu ve QuickCSS kurallarının yönetiminden sorumlu servis.
/// Geliştirici: İbrahim Etem Boz
/// </summary>
public class ThemeService
{
    private readonly VencordConfigService _configService;
    private readonly ILogger<ThemeService> _logger;

    // Popüler, topluluk tarafından en çok sevilen güvenilir Vencord temaları
    private static readonly List<DiscordTheme> CuratedThemes = new()
    {
        new DiscordTheme
        {
            Id = "catppuccin-mocha",
            Name = "Catppuccin Mocha",
            Author = "Catppuccin Org",
            Description = "Yumuşak pastel tonları ve modern koyu paletiyle göz yormayan popüler estetik tema.",
            CssUrl = "https://catppuccin.github.io/discord/dist/catppuccin-mocha.theme.css",
            AccentColor = "#CBA6F7"
        },
        new DiscordTheme
        {
            Id = "midnight",
            Name = "Midnight Discord (OLED Siyah)",
            Author = "refact0r",
            Description = "Saf siyah (OLED / AMOLED) arayüz. Ekranlarda maksimum pil tasarrufu ve derin kontrast sağlar.",
            CssUrl = "https://refact0r.github.io/midnight-discord/midnight.css",
            AccentColor = "#5865F2"
        },
        new DiscordTheme
        {
            Id = "frosted-glass",
            Name = "Frosted Glass (Buzlu Cam)",
            Author = "Gibbu",
            Description = "Discord arkasına yarı saydam, bulanık akrilik cam efekti ve şık animasyonlar ekler.",
            CssUrl = "https://gibbu.github.io/BetterDiscord-Themes/FrostedGlass/FrostedGlass.theme.css",
            AccentColor = "#00ADB5"
        },
        new DiscordTheme
        {
            Id = "clear-vision",
            Name = "ClearVision v6",
            Author = "ClearVision Team",
            Description = "Fütüristik mavi neon ışıklar, özel yazı tipleri ve modern cam kutucuklar içeren efsanevi tema.",
            CssUrl = "https://clearvision.github.io/ClearVision-v6/ClearVision_v6.theme.css",
            AccentColor = "#7289DA"
        },
        new DiscordTheme
        {
            Id = "material-discord",
            Name = "Material Discord",
            Author = "CapnKitten",
            Description = "Google Material Design tasarım dilini Discord'a taşıyan temiz, kart tabanlı görünüm.",
            CssUrl = "https://capnkitten.github.io/BetterDiscord/Themes/Material-Discord/css/material.theme.css",
            AccentColor = "#4285F4"
        }
    };

    public ThemeService(VencordConfigService configService, ILogger<ThemeService> logger)
    {
        _configService = configService;
        _logger = logger;
    }

    /// <summary>
    /// Küratörlü temaları, hangisinin şu an Discord'da aktif olduğunu belirterek listeler.
    /// </summary>
    public List<DiscordTheme> GetThemes()
    {
        string? activeThemeUrl = _configService.GetActiveThemeUrl();

        return CuratedThemes.Select(t => t with
        {
            IsApplied = !string.IsNullOrEmpty(activeThemeUrl) &&
                        string.Equals(activeThemeUrl, t.CssUrl, StringComparison.OrdinalIgnoreCase)
        }).ToList();
    }

    /// <summary>
    /// Seçilen temayı Vencord'a uygular veya null verilirse temayı kaldırır (Varsayılan Discord'a döner).
    /// </summary>
    public async Task ApplyThemeAsync(string? themeUrl)
    {
        await _configService.SetActiveThemeUrlAsync(themeUrl);
        _logger.LogInformation("Tema durumu güncellendi: {Url}", themeUrl ?? "Varsayılan Discord");
    }

    /// <summary>
    /// Vencord quickCss.css dosyasının içeriğini okur.
    /// </summary>
    public async Task<string> GetQuickCssAsync()
    {
        return await _configService.GetQuickCssAsync();
    }

    /// <summary>
    /// Vencord quickCss.css dosyasına özel CSS kodlarını kaydeder.
    /// </summary>
    public async Task SaveQuickCssAsync(string cssContent)
    {
        await _configService.SaveQuickCssAsync(cssContent);
    }
}
