using System.Text.Json;
using VencordManager.Models;

namespace VencordManager.Services;

/// <summary>
/// Önceden tanımlanmış hazır paketleri ve kullanıcının özel profillerini yönetir.
/// Geliştirici: İbrahim Etem Boz
/// </summary>
public class PresetService
{
    private readonly string _customPresetsPath;
    private readonly ILogger<PresetService> _logger;

    public PresetService(ILogger<PresetService> logger)
    {
        _logger = logger;
        string appData = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
        string appFolder = Path.Combine(appData, "VencordManager");
        Directory.CreateDirectory(appFolder);
        _customPresetsPath = Path.Combine(appFolder, "custom_presets.json");
    }

    public List<PresetProfile> GetBuiltInPresets()
    {
        return new List<PresetProfile>
        {
            new PresetProfile
            {
                Id = "ultimate",
                Name = "⚡ Ultimate Power Pack",
                Description = "Enables the most popular quality-of-life Vencord plugins all in one click.",
                Icon = "bolt",
                Color = "#5865F2",
                PluginStates = new Dictionary<string, bool>
                {
                    ["FakeNitro"] = true,
                    ["SpotifyControls"] = true,
                    ["SpotifyCrack"] = true,
                    ["VolumeBooster"] = true,
                    ["Translate"] = true,
                    ["ShowHiddenChannels"] = true,
                    ["ClearURLs"] = true,
                    ["PlatformIndicators"] = true,
                    ["ImageZoom"] = true,
                    ["BetterFolders"] = true,
                    ["BetterSettings"] = true,
                    ["CallTimer"] = true,
                    ["VoiceMessages"] = true,
                    ["VoiceDownload"] = true,
                    ["ReadAllNotificationsButton"] = true,
                    ["PinDMs"] = true,
                    ["ShikiCodeblocks"] = true,
                    ["MessageLinkEmbeds"] = true,
                    ["AlwaysAnimate"] = true,
                    ["ViewIcons"] = true
                }
            },
            new PresetProfile
            {
                Id = "gamer",
                Name = "🎮 Gaming & High Performance",
                Description = "Disables heavy visual effects, minimizes CPU/RAM usage, and enables voice and music utilities.",
                Icon = "gamepad",
                Color = "#23A55A",
                PluginStates = new Dictionary<string, bool>
                {
                    ["FakeNitro"] = true,
                    ["SpotifyControls"] = true,
                    ["SpotifyCrack"] = true,
                    ["VolumeBooster"] = true,
                    ["PlatformIndicators"] = true,
                    ["ClearURLs"] = true,
                    ["SilentTyping"] = true,
                    ["AlwaysAnimate"] = false,
                    ["oneko"] = false,
                    ["petpet"] = false
                }
            },
            new PresetProfile
            {
                Id = "developer",
                Name = "💻 Developer & Coding Pack",
                Description = "Optimized for software students and coders: Shiki syntax highlighting, DevTools, URL cleaning, and translator.",
                Icon = "code",
                Color = "#F47B67",
                PluginStates = new Dictionary<string, bool>
                {
                    ["ShikiCodeblocks"] = true,
                    ["NoDevtoolsWarning"] = true,
                    ["ClearURLs"] = true,
                    ["Translate"] = true,
                    ["PermissionsViewer"] = true,
                    ["ImageZoom"] = true,
                    ["BetterSettings"] = true,
                    ["MessageLinkEmbeds"] = true
                }
            },
            new PresetProfile
            {
                Id = "privacy",
                Name = "🛡️ Privacy & Security",
                Description = "Cleans tracking parameters from links, disables typing indicator, and enhances overall privacy.",
                Icon = "shield",
                Color = "#57F287",
                PluginStates = new Dictionary<string, bool>
                {
                    ["ClearURLs"] = true,
                    ["SilentTyping"] = true,
                    ["NoDevtoolsWarning"] = true,
                    ["PermissionsViewer"] = true,
                    ["MessageLinkEmbeds"] = true
                }
            },
            new PresetProfile
            {
                Id = "minimal",
                Name = "🌱 Clean & Minimalist",
                Description = "Preserves the clean default Discord feel while adding essential volume boost and notification clearing.",
                Icon = "leaf",
                Color = "#949BA4",
                PluginStates = new Dictionary<string, bool>
                {
                    ["VolumeBooster"] = true,
                    ["ReadAllNotificationsButton"] = true,
                    ["BetterSettings"] = true,
                    ["ClearURLs"] = true
                }
            }
        };
    }

    public async Task<List<PresetProfile>> GetAllPresetsAsync()
    {
        var presets = GetBuiltInPresets();

        if (File.Exists(_customPresetsPath))
        {
            try
            {
                string json = await File.ReadAllTextAsync(_customPresetsPath);
                var customPresets = JsonSerializer.Deserialize<List<PresetProfile>>(json);
                if (customPresets != null)
                {
                    presets.AddRange(customPresets);
                }
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Failed to read custom presets.");
            }
        }

        return presets;
    }

    public async Task SaveCustomPresetAsync(string name, string description, Dictionary<string, bool> pluginStates)
    {
        var customPresets = new List<PresetProfile>();

        if (File.Exists(_customPresetsPath))
        {
            try
            {
                string existingJson = await File.ReadAllTextAsync(_customPresetsPath);
                customPresets = JsonSerializer.Deserialize<List<PresetProfile>>(existingJson) ?? new();
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Could not load existing custom presets, creating fresh list.");
            }
        }

        string id = "custom_" + Guid.NewGuid().ToString("N")[..8];
        customPresets.Add(new PresetProfile
        {
            Id = id,
            Name = "⭐ " + name,
            Description = description,
            Icon = "star",
            Color = "#FEE75C",
            PluginStates = pluginStates
        });

        string serialized = JsonSerializer.Serialize(customPresets, new JsonSerializerOptions { WriteIndented = true });
        await File.WriteAllTextAsync(_customPresetsPath, serialized);
        _logger.LogInformation("Saved new custom preset: {Name}", name);
    }
}
