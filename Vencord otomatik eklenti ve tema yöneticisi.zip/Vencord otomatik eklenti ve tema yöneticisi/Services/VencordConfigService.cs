using System.Text.Json;
using System.Text.Json.Nodes;
using VencordManager.Models;

namespace VencordManager.Services;

/// <summary>
/// Vencord ayar dosyasının (settings.json) güvenli okunması, atomik yazılması, yedeklenmesi
/// ve eklenti katalog yönetiminden sorumlu servis.
/// Geliştirici: İbrahim Etem Boz
/// </summary>
public class VencordConfigService
{
    private readonly string _configFilePath;
    private readonly string _backupFilePath;
    private readonly string _quickCssFilePath;
    private readonly ILogger<VencordConfigService> _logger;

    // Defined catalog of popular plugins with English descriptions, categories, and sub-options
    private static readonly List<PluginInfo> KnownPluginCatalog = new()
    {
        // --- Popular & Essential Tools ---
        new PluginInfo {
            Id = "FakeNitro",
            Name = "Fake Nitro",
            Category = "Nitro & Features",
            Description = "Enables custom emojis, animated emojis, server stickers, and 1080p 60fps screen sharing without Discord Nitro.",
            IsEssential = true,
            Tags = new[] { "nitro", "emoji", "stream", "popular" },
            AvailableOptions = new List<PluginOptionDef>
            {
                new() { Key = "enableEmojiBypass", Label = "Cross-Server Emoji Bypass", Type = "boolean", DefaultValue = true },
                new() { Key = "transformStickers", Label = "Send Custom Stickers", Type = "boolean", DefaultValue = true },
                new() { Key = "transformEmojis", Label = "Send Animated GIF Emojis", Type = "boolean", DefaultValue = true }
            }
        },
        new PluginInfo {
            Id = "SpotifyControls",
            Name = "Spotify Controls",
            Category = "Media & Music",
            Description = "Adds handy play, pause, and skip controls for Spotify right into Discord's bottom left profile panel.",
            IsEssential = true,
            Tags = new[] { "spotify", "music", "controls" },
            AvailableOptions = new List<PluginOptionDef>
            {
                new() { Key = "hoverControls", Label = "Show Controls Only on Hover", Type = "boolean", DefaultValue = false }
            }
        },
        new PluginInfo {
            Id = "SpotifyCrack",
            Name = "Spotify Listen-Along Bypass",
            Category = "Media & Music",
            Description = "Prevents Discord from automatically pausing your Spotify music after speaking for 30 seconds in voice channels.",
            IsEssential = true,
            Tags = new[] { "spotify", "unlimited", "voice" }
        },
        new PluginInfo {
            Id = "VolumeBooster",
            Name = "Volume Booster (Up to 500%)",
            Category = "Voice & Audio",
            Description = "Boosts individual user volume sliders beyond the standard 200% limit, up to 500% for quiet microphones.",
            IsEssential = true,
            Tags = new[] { "volume", "voice", "microphone", "boost" },
            AvailableOptions = new List<PluginOptionDef>
            {
                new() { Key = "multiplier", Label = "Maximum Volume Multiplier (1x - 5x)", Type = "number", DefaultValue = 2, Min = 1, Max = 5 }
            }
        },
        new PluginInfo {
            Id = "Translate",
            Name = "Instant Message Translator",
            Category = "Chat & Messaging",
            Description = "Translates incoming and outgoing foreign messages instantly with a single click using Google Translate.",
            IsEssential = false,
            Tags = new[] { "translate", "language", "chat" },
            AvailableOptions = new List<PluginOptionDef>
            {
                new() { Key = "receivedInputLanguage", Label = "Target Language", Type = "select", DefaultValue = "en", Choices = new[] { "en", "tr", "de", "fr", "es", "ru", "ja" } }
            }
        },
        new PluginInfo {
            Id = "ShowHiddenChannels",
            Name = "Show Hidden Channels",
            Category = "Advanced & Discovery",
            Description = "Displays locked channels you do not have permission to view (does not read private messages, but reveals channel names and topics).",
            IsEssential = false,
            Tags = new[] { "channels", "server", "discovery" }
        },
        new PluginInfo {
            Id = "ClearURLs",
            Name = "Clear URLs (Link Tracker Cleaner)",
            Category = "Privacy & Security",
            Description = "Removes tracking and analytic parameters (utm_*, ref, etc.) from shared and copied web links.",
            IsEssential = true,
            Tags = new[] { "privacy", "security", "links" }
        },
        new PluginInfo {
            Id = "SilentTyping",
            Name = "Silent Typing",
            Category = "Privacy & Security",
            Description = "Disables the 'User is typing...' indicator, letting you compose messages completely silently.",
            IsEssential = false,
            Tags = new[] { "privacy", "typing", "stealth" }
        },
        new PluginInfo {
            Id = "PlatformIndicators",
            Name = "Platform Indicators",
            Category = "Interface & Appearance",
            Description = "Shows crisp badges next to user avatars indicating whether they are on Desktop, Mobile, or Web.",
            IsEssential = true,
            Tags = new[] { "ui", "mobile", "web", "desktop", "platform" }
        },
        new PluginInfo {
            Id = "ImageZoom",
            Name = "Smart Image Zoom",
            Category = "Media & Music",
            Description = "Allows zooming and panning images directly in chat without opening external browser windows.",
            IsEssential = true,
            Tags = new[] { "image", "zoom", "preview" }
        },
        new PluginInfo {
            Id = "BetterFolders",
            Name = "Better Server Folders",
            Category = "Interface & Appearance",
            Description = "Improves Discord server folders by displaying them in a clean, compact popout grid instead of an expanded column.",
            IsEssential = false,
            Tags = new[] { "servers", "folders", "ui" }
        },
        new PluginInfo {
            Id = "BetterSettings",
            Name = "Better Settings UI",
            Category = "Interface & Appearance",
            Description = "Redesigns Discord settings with a fast search bar and categorized navigation for quicker access.",
            IsEssential = true,
            Tags = new[] { "settings", "search", "navigation" }
        },
        new PluginInfo {
            Id = "CallTimer",
            Name = "Call Duration Timer",
            Category = "Voice & Audio",
            Description = "Displays elapsed time for 1-on-1 calls and voice channel sessions right in the top bar.",
            IsEssential = true,
            Tags = new[] { "call", "timer", "voice" }
        },
        new PluginInfo {
            Id = "VoiceMessages",
            Name = "Voice Messages",
            Category = "Voice & Audio",
            Description = "Enables recording and listening to voice messages on desktop Discord.",
            IsEssential = true,
            Tags = new[] { "voice", "audio", "message" }
        },
        new PluginInfo {
            Id = "VoiceDownload",
            Name = "Voice Message Downloader",
            Category = "Voice & Audio",
            Description = "Adds a download button to audio clips and voice messages to save them to your PC.",
            IsEssential = false,
            Tags = new[] { "download", "voice", "audio" }
        },
        new PluginInfo {
            Id = "ReadAllNotificationsButton",
            Name = "Read All Notifications Button",
            Category = "Interface & Appearance",
            Description = "Adds a one-click button to mark all notifications across all servers as read.",
            IsEssential = true,
            Tags = new[] { "notifications", "clear", "read" }
        },
        new PluginInfo {
            Id = "PinDMs",
            Name = "Pin DMs",
            Category = "Chat & Messaging",
            Description = "Allows pinning your most important direct message conversations and group chats to the top of the DM list.",
            IsEssential = true,
            Tags = new[] { "dm", "pin", "friends" }
        },
        new PluginInfo {
            Id = "ReverseImageSearch",
            Name = "Reverse Image Search",
            Category = "Advanced & Discovery",
            Description = "Right-click any image in chat to search its source via Google, Yandex, or SauceNAO.",
            IsEssential = false,
            Tags = new[] { "image", "search", "source" }
        },
        new PluginInfo {
            Id = "ShikiCodeblocks",
            Name = "Shiki Syntax Highlighting",
            Category = "Developer Tools",
            Description = "Renders code blocks in chat with VS Code-quality syntax highlighting and line numbers.",
            IsEssential = true,
            Tags = new[] { "code", "syntax", "developer", "shiki" }
        },
        new PluginInfo {
            Id = "PermissionsViewer",
            Name = "Permissions Viewer",
            Category = "Advanced & Discovery",
            Description = "Detailed popout list showing all permissions assigned to any user or role in the server.",
            IsEssential = false,
            Tags = new[] { "permissions", "roles", "admin" }
        },
        new PluginInfo {
            Id = "AlwaysAnimate",
            Name = "Always Animate Avatars",
            Category = "Interface & Appearance",
            Description = "Keeps animated GIF avatars and profile banners playing continuously without needing to hover.",
            IsEssential = false,
            Tags = new[] { "gif", "avatar", "animation" }
        },
        new PluginInfo {
            Id = "ViewIcons",
            Name = "View Fullsize Avatars & Icons",
            Category = "Interface & Appearance",
            Description = "Click on user avatars, banners, or server icons to view and download them in their original high resolution.",
            IsEssential = false,
            Tags = new[] { "icon", "avatar", "banner", "hd" }
        },
        new PluginInfo {
            Id = "MessageLinkEmbeds",
            Name = "Message Link Embeds",
            Category = "Chat & Messaging",
            Description = "Automatically renders Discord message links as quote cards in chat without needing to click them.",
            IsEssential = true,
            Tags = new[] { "link", "quote", "embed" }
        },
        new PluginInfo {
            Id = "NoDevtoolsWarning",
            Name = "Disable DevTools Warning",
            Category = "Developer Tools",
            Description = "Suppresses the 'Hold Up!' warning message when opening the Discord developer console (Ctrl+Shift+I).",
            IsEssential = false,
            Tags = new[] { "developer", "console", "devtools" }
        },
        new PluginInfo {
            Id = "oneko",
            Name = "Oneko (Cursor Following Cat)",
            Category = "Fun & Cosmetics",
            Description = "Spawns an adorable pixel-art cat that chases your mouse cursor around the Discord window.",
            IsEssential = false,
            Tags = new[] { "cat", "fun", "cosmetic", "oneko" }
        },
        new PluginInfo {
            Id = "petpet",
            Name = "PetPet Generator",
            Category = "Fun & Cosmetics",
            Description = "Right-click any user or emoji to create a head-patting hand animation GIF.",
            IsEssential = false,
            Tags = new[] { "petpet", "fun", "gif" }
        },
        // --- Extended Official Vencord Plugins Catalog ---
        new PluginInfo {
            Id = "FriendsSince",
            Name = "Friends Since",
            Category = "Chat & Messaging",
            Description = "Shows when you became friends with someone in the user popout.",
            IsEssential = true,
            Tags = new[] { "friends", "profile", "chat" }
        },
        new PluginInfo {
            Id = "FullSearchContext",
            Name = "Full Search Context",
            Category = "Chat & Messaging",
            Description = "Makes the message context menu in message search results have all options you'd expect.",
            IsEssential = true,
            Tags = new[] { "search", "context", "chat" }
        },
        new PluginInfo {
            Id = "FullUserInChatbox",
            Name = "Full User In Chatbox",
            Category = "Chat & Messaging",
            Description = "Makes the user mention in the chatbox have more functionalities, like left/right clicking.",
            IsEssential = true,
            Tags = new[] { "chatbox", "mention", "user" }
        },
        new PluginInfo {
            Id = "ImageFilename",
            Name = "Image Filename Tooltip",
            Category = "Media & Music",
            Description = "Display the file name of images & GIFs as a tooltip when hovering over them.",
            IsEssential = true,
            Tags = new[] { "images", "filename", "tooltip" }
        },
        new PluginInfo {
            Id = "ImplicitRelationships",
            Name = "Implicit Relationships",
            Category = "General & Productivity",
            Description = "Shows your implicit relationships in the Friends tab.",
            IsEssential = false,
            Tags = new[] { "friends", "relationships" }
        },
        new PluginInfo {
            Id = "MentionAvatars",
            Name = "Mention Avatars",
            Category = "Interface & Appearance",
            Description = "Shows user avatars and role icons inside mentions.",
            IsEssential = true,
            Tags = new[] { "mentions", "avatars", "roles" }
        },
        new PluginInfo {
            Id = "NoF1",
            Name = "Disable F1 Help",
            Category = "General & Productivity",
            Description = "Disables F1 help bind.",
            IsEssential = true,
            Tags = new[] { "f1", "help", "bind" }
        },
        new PluginInfo {
            Id = "OnePingPerDM",
            Name = "One Ping Per DM",
            Category = "Voice & Audio",
            Description = "If unread messages are sent by a user in DMs multiple times, you'll only receive one audio ping.",
            IsEssential = true,
            Tags = new[] { "dm", "ping", "notification", "audio" }
        },
        new PluginInfo {
            Id = "MessageLogger",
            Name = "Message Logger",
            Category = "Chat & Messaging",
            Description = "Logs deleted and edited messages locally on your device so you never miss what was said.",
            IsEssential = true,
            Tags = new[] { "messages", "logger", "deleted", "privacy" }
        },
        new PluginInfo {
            Id = "InvisibleChat",
            Name = "Invisible Chat",
            Category = "Privacy & Security",
            Description = "Allows sending hidden end-to-end encrypted messages that only intended recipients can decrypt.",
            IsEssential = false,
            Tags = new[] { "encryption", "privacy", "secret" }
        },
        new PluginInfo {
            Id = "QuickReply",
            Name = "Quick Reply",
            Category = "Chat & Messaging",
            Description = "Press 'R' while hovering or focusing any message to quickly quote-reply without touching your mouse.",
            IsEssential = true,
            Tags = new[] { "reply", "shortcuts", "chat" }
        },
        new PluginInfo {
            Id = "QuickMention",
            Name = "Quick Mention",
            Category = "Chat & Messaging",
            Description = "Quickly mention users in chat simply by clicking their avatar with a key modifier.",
            IsEssential = true,
            Tags = new[] { "mention", "avatar", "chat" }
        },
        new PluginInfo {
            Id = "MemberCount",
            Name = "Member Count",
            Category = "Interface & Appearance",
            Description = "Displays accurate total and online server member counts right in the channel header bar.",
            IsEssential = true,
            Tags = new[] { "server", "member", "stats" }
        },
        new PluginInfo {
            Id = "OpenInApp",
            Name = "Open In App",
            Category = "General & Productivity",
            Description = "Opens external Spotify, YouTube, SoundCloud, and Steam links directly in their desktop apps.",
            IsEssential = true,
            Tags = new[] { "links", "spotify", "youtube", "steam" }
        },
        new PluginInfo {
            Id = "BetterRoleDot",
            Name = "Better Role Dot",
            Category = "Interface & Appearance",
            Description = "Styles user role indicators as sleek, modern colored dots instead of standard badges.",
            IsEssential = false,
            Tags = new[] { "roles", "colors", "dots" }
        },
        new PluginInfo {
            Id = "BetterRoleContext",
            Name = "Better Role Context",
            Category = "Interface & Appearance",
            Description = "Adds context menu options to easily copy role IDs, hex colors, and permissions.",
            IsEssential = false,
            Tags = new[] { "roles", "context", "color" }
        },
        new PluginInfo {
            Id = "BetterGifAltText",
            Name = "Better GIF Alt Text",
            Category = "Media & Music",
            Description = "Improves GIF alt text accessibility labels throughout chat.",
            IsEssential = false,
            Tags = new[] { "gif", "media", "accessibility" }
        },
        new PluginInfo {
            Id = "BetterGifPicker",
            Name = "Better GIF Picker",
            Category = "Media & Music",
            Description = "Greatly improves Discord's built-in GIF search, loading speed, and favorites picker.",
            IsEssential = true,
            Tags = new[] { "gif", "search", "picker" }
        },
        new PluginInfo {
            Id = "BlurNSFW",
            Name = "Blur NSFW Media",
            Category = "Privacy & Security",
            Description = "Blurs potentially sensitive and NSFW images and videos until you explicitly hover over them.",
            IsEssential = true,
            Tags = new[] { "nsfw", "privacy", "blur" }
        },
        new PluginInfo {
            Id = "CopyUserURLs",
            Name = "Copy User URLs",
            Category = "General & Productivity",
            Description = "Adds context menu options to copy avatar, banner, and profile URLs with one click.",
            IsEssential = true,
            Tags = new[] { "copy", "avatar", "banner", "url" }
        },
        new PluginInfo {
            Id = "CopyAvatarURL",
            Name = "Copy Avatar URL",
            Category = "General & Productivity",
            Description = "Quickly copy direct image links to user avatars from context menus.",
            IsEssential = false,
            Tags = new[] { "avatar", "copy", "url" }
        },
        new PluginInfo {
            Id = "CustomRPC",
            Name = "Custom Rich Presence (RPC)",
            Category = "Interface & Appearance",
            Description = "Display a completely customizable Rich Presence activity on your Discord profile.",
            IsEssential = false,
            Tags = new[] { "rpc", "presence", "custom" }
        },
        new PluginInfo {
            Id = "DisableCallIdle",
            Name = "Disable Call Idle Disconnect",
            Category = "Voice & Audio",
            Description = "Prevents Discord from automatically disconnecting you when you are alone in a call or voice channel.",
            IsEssential = true,
            Tags = new[] { "voice", "call", "idle" }
        },
        new PluginInfo {
            Id = "EmoteCloner",
            Name = "Emote Cloner",
            Category = "Fun & Cosmetics",
            Description = "Right-click any custom emote or sticker to instantly clone it into your own managed servers.",
            IsEssential = true,
            Tags = new[] { "emote", "sticker", "clone" }
        },
        new PluginInfo {
            Id = "Experiments",
            Name = "Discord Experiments",
            Category = "Developer Tools",
            Description = "Unlocks Discord's hidden internal experiments and developer features tab.",
            IsEssential = false,
            Tags = new[] { "experiments", "developer", "hidden" }
        },
        new PluginInfo {
            Id = "FixCodeblockGap",
            Name = "Fix Codeblock Gap",
            Category = "Interface & Appearance",
            Description = "Removes the awkward extra vertical gap between adjacent codeblocks in messages.",
            IsEssential = false,
            Tags = new[] { "code", "gap", "fix" }
        },
        new PluginInfo {
            Id = "FixImagesQuality",
            Name = "Fix Images Quality",
            Category = "Media & Music",
            Description = "Forces Discord to always load original high-resolution uncompressed images in chat.",
            IsEssential = true,
            Tags = new[] { "images", "hd", "quality" }
        },
        new PluginInfo {
            Id = "FixSpotifyEmbeds",
            Name = "Fix Spotify Embeds",
            Category = "Media & Music",
            Description = "Fixes Spotify track preview embeds that fail to play audio in chat.",
            IsEssential = true,
            Tags = new[] { "spotify", "embed", "audio" }
        },
        new PluginInfo {
            Id = "FixYoutubeEmbeds",
            Name = "Fix YouTube Embeds",
            Category = "Media & Music",
            Description = "Fixes broken embedded YouTube video playback within Discord messages.",
            IsEssential = true,
            Tags = new[] { "youtube", "embed", "video" }
        },
        new PluginInfo {
            Id = "ForceOwnerCrown",
            Name = "Force Owner Crown",
            Category = "Interface & Appearance",
            Description = "Forces the server owner crown icon to always display next to the owner's name in member lists.",
            IsEssential = false,
            Tags = new[] { "owner", "crown", "server" }
        },
        new PluginInfo {
            Id = "FriendshipRanks",
            Name = "Friendship Ranks",
            Category = "Fun & Cosmetics",
            Description = "Calculates and ranks your closest friends based on message history and DM interactions.",
            IsEssential = false,
            Tags = new[] { "friends", "stats", "ranks" }
        },
        new PluginInfo {
            Id = "GameActivityToggle",
            Name = "Game Activity Toggle",
            Category = "General & Productivity",
            Description = "Adds a quick one-click toggle in the bottom user panel to show/hide game activity.",
            IsEssential = true,
            Tags = new[] { "activity", "game", "toggle" }
        },
        new PluginInfo {
            Id = "GifPaste",
            Name = "GIF Paste",
            Category = "Chat & Messaging",
            Description = "Automatically converts pasted Tenor and Giphy links into embedded media.",
            IsEssential = false,
            Tags = new[] { "gif", "paste", "media" }
        },
        new PluginInfo {
            Id = "KeepCurrentChannel",
            Name = "Keep Current Channel",
            Category = "Interface & Appearance",
            Description = "Remembers and restores the last viewed channel when switching back and forth between servers.",
            IsEssential = false,
            Tags = new[] { "channel", "remember", "server" }
        },
        new PluginInfo {
            Id = "MessageClickActions",
            Name = "Message Click Actions",
            Category = "Chat & Messaging",
            Description = "Enables double-click to edit your own messages and click to quickly delete or reply.",
            IsEssential = true,
            Tags = new[] { "click", "edit", "delete", "actions" }
        },
        new PluginInfo {
            Id = "MoreCommands",
            Name = "More Slash Commands",
            Category = "General & Productivity",
            Description = "Adds useful slash commands like /timestamp, /ip, /dice, /shrug, and more.",
            IsEssential = false,
            Tags = new[] { "commands", "slash", "utility" }
        },
        new PluginInfo {
            Id = "MoreKaomoji",
            Name = "More Kaomoji",
            Category = "Fun & Cosmetics",
            Description = "Extends Discord's emoticon picker with a huge library of Japanese kaomoji.",
            IsEssential = false,
            Tags = new[] { "kaomoji", "emoticons", "japanese" }
        },
        new PluginInfo {
            Id = "MutualGroupDMs",
            Name = "Mutual Group DMs",
            Category = "Chat & Messaging",
            Description = "Displays mutual group direct messages in user profile popout cards.",
            IsEssential = false,
            Tags = new[] { "group", "dm", "mutual" }
        },
        new PluginInfo {
            Id = "NoBandwidthKick",
            Name = "No Bandwidth Kick",
            Category = "Voice & Audio",
            Description = "Prevents Discord from kicking you out of voice channels due to temporary low bandwidth.",
            IsEssential = true,
            Tags = new[] { "voice", "bandwidth", "disconnect" }
        },
        new PluginInfo {
            Id = "NoCanaryBadge",
            Name = "No Canary Badge",
            Category = "Interface & Appearance",
            Description = "Hides the Canary or PTB badge from the Discord window header.",
            IsEssential = false,
            Tags = new[] { "canary", "badge", "clean" }
        },
        new PluginInfo {
            Id = "NoFlineTo",
            Name = "No Telemetry Tracking",
            Category = "Privacy & Security",
            Description = "Blocks background analytics and telemetry data collection packets.",
            IsEssential = true,
            Tags = new[] { "privacy", "telemetry", "tracking" }
        },
        new PluginInfo {
            Id = "NoMaskedUrlPaste",
            Name = "No Masked URL Paste",
            Category = "Privacy & Security",
            Description = "Pastes clean raw URLs instead of masked markdown links to prevent phishing risks.",
            IsEssential = true,
            Tags = new[] { "links", "url", "security" }
        },
        new PluginInfo {
            Id = "NoMosaic",
            Name = "No Photo Mosaic",
            Category = "Media & Music",
            Description = "Disables Discord's cramped grid photo mosaic and displays images individually.",
            IsEssential = true,
            Tags = new[] { "mosaic", "images", "display" }
        },
        new PluginInfo {
            Id = "NoPendingCount",
            Name = "No Pending Friend Count",
            Category = "Interface & Appearance",
            Description = "Hides the red notification badge on the pending friend requests tab.",
            IsEssential = false,
            Tags = new[] { "badge", "friends", "clean" }
        },
        new PluginInfo {
            Id = "NoProfileThemes",
            Name = "No Profile Themes",
            Category = "Interface & Appearance",
            Description = "Overrides eye-straining custom profile colors with clean standard dark mode.",
            IsEssential = false,
            Tags = new[] { "profile", "theme", "dark" }
        },
        new PluginInfo {
            Id = "NoReplyMention",
            Name = "No Reply Mention by Default",
            Category = "Chat & Messaging",
            Description = "Automatically turns OFF the @mention toggle when replying to messages.",
            IsEssential = true,
            Tags = new[] { "reply", "mention", "ping" }
        },
        new PluginInfo {
            Id = "NoTypingAnimation",
            Name = "No Typing Animation",
            Category = "Interface & Appearance",
            Description = "Removes the animated typing dots indicator to save CPU and reduce visual clutter.",
            IsEssential = false,
            Tags = new[] { "typing", "animation", "clean" }
        },
        new PluginInfo {
            Id = "NormalizeMessageLinks",
            Name = "Normalize Message Links",
            Category = "Chat & Messaging",
            Description = "Standardizes discord.com message URLs for cross-platform consistency.",
            IsEssential = false,
            Tags = new[] { "links", "normalize", "chat" }
        },
        new PluginInfo {
            Id = "NotificationVolume",
            Name = "Notification Volume Slider",
            Category = "Voice & Audio",
            Description = "Adds an independent volume slider to control Discord's ping and notification sounds.",
            IsEssential = true,
            Tags = new[] { "volume", "notification", "audio" }
        },
        new PluginInfo {
            Id = "PauseInvitesForever",
            Name = "Pause Invites Forever",
            Category = "Privacy & Security",
            Description = "Keeps server invites paused indefinitely for raided or private servers.",
            IsEssential = false,
            Tags = new[] { "invites", "security", "server" }
        },
        new PluginInfo {
            Id = "PictureInPicture",
            Name = "Picture-in-Picture",
            Category = "Media & Music",
            Description = "Enables floating Picture-in-Picture window for Discord screen shares and video streams.",
            IsEssential = true,
            Tags = new[] { "pip", "stream", "video" }
        },
        new PluginInfo {
            Id = "PlainFolderIcon",
            Name = "Plain Folder Icon",
            Category = "Interface & Appearance",
            Description = "Replaces the cluster of tiny server icons on folders with a clean, unified folder icon.",
            IsEssential = false,
            Tags = new[] { "folder", "icon", "servers" }
        },
        new PluginInfo {
            Id = "PreviewMessage",
            Name = "Preview Message",
            Category = "Chat & Messaging",
            Description = "Live preview your markdown, codeblocks, and mentions before sending your message.",
            IsEssential = true,
            Tags = new[] { "preview", "markdown", "chat" }
        },
        new PluginInfo {
            Id = "PronounDB",
            Name = "PronounDB",
            Category = "General & Productivity",
            Description = "Fetches and displays user pronouns right next to their name using the PronounDB database.",
            IsEssential = false,
            Tags = new[] { "pronouns", "profile", "identity" }
        },
        new PluginInfo {
            Id = "ReactErrorDecoder",
            Name = "React Error Decoder",
            Category = "Developer Tools",
            Description = "Automatically decodes minified Discord React error codes into readable stack traces.",
            IsEssential = false,
            Tags = new[] { "react", "errors", "debug" }
        },
        new PluginInfo {
            Id = "RelationshipNotifier",
            Name = "Relationship Notifier",
            Category = "Privacy & Security",
            Description = "Notifies you with a desktop toast whenever someone unfriends, removes, or blocks you.",
            IsEssential = true,
            Tags = new[] { "notifier", "friends", "alert" }
        },
        new PluginInfo {
            Id = "ReviewDB",
            Name = "ReviewDB",
            Category = "Fun & Cosmetics",
            Description = "Read and write community reviews on Discord profiles using the ReviewDB system.",
            IsEssential = false,
            Tags = new[] { "review", "profile", "social" }
        },
        new PluginInfo {
            Id = "RoleColorEverywhere",
            Name = "Role Color Everywhere",
            Category = "Interface & Appearance",
            Description = "Colors usernames across chat, mentions, and typing indicators using their role color.",
            IsEssential = true,
            Tags = new[] { "role", "color", "username" }
        },
        new PluginInfo {
            Id = "SearchReply",
            Name = "Search Reply Jump",
            Category = "Chat & Messaging",
            Description = "Directly jump to the referenced reply message from search results.",
            IsEssential = false,
            Tags = new[] { "search", "reply", "jump" }
        },
        new PluginInfo {
            Id = "SendTimestamps",
            Name = "Send Formatted Timestamps",
            Category = "Chat & Messaging",
            Description = "Adds a date/time picker button to insert localized Discord timestamp tags.",
            IsEssential = true,
            Tags = new[] { "timestamp", "time", "date" }
        },
        new PluginInfo {
            Id = "ServerListIndicators",
            Name = "Server List Indicators",
            Category = "Interface & Appearance",
            Description = "Shows clear mute, unread, and deafen status icons directly on server sidebar icons.",
            IsEssential = true,
            Tags = new[] { "server", "indicators", "sidebar" }
        },
        new PluginInfo {
            Id = "ServerProfile",
            Name = "Quick Server Profile",
            Category = "Interface & Appearance",
            Description = "Adds a quick access button in the server banner to edit your per-server profile.",
            IsEssential = false,
            Tags = new[] { "server", "profile", "edit" }
        },
        new PluginInfo {
            Id = "ShowConnections",
            Name = "Show Connected Accounts",
            Category = "General & Productivity",
            Description = "Directly displays linked YouTube, Twitch, Steam, and GitHub accounts on profile cards.",
            IsEssential = true,
            Tags = new[] { "connections", "accounts", "social" }
        },
        new PluginInfo {
            Id = "ShowHiddenThings",
            Name = "Show Hidden Things",
            Category = "Advanced & Discovery",
            Description = "Reveals hidden UI buttons, menus, and hidden Discord developer settings.",
            IsEssential = false,
            Tags = new[] { "hidden", "discovery", "ui" }
        },
        new PluginInfo {
            Id = "ShowMeYourName",
            Name = "Show Me Your Name",
            Category = "Interface & Appearance",
            Description = "Displays the user's original Discord handle right next to confusing server nicknames.",
            IsEssential = true,
            Tags = new[] { "username", "nickname", "identity" }
        },
        new PluginInfo {
            Id = "ShowTimeouts",
            Name = "Show Timeouts Remaining",
            Category = "General & Productivity",
            Description = "Displays an active countdown timer badge on users who are currently timed out.",
            IsEssential = false,
            Tags = new[] { "timeout", "moderation", "timer" }
        },
        new PluginInfo {
            Id = "SilentMessageToggle",
            Name = "Silent Message Toggle",
            Category = "Chat & Messaging",
            Description = "Adds a quick switch button in the chat bar to automatically send messages with @silent.",
            IsEssential = true,
            Tags = new[] { "silent", "quiet", "notification" }
        },
        new PluginInfo {
            Id = "SlowmodeCounter",
            Name = "Slowmode Counter",
            Category = "Interface & Appearance",
            Description = "Shows an exact countdown timer in the chat bar until slowmode expires.",
            IsEssential = true,
            Tags = new[] { "slowmode", "cooldown", "timer" }
        },
        new PluginInfo {
            Id = "SpotifyShareCommands",
            Name = "Spotify Share Commands",
            Category = "Media & Music",
            Description = "Adds /spotify commands to quickly share your current listening song in chat.",
            IsEssential = false,
            Tags = new[] { "spotify", "music", "share" }
        },
        new PluginInfo {
            Id = "StartupTimings",
            Name = "Startup Timings Benchmark",
            Category = "Developer Tools",
            Description = "Records and displays Discord startup times and plugin initialization benchmarks.",
            IsEssential = false,
            Tags = new[] { "benchmark", "startup", "speed" }
        },
        new PluginInfo {
            Id = "SupportHelper",
            Name = "Support Helper",
            Category = "Developer Tools",
            Description = "Generates comprehensive system and Vencord diagnostics for troubleshooting.",
            IsEssential = false,
            Tags = new[] { "support", "diagnostics", "debug" }
        },
        new PluginInfo {
            Id = "TimeBarAllActivities",
            Name = "Time Bar All Activities",
            Category = "Interface & Appearance",
            Description = "Renders elapsed and remaining progress bars on all Rich Presence activities.",
            IsEssential = false,
            Tags = new[] { "presence", "activity", "progress" }
        },
        new PluginInfo {
            Id = "TypingIndicator",
            Name = "Typing Indicator Avatars",
            Category = "Chat & Messaging",
            Description = "Shows user avatars in the channel typing bar instead of just text names.",
            IsEssential = true,
            Tags = new[] { "typing", "avatars", "indicator" }
        },
        new PluginInfo {
            Id = "TypingTweaks",
            Name = "Typing Tweaks",
            Category = "Chat & Messaging",
            Description = "Customizes typing indicator display format, avatar sizes, and animation speed.",
            IsEssential = false,
            Tags = new[] { "typing", "tweaks", "chat" }
        },
        new PluginInfo {
            Id = "Unindent",
            Name = "Codeblock Unindent",
            Category = "Chat & Messaging",
            Description = "Automatically strips unnecessary leading indentation from multi-line code blocks.",
            IsEssential = false,
            Tags = new[] { "code", "indent", "format" }
        },
        new PluginInfo {
            Id = "UnsuppressEmbeds",
            Name = "Unsuppress Embeds",
            Category = "Chat & Messaging",
            Description = "Allows unsuppressing and viewing embeds that were hidden by message authors.",
            IsEssential = false,
            Tags = new[] { "embeds", "media", "chat" }
        },
        new PluginInfo {
            Id = "UrbanDictionary",
            Name = "Urban Dictionary",
            Category = "Fun & Cosmetics",
            Description = "Query Urban Dictionary slang and phrase definitions using /urban commands.",
            IsEssential = false,
            Tags = new[] { "slang", "dictionary", "urban" }
        },
        new PluginInfo {
            Id = "UserVoiceShow",
            Name = "User Voice Show",
            Category = "Voice & Audio",
            Description = "Displays which server voice channel a user is currently sitting in on their profile card.",
            IsEssential = true,
            Tags = new[] { "voice", "channel", "profile" }
        },
        new PluginInfo {
            Id = "USRBG",
            Name = "USRBG Custom User Backgrounds",
            Category = "Interface & Appearance",
            Description = "Loads and displays high-quality custom user profile banners from the community USRBG database.",
            IsEssential = true,
            Tags = new[] { "banner", "usrbg", "background" }
        },
        new PluginInfo {
            Id = "ValidReply",
            Name = "Valid Reply",
            Category = "Chat & Messaging",
            Description = "Prevents accidental loss of reply targets when typing in chat.",
            IsEssential = false,
            Tags = new[] { "reply", "chat", "safety" }
        },
        new PluginInfo {
            Id = "ValidUser",
            Name = "Valid User",
            Category = "Chat & Messaging",
            Description = "Validates user mentions before sending.",
            IsEssential = false,
            Tags = new[] { "user", "mention", "validation" }
        },
        new PluginInfo {
            Id = "WebContextMenus",
            Name = "Web Context Menus",
            Category = "Interface & Appearance",
            Description = "Brings native desktop right-click menus and features to Discord in the browser.",
            IsEssential = false,
            Tags = new[] { "web", "menu", "context" }
        },
        new PluginInfo {
            Id = "WebKeybinds",
            Name = "Web Keybinds",
            Category = "General & Productivity",
            Description = "Enables desktop keyboard shortcuts (like mute and deafen) inside web Discord.",
            IsEssential = false,
            Tags = new[] { "keybinds", "web", "shortcuts" }
        },
        new PluginInfo {
            Id = "WhoReacted",
            Name = "Who Reacted Tooltip",
            Category = "Chat & Messaging",
            Description = "Hover over message reaction emojis to instantly see a tooltip list of who reacted.",
            IsEssential = true,
            Tags = new[] { "reactions", "emoji", "tooltip" }
        },
        new PluginInfo {
            Id = "Wikilinks",
            Name = "Wikilinks",
            Category = "General & Productivity",
            Description = "Converts [[text]] syntax into instant Wikipedia search links in chat.",
            IsEssential = false,
            Tags = new[] { "wiki", "links", "search" }
        },
        new PluginInfo {
            Id = "YoutubeAdblock",
            Name = "YouTube Adblock",
            Category = "Media & Music",
            Description = "Blocks annoying advertisements during Discord YouTube Watch Together activities.",
            IsEssential = true,
            Tags = new[] { "youtube", "adblock", "stream" }
        },
        new PluginInfo {
            Id = "Dearrow",
            Name = "DeArrow Clickbait Cleaner",
            Category = "Media & Music",
            Description = "Replaces clickbait YouTube titles and thumbnails in Discord with clean community-voted titles.",
            IsEssential = true,
            Tags = new[] { "youtube", "dearrow", "clean" }
        },
        new PluginInfo {
            Id = "AnonymiseFileNames",
            Name = "Anonymise File Names",
            Category = "Privacy & Security",
            Description = "Scrambles and randomizes attachment file names before sending to protect privacy.",
            IsEssential = false,
            Tags = new[] { "files", "privacy", "anonymize" }
        },
        new PluginInfo {
            Id = "BetterUploadButton",
            Name = "Better Upload Button",
            Category = "Chat & Messaging",
            Description = "Customizes the chat plus/upload button with quick shortcuts.",
            IsEssential = false,
            Tags = new[] { "upload", "button", "chat" }
        }
    };

    public VencordConfigService(ILogger<VencordConfigService> logger)
    {
        _logger = logger;
        string appData = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
        _configFilePath = Path.Combine(appData, "Vencord", "settings", "settings.json");
        _backupFilePath = Path.Combine(appData, "Vencord", "settings", "settings.backup.json");
        _quickCssFilePath = Path.Combine(appData, "Vencord", "settings", "quickCss.css");
    }

    public string ConfigFilePath => _configFilePath;
    public string BackupFilePath => _backupFilePath;
    public string QuickCssFilePath => _quickCssFilePath;

    public bool Exists() => File.Exists(_configFilePath);

    public SystemStatus GetStatus(bool isDiscordRunning, int discordProcessCount)
    {
        bool exists = Exists();
        int totalPlugins = 0;
        int enabledPlugins = 0;
        DateTime? lastBackup = File.Exists(_backupFilePath) ? File.GetLastWriteTime(_backupFilePath) : null;
        string? activeTheme = GetActiveThemeUrl();

        if (exists)
        {
            try
            {
                var plugins = GetAllPlugins();
                totalPlugins = plugins.Count;
                enabledPlugins = plugins.Count(p => p.Enabled);
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Error computing plugin stats.");
            }
        }

        return new SystemStatus
        {
            IsVencordInstalled = exists,
            VencordConfigPath = _configFilePath,
            IsDiscordRunning = isDiscordRunning,
            DiscordProcessCount = discordProcessCount,
            TotalPlugins = totalPlugins,
            EnabledPlugins = enabledPlugins,
            LastBackupTime = lastBackup,
            ActiveThemeUrl = activeTheme
        };
    }

    public List<PluginInfo> GetAllPlugins()
    {
        if (!Exists())
        {
            return KnownPluginCatalog;
        }

        string jsonContent = File.ReadAllText(_configFilePath);
        using JsonDocument doc = JsonDocument.Parse(jsonContent);

        var enabledMap = new Dictionary<string, bool>(StringComparer.OrdinalIgnoreCase);
        var optionsMap = new Dictionary<string, Dictionary<string, object>>(StringComparer.OrdinalIgnoreCase);

        if (doc.RootElement.TryGetProperty("plugins", out JsonElement pluginsElement) &&
            pluginsElement.ValueKind == JsonValueKind.Object)
        {
            foreach (JsonProperty prop in pluginsElement.EnumerateObject())
            {
                bool isEnabled = false;
                var pluginOpts = new Dictionary<string, object>();

                if (prop.Value.ValueKind == JsonValueKind.Object)
                {
                    foreach (JsonProperty innerProp in prop.Value.EnumerateObject())
                    {
                        if (string.Equals(innerProp.Name, "enabled", StringComparison.OrdinalIgnoreCase))
                        {
                            isEnabled = innerProp.Value.GetBoolean();
                        }
                        else
                        {
                            pluginOpts[innerProp.Name] = innerProp.Value.ValueKind switch
                            {
                                JsonValueKind.True => true,
                                JsonValueKind.False => false,
                                JsonValueKind.Number => innerProp.Value.GetDouble(),
                                JsonValueKind.String => innerProp.Value.GetString() ?? "",
                                _ => innerProp.Value.ToString()
                            };
                        }
                    }
                }

                enabledMap[prop.Name] = isEnabled;
                if (pluginOpts.Count > 0)
                {
                    optionsMap[prop.Name] = pluginOpts;
                }
            }
        }

        var resultList = new List<PluginInfo>();
        var addedIds = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

        foreach (var catalogItem in KnownPluginCatalog)
        {
            bool isEnabled = enabledMap.TryGetValue(catalogItem.Id, out bool val) && val;
            optionsMap.TryGetValue(catalogItem.Id, out var currentOpts);

            resultList.Add(catalogItem with
            {
                Enabled = isEnabled,
                CurrentOptions = currentOpts
            });
            addedIds.Add(catalogItem.Id);
        }

        foreach (var kvp in enabledMap)
        {
            if (!addedIds.Contains(kvp.Key))
            {
                optionsMap.TryGetValue(kvp.Key, out var currentOpts);
                resultList.Add(new PluginInfo
                {
                    Id = kvp.Key,
                    Name = kvp.Key,
                    Description = "Vencord system plugin",
                    Category = "Other Plugins",
                    Enabled = kvp.Value,
                    IsEssential = false,
                    Tags = new[] { "plugin", "vencord" },
                    CurrentOptions = currentOpts
                });
            }
        }

        return resultList.OrderByDescending(p => p.IsEssential)
                         .ThenBy(p => p.Category)
                         .ThenBy(p => p.Name)
                         .ToList();
    }

    public async Task CreateBackupAsync()
    {
        if (!Exists()) return;

        try
        {
            await Task.Run(() => File.Copy(_configFilePath, _backupFilePath, overwrite: true));
            _logger.LogInformation("Vencord settings backed up to {BackupPath}", _backupFilePath);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to create settings backup.");
            throw;
        }
    }

    public async Task ApplyPluginsAsync(
        Dictionary<string, bool> newPluginStates,
        Dictionary<string, Dictionary<string, object>>? pluginOptions = null)
    {
        if (!Exists())
        {
            throw new FileNotFoundException($"Vencord settings file not found: {_configFilePath}");
        }

        await CreateBackupAsync();

        string jsonText = await File.ReadAllTextAsync(_configFilePath);
        JsonNode? rootNode = JsonNode.Parse(jsonText);

        if (rootNode is null)
        {
            throw new InvalidOperationException("Could not parse settings.json.");
        }

        JsonObject? pluginsObj = rootNode["plugins"] as JsonObject;
        if (pluginsObj is null)
        {
            pluginsObj = new JsonObject();
            rootNode["plugins"] = pluginsObj;
        }

        foreach (var (pluginId, isEnabled) in newPluginStates)
        {
            JsonObject pluginEntry;
            if (pluginsObj.ContainsKey(pluginId) && pluginsObj[pluginId] is JsonObject existing)
            {
                pluginEntry = existing;
                pluginEntry["enabled"] = isEnabled;
            }
            else
            {
                pluginEntry = new JsonObject { ["enabled"] = isEnabled };
                pluginsObj[pluginId] = pluginEntry;
            }

            if (pluginOptions != null && pluginOptions.TryGetValue(pluginId, out var opts))
            {
                foreach (var (optKey, optVal) in opts)
                {
                    if (optVal is bool b) pluginEntry[optKey] = b;
                    else if (optVal is JsonElement je)
                    {
                        if (je.ValueKind == JsonValueKind.True || je.ValueKind == JsonValueKind.False) pluginEntry[optKey] = je.GetBoolean();
                        else if (je.ValueKind == JsonValueKind.Number) pluginEntry[optKey] = je.GetDouble();
                        else pluginEntry[optKey] = je.GetString();
                    }
                    else if (double.TryParse(optVal?.ToString(), out double num)) pluginEntry[optKey] = num;
                    else pluginEntry[optKey] = optVal?.ToString();
                }
            }
        }

        var options = new JsonSerializerOptions { WriteIndented = true };
        string updatedJson = rootNode.ToJsonString(options);

        string tempFile = _configFilePath + ".tmp";
        await File.WriteAllTextAsync(tempFile, updatedJson);
        File.Move(tempFile, _configFilePath, overwrite: true);

        _logger.LogInformation("Successfully updated {Count} plugin states.", newPluginStates.Count);
    }

    public async Task RestoreBackupAsync()
    {
        if (!File.Exists(_backupFilePath))
        {
            throw new FileNotFoundException("No backup file found to restore.");
        }

        await Task.Run(() => File.Copy(_backupFilePath, _configFilePath, overwrite: true));
        _logger.LogInformation("Restored settings from backup.");
    }

    public string? GetActiveThemeUrl()
    {
        if (!Exists()) return null;

        try
        {
            string json = File.ReadAllText(_configFilePath);
            using var doc = JsonDocument.Parse(json);
            if (doc.RootElement.TryGetProperty("themeLinks", out var themeLinks) &&
                themeLinks.ValueKind == JsonValueKind.Array &&
                themeLinks.GetArrayLength() > 0)
            {
                return themeLinks[0].GetString();
            }
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Error reading active theme link.");
        }

        return null;
    }

    public async Task SetActiveThemeUrlAsync(string? themeUrl)
    {
        if (!Exists()) return;

        await CreateBackupAsync();

        string jsonText = await File.ReadAllTextAsync(_configFilePath);
        JsonNode? rootNode = JsonNode.Parse(jsonText) ?? throw new InvalidOperationException("Could not parse JSON");

        var themeLinksArray = new JsonArray();
        if (!string.IsNullOrWhiteSpace(themeUrl))
        {
            themeLinksArray.Add(themeUrl);
        }

        rootNode["themeLinks"] = themeLinksArray;

        var options = new JsonSerializerOptions { WriteIndented = true };
        string updatedJson = rootNode.ToJsonString(options);

        string tempFile = _configFilePath + ".tmp";
        await File.WriteAllTextAsync(tempFile, updatedJson);
        File.Move(tempFile, _configFilePath, overwrite: true);
    }

    public async Task<string> GetQuickCssAsync()
    {
        if (!File.Exists(_quickCssFilePath))
        {
            return string.Empty;
        }

        return await File.ReadAllTextAsync(_quickCssFilePath);
    }

    public async Task SaveQuickCssAsync(string cssContent)
    {
        string? dir = Path.GetDirectoryName(_quickCssFilePath);
        if (!string.IsNullOrEmpty(dir)) Directory.CreateDirectory(dir);

        await File.WriteAllTextAsync(_quickCssFilePath, cssContent);

        if (Exists())
        {
            string jsonText = await File.ReadAllTextAsync(_configFilePath);
            JsonNode? rootNode = JsonNode.Parse(jsonText);
            if (rootNode != null)
            {
                rootNode["useQuickCss"] = true;
                await File.WriteAllTextAsync(_configFilePath, rootNode.ToJsonString(new JsonSerializerOptions { WriteIndented = true }));
            }
        }
    }
}
