using System.Net;
using System.Text.Json;
using VencordManager.Models;

namespace VencordManager.Middlewares;

/// <summary>
/// Uygulama genelindeki tüm HTTP isteklerinde fırlatılan beklenmeyen hataları merkezi olarak yakalar,
/// loglar ve standart ApiResponse formatında istemciye döner.
/// Geliştirici: İbrahim Etem Boz
/// </summary>
public class GlobalExceptionMiddleware
{
    private readonly RequestDelegate _next;
    private readonly ILogger<GlobalExceptionMiddleware> _logger;

    public GlobalExceptionMiddleware(RequestDelegate _next, ILogger<GlobalExceptionMiddleware> logger)
    {
        this._next = _next;
        _logger = logger;
    }

    public async Task InvokeAsync(HttpContext context)
    {
        try
        {
            // İsteği pipeline'daki bir sonraki middleware veya endpoint'e ilet
            await _next(context);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "HTTP isteği işlenirken beklenmeyen bir hata oluştu: {Message}", ex.Message);
            await HandleExceptionAsync(context, ex);
        }
    }

    private static async Task HandleExceptionAsync(HttpContext context, Exception ex)
    {
        context.Response.ContentType = "application/json; charset=utf-8";
        context.Response.StatusCode = (int)HttpStatusCode.InternalServerError;

        var response = ApiResponse<object>.Fail($"Sunucu hatası: {ex.Message}");
        var json = JsonSerializer.Serialize(response, new JsonSerializerOptions
        {
            PropertyNamingPolicy = JsonNamingPolicy.CamelCase
        });

        await context.Response.WriteAsync(json);
    }
}
