using System.Text.Json.Serialization;

namespace VencordManager.Models;

/// <summary>
/// Vencord eklentilerinin meta verilerini ve durum bilgilerini temsil eden veri modeli.
/// Geliştirici: İbrahim Etem Boz
/// </summary>
public record PluginInfo
{
    public required string Id { get; init; }
    public required string Name { get; init; }
    public required string Description { get; init; }
    public required string Category { get; init; }
    public bool Enabled { get; set; }
    public bool IsEssential { get; init; } = false;
    public string[] Tags { get; init; } = Array.Empty<string>();
    
    // Eklentinin alt ayarları (sub-options) varsa tanımları
    public List<PluginOptionDef>? AvailableOptions { get; init; }
    public Dictionary<string, object>? CurrentOptions { get; set; }
}

/// <summary>
/// Eklenti alt ayar alanının tipi ve tanımı (Örn: checkbox, slider/sayı, açılır kutu)
/// </summary>
public record PluginOptionDef
{
    public required string Key { get; init; }
    public required string Label { get; init; }
    public required string Type { get; init; } // "boolean", "number", "select"
    public object? DefaultValue { get; init; }
    public double? Min { get; init; }
    public double? Max { get; init; }
    public string[]? Choices { get; init; }
}

/// <summary>
/// Vencord'un settings.json dosyasındaki "plugins" altındaki her bir eklentinin durumunu modeller.
/// </summary>
public class VencordPluginState
{
    [JsonPropertyName("enabled")]
    public bool Enabled { get; set; }
}

/// <summary>
/// Hazır ve özel profilleri (Presets) temsil eden model.
/// </summary>
public class PresetProfile
{
    public required string Id { get; set; }
    public required string Name { get; set; }
    public required string Description { get; set; }
    public required string Icon { get; set; }
    public required string Color { get; set; }
    public Dictionary<string, bool> PluginStates { get; set; } = new();
    public Dictionary<string, Dictionary<string, object>>? PluginOptions { get; set; }
    public string? ThemeUrl { get; set; }
}

/// <summary>
/// Popüler ve özel Discord/Vencord temalarını temsil eden model.
/// </summary>
public record DiscordTheme
{
    public required string Id { get; init; }
    public required string Name { get; init; }
    public required string Author { get; init; }
    public required string Description { get; init; }
    public required string CssUrl { get; init; }
    public required string AccentColor { get; init; }
    public string? PreviewImage { get; init; }
    public bool IsApplied { get; set; }
}

/// <summary>
/// Frontend'e döneceğimiz sistem durumu bilgisi.
/// </summary>
public class SystemStatus
{
    public bool IsVencordInstalled { get; set; }
    public string VencordConfigPath { get; set; } = string.Empty;
    public bool IsDiscordRunning { get; set; }
    public int DiscordProcessCount { get; set; }
    public int TotalPlugins { get; set; }
    public int EnabledPlugins { get; set; }
    public DateTime? LastBackupTime { get; set; }
    public string? ActiveThemeUrl { get; set; }
}

/// <summary>
/// Genel standart API Yanıt Zarfı (Response Envelope Pattern).
/// </summary>
public class ApiResponse<T>
{
    public bool Success { get; set; }
    public string Message { get; set; } = string.Empty;
    public T? Data { get; set; }

    public static ApiResponse<T> Ok(T data, string message = "İşlem başarılı") =>
        new() { Success = true, Message = message, Data = data };

    public static ApiResponse<T> Fail(string message) =>
        new() { Success = false, Message = message, Data = default };
}

/// <summary>
/// Eklenti durumlarını ve varsa alt ayarlarını topluca güncellemek için gelen istek.
/// </summary>
public class ApplyPluginsRequest
{
    public Dictionary<string, bool> Plugins { get; set; } = new();
    public Dictionary<string, Dictionary<string, object>>? PluginOptions { get; set; }
    public bool RestartDiscordAfterApply { get; set; } = false;
}

/// <summary>
/// Tema uygulama isteği modeli.
/// </summary>
public class ApplyThemeRequest
{
    public string? ThemeUrl { get; set; }
    public bool RestartDiscordAfterApply { get; set; } = false;
}

/// <summary>
/// QuickCSS güncelleme modeli.
/// </summary>
public class QuickCssRequest
{
    public required string CssContent { get; set; }
}
