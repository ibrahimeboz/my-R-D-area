@echo off
chcp 65001 > nul
title Vencord AutoManager - Ibrahim Etem Boz
cd /d "%~dp0"

echo ===============================================================
echo   Vencord Otomatik Eklenti ve Profil Yoneticisi
echo   Gelistirici : Ibrahim Etem Boz
echo   GitHub      : https://github.com/ibrahimetemboz
echo ===============================================================
echo.

where dotnet >nul 2>&1
if %errorlevel% neq 0 (
    echo [HATA] .NET SDK bulunamadi. Lutfen .NET 8 SDK kurulu oldugundan emin olun.
    pause
    exit /b 1
)

echo [1/2] Proje derleniyor ve calistiriliyor...
echo [2/2] Tarayici otomatik olarak http://127.0.0.1:5055 adresinde acilacak.
echo.
echo Paneli kapatmak icin bu konsol penceresinde Ctrl+C tuslarina basabilirsiniz.
echo ---------------------------------------------------------------

dotnet run

if %errorlevel% neq 0 (
    echo.
    echo Bir hata olustu. Detaylar yukarida gorunmektedir.
    pause
)
