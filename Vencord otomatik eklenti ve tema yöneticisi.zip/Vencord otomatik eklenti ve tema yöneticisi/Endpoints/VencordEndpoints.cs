using VencordManager.Models;
using VencordManager.Services;

namespace VencordManager.Endpoints;

/// <summary>
/// Vencord AutoManager REST API rotalarını ve Minimal API endpoint eşlemelerini yönetir.
/// Geliştirici: İbrahim Etem Boz
/// </summary>
public static class VencordEndpoints
{
    public static IEndpointRouteBuilder MapVencordEndpoints(this IEndpointRouteBuilder app)
    {
        var api = app.MapGroup("/api");

        // --------------------------------------------------------------------------
        // SİSTEM & DURUM UÇ NOKTALARI
        // --------------------------------------------------------------------------
        api.MapGet("/status", (VencordConfigService configService, DiscordProcessService discordService) =>
        {
            var (isRunning, count) = discordService.GetDiscordStatus();
            var status = configService.GetStatus(isRunning, count);
            return Results.Ok(ApiResponse<SystemStatus>.Ok(status));
        });

        api.MapPost("/restart-discord", async (DiscordProcessService discordService) =>
        {
            bool success = await discordService.RestartDiscordAsync();
            return success
                ? Results.Ok(ApiResponse<bool>.Ok(true, "Discord yeniden başlatıldı."))
                : Results.Ok(ApiResponse<bool>.Ok(false, "Discord süreçleri sonlandırıldı ancak otomatik başlatılamadı."));
        });

        // --------------------------------------------------------------------------
        // EKLENTİ (PLUGIN) UÇ NOKTALARI
        // --------------------------------------------------------------------------
        api.MapGet("/plugins", (VencordConfigService configService) =>
        {
            var plugins = configService.GetAllPlugins();
            return Results.Ok(ApiResponse<List<PluginInfo>>.Ok(plugins));
        });

        api.MapPost("/apply", async (ApplyPluginsRequest request, VencordConfigService configService, DiscordProcessService discordService) =>
        {
            if (request.Plugins == null || request.Plugins.Count == 0)
            {
                return Results.BadRequest(ApiResponse<bool>.Fail("Güncellenecek eklenti listesi boş olamaz."));
            }

            // Eklentileri ve alt ayarları atomik olarak uygula
            await configService.ApplyPluginsAsync(request.Plugins, request.PluginOptions);

            bool restarted = false;
            if (request.RestartDiscordAfterApply)
            {
                restarted = await discordService.RestartDiscordAsync();
            }

            string msg = restarted
                ? "Ayarlar başarıyla uygulandı ve Discord yeniden başlatıldı!"
                : "Ayarlar başarıyla uygulandı! Discord'da 'Ctrl + R' yaparak yeni ayarları görebilirsiniz.";

            return Results.Ok(ApiResponse<bool>.Ok(true, msg));
        });

        api.MapPost("/restore-backup", async (VencordConfigService configService) =>
        {
            await configService.RestoreBackupAsync();
            return Results.Ok(ApiResponse<bool>.Ok(true, "Yedek dosyasından ayarlar başarıyla geri yüklendi."));
        });

        // --------------------------------------------------------------------------
        // PROFİL (PRESET) UÇ NOKTALARI (IMPORT / EXPORT)
        // --------------------------------------------------------------------------
        api.MapGet("/presets", async (PresetService presetService) =>
        {
            var presets = await presetService.GetAllPresetsAsync();
            return Results.Ok(ApiResponse<List<PresetProfile>>.Ok(presets));
        });

        api.MapPost("/presets/save", async (PresetProfile request, PresetService presetService) =>
        {
            if (string.IsNullOrWhiteSpace(request.Name))
            {
                return Results.BadRequest(ApiResponse<bool>.Fail("Profil ismi boş olamaz."));
            }

            await presetService.SaveCustomPresetAsync(request.Name, request.Description ?? "", request.PluginStates);
            return Results.Ok(ApiResponse<bool>.Ok(true, "Özel profil başarıyla kaydedildi."));
        });

        api.MapPost("/presets/import", async (PresetProfile importedPreset, PresetService presetService) =>
        {
            if (string.IsNullOrWhiteSpace(importedPreset.Name) || importedPreset.PluginStates == null)
            {
                return Results.BadRequest(ApiResponse<bool>.Fail("Geçersiz profil JSON dosyası."));
            }

            await presetService.SaveCustomPresetAsync(
                importedPreset.Name.Replace("⭐", "").Trim(),
                importedPreset.Description ?? "İçe aktarılmış profil",
                importedPreset.PluginStates
            );

            return Results.Ok(ApiResponse<bool>.Ok(true, $"'{importedPreset.Name}' profili başarıyla içe aktarıldı!"));
        });

        // --------------------------------------------------------------------------
        // TEMA & QUICK CSS UÇ NOKTALARI
        // --------------------------------------------------------------------------
        api.MapGet("/themes", (ThemeService themeService) =>
        {
            var themes = themeService.GetThemes();
            return Results.Ok(ApiResponse<List<DiscordTheme>>.Ok(themes));
        });

        api.MapPost("/themes/apply", async (ApplyThemeRequest request, ThemeService themeService, DiscordProcessService discordService) =>
        {
            await themeService.ApplyThemeAsync(request.ThemeUrl);

            bool restarted = false;
            if (request.RestartDiscordAfterApply)
            {
                restarted = await discordService.RestartDiscordAsync();
            }

            string msg = string.IsNullOrEmpty(request.ThemeUrl)
                ? "Tema kaldırıldı (Varsayılan Discord temasına dönüldü)."
                : "Tema başarıyla uygulandı!";

            if (restarted) msg += " Discord yeniden başlatıldı.";

            return Results.Ok(ApiResponse<bool>.Ok(true, msg));
        });

        api.MapGet("/quickcss", async (ThemeService themeService) =>
        {
            string css = await themeService.GetQuickCssAsync();
            return Results.Ok(ApiResponse<string>.Ok(css));
        });

        api.MapPost("/quickcss", async (QuickCssRequest request, ThemeService themeService) =>
        {
            await themeService.SaveQuickCssAsync(request.CssContent);
            return Results.Ok(ApiResponse<bool>.Ok(true, "QuickCSS başarıyla kaydedildi!"));
        });

        return app;
    }
}
