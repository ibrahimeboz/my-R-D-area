# 💖 Romantik Sürpriz Web Sitesi (Interactive Flower Bloom & Romantic Surprise)

Sevgilinize veya özel hissettirmek istediğiniz kişiye dijital ortamda unutulmaz, interaktif ve görsel olarak büyüleyici bir sürpriz sunmak için geliştirilmiş web projesi.

![HTML5 Canvas](https://img.shields.io/badge/Canvas-HTML5-orange?style=for-the-badge&logo=html5)
![Vanilla JS](https://img.shields.io/badge/JavaScript-Procedural_Bloom-yellow?style=for-the-badge&logo=javascript)
![CSS3 Glassmorphic](https://img.shields.io/badge/CSS3-Glassmorphism-blue?style=for-the-badge&logo=css3)
![License](https://img.shields.io/badge/License-MIT-green?style=for-the-badge)

---

## ✨ Öne Çıkan Özellikler

- 🌸 **Prosedürel Çiçek Açma Animasyonu (Procedural Canvas Bloom):** Matematiksel Bezier eğrileri ve yumuşak geçiş fonksiyonları (Easing) ile adım adım filizlenen, yapraklanan ve polen saçan 2D/3D çiçek animasyonu.
- 🎶 **Web Audio API Ambiyans Müziği:** Dışarıdan dosya yüklemeden, tarayıcı içinde Web Audio API sentezleyicisi ile çalınan yumuşak ve romantik piyano/çan akorları.
- ✨ **BOKEH Partikül & Gökyüzü Efekti:** Derin gece ortamı hissi veren ışıldayan arka plan parçacıkları.
- ❤️ **İnteraktif Kalp Dokunma Efekti:** Ekrana her dokunulduğunda veya tıklandığında yükselen renkli ve ışıltılı kalp animasyonu.
- ✉️ **Özel Mektup Modalı (Wax Seal Glass Card):** Balmumu mühürlü, mühür efekti içeren şık ve cam efekti (Glassmorphism) verilmiş özel not penceresi.
- 📱 **Mobil & Tablet Uyumlu (Responsive):** Tüm ekran boyutları ve Retina / Yüksek DPI ekranlar ile %100 uyumlu.

---

## 🛠️ Kullanılan Teknolojiler

- **HTML5 & Canvas API:** Grafiksel çizimler ve animasyonlar.
- **Vanilla JavaScript (ES6+):** Sıfır harici kütüphane (Zero dependencies) ile saf performanslı mantık.
- **Web Audio API:** Dinamik ses sentezleme.
- **CSS3 & Glassmorphism:** Derinlik hissi, bulanıklaştırma (backdrop-filter) ve özel renk paleti.
- **Font Awesome 6 & Google Fonts:** İkonlar ve tipografi (Great Vibes, Cormorant Garamond, Plus Jakarta Sans).

---

## 🚀 Projeyi Çalıştırma

Proje herhangi bir sunucu kurumu gerektirmez.

1. Projeyi bilgisayarınıza indirin veya klonlayın:
   ```bash
   git clone https://github.com/ibrahimetemboz/kiz-arkadasa-supriz-cicek-sitesi.git
   ```
2. `index.html` dosyasını tarayıcınızda (Chrome, Safari, Edge, Firefox vb.) çift tıklayarak açın.

---

## ⚙️ Nasıl Özelleştirilir?

Sitedeki mesajları ve mektup notunu kendi sevgilinize/özel kişinize göre kolayca güncelleyebilirsiniz:

### 1. Ekrandaki Romantik Sözü Değiştirmek
`index.html` dosyasındaki `romantic-quote` ID'li `<p>` etiketini düzenleyin:
```html
<p class="romantic-text" id="romantic-quote">
    "Seni çok seviyorum. Yüzündeki gülücük hiç eksik olmasın..."
</p>
```

### 2. Özel Mektubu Değiştirmek
`index.html` dosyasındaki `#letter-modal` içerisindeki metinleri ve imzayı özelleştirin:
```html
<div class="modal-body">
    <p>Hayatıma girdiğin ilk andan itibaren dünyamı güzelleştirdin...</p>
    <p class="signature">Sonsuz Sevgimle... ❤️</p>
</div>
```

---

## 👨‍💻 Geliştirici (Developer)

Proje **İbrahim Etem Boz** tarafından tasarlanmış ve geliştirilmiştir.

- **GitHub:** [@ibrahimetemboz](https://github.com/ibrahimetemboz)
- **Lisans:** MIT (Dilediğiniz gibi özelleştirip sevdikleriniz için kullanabilirsiniz!)

---

*Sevgiyle ve kodla yapıldı... ❤️*
