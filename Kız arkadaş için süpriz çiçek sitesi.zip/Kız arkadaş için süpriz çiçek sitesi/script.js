/**
 * ==========================================================================
 * Romantik Sürpriz Web Sitesi - JavaScript (Procedural Canvas Bloom & Interaktivite)
 * Geliştirici (Developer): İbrahim Etem Boz
 * GitHub: https://github.com/ibrahimetemboz
 * ==========================================================================
 */

document.addEventListener('DOMContentLoaded', () => {
    // Developer Credit Console Badge
    console.log(
        '%c Developed with ❤️ by İbrahim Etem Boz %c https://github.com/ibrahimetemboz ',
        'background: #ff2a6d; color: #fff; padding: 6px 12px; border-radius: 4px 0 0 4px; font-weight: bold;',
        'background: #0f0a1c; color: #ff6584; padding: 6px 12px; border-radius: 0 4px 4px 0; border: 1px solid #ff2a6d;'
    );

    // Canvas Elementleri
    const bgCanvas = document.getElementById('bg-canvas');
    const bgCtx = bgCanvas.getContext('2d');

    const flowerCanvas = document.getElementById('flower-canvas');
    const flowerCtx = flowerCanvas.getContext('2d');

    const heartCanvas = document.getElementById('heart-canvas');
    const heartCtx = heartCanvas.getContext('2d');

    // UI Elementleri
    const startOverlay = document.getElementById('start-overlay');
    const startBtn = document.getElementById('start-btn');
    const messageContainer = document.getElementById('message-container');
    const audioToggleBtn = document.getElementById('audio-toggle-btn');
    const letterBtn = document.getElementById('letter-btn');
    const replayBtn = document.getElementById('replay-btn');
    const letterModal = document.getElementById('letter-modal');
    const closeModalBtn = document.getElementById('close-modal-btn');

    // Ekran Boyutu Mantığı (DPR Uyumlu)
    let width = 0;
    let height = 0;
    let dpr = Math.min(window.devicePixelRatio || 1, 2);

    function resizeCanvases() {
        width = window.innerWidth;
        height = window.innerHeight;
        dpr = Math.min(window.devicePixelRatio || 1, 2);

        [bgCanvas, flowerCanvas, heartCanvas].forEach(canvas => {
            canvas.width = width * dpr;
            canvas.height = height * dpr;
            canvas.style.width = `${width}px`;
            canvas.style.height = `${height}px`;
            const ctx = canvas.getContext('2d');
            ctx.scale(dpr, dpr);
        });
    }

    window.addEventListener('resize', () => {
        resizeCanvases();
        initBackgroundParticles();
    });

    resizeCanvases();

    // ==========================================================================
    // 1. ARKA PLAN BOKEH & PARTİKÜL SİSTEMİ
    // ==========================================================================
    let bgParticles = [];
    const BG_PARTICLE_COUNT = Math.min(Math.floor(width / 15), 65);

    class BgParticle {
        constructor() {
            this.reset();
        }

        reset() {
            this.x = Math.random() * width;
            this.y = Math.random() * height;
            this.size = Math.random() * 4 + 1.5;
            this.speedY = Math.random() * 0.4 + 0.1;
            this.speedX = (Math.random() - 0.5) * 0.2;
            this.opacity = Math.random() * 0.6 + 0.2;
            this.pulseSpeed = Math.random() * 0.02 + 0.005;
            this.color = Math.random() > 0.4 ? '#ff7597' : (Math.random() > 0.5 ? '#ffe066' : '#9b51e0');
        }

        update() {
            this.y -= this.speedY;
            this.x += Math.sin(this.y * 0.01) * 0.3;
            this.opacity += Math.sin(Date.now() * this.pulseSpeed) * 0.005;

            if (this.y < -10 || this.x < -10 || this.x > width + 10) {
                this.reset();
                this.y = height + 10;
            }
        }

        draw() {
            bgCtx.save();
            bgCtx.globalAlpha = Math.max(0.1, Math.min(0.8, this.opacity));
            bgCtx.shadowBlur = this.size * 3;
            bgCtx.shadowColor = this.color;

            bgCtx.beginPath();
            bgCtx.arc(this.x, this.y, this.size, 0, Math.PI * 2);
            bgCtx.fillStyle = this.color;
            bgCtx.fill();
            bgCtx.restore();
        }
    }

    function initBackgroundParticles() {
        bgParticles = [];
        for (let i = 0; i < BG_PARTICLE_COUNT; i++) {
            bgParticles.push(new BgParticle());
        }
    }

    initBackgroundParticles();

    function renderBackground() {
        bgCtx.clearRect(0, 0, width, height);

        // Gece Gökyüzü Derin Gradyanı
        const gradient = bgCtx.createRadialGradient(
            width / 2, height / 2, 50,
            width / 2, height / 2, Math.max(width, height)
        );
        gradient.addColorStop(0, '#0c071a');
        gradient.addColorStop(0.6, '#06040d');
        gradient.addColorStop(1, '#030206');
        bgCtx.fillStyle = gradient;
        bgCtx.fillRect(0, 0, width, height);

        // Partikülleri Çiz
        bgParticles.forEach(p => {
            p.update();
            p.draw();
        });

        requestAnimationFrame(renderBackground);
    }

    renderBackground();

    // ==========================================================================
    // 2. PROSEDÜREL ÇİÇEK AÇMA ANİMASYONU (HTML5 CANVAS 2D/3D BLOOM)
    // ==========================================================================

    let bloomState = {
        progress: 0,
        stemProgress: 0,
        petalProgress: 0,
        stamenProgress: 0,
        active: false,
        completed: false,
        sparks: []
    };

    // Easing Fonksiyonu (Pürüzsüz Geçiş)
    function easeOutCubic(t) {
        return 1 - Math.pow(1 - t, 3);
    }
    
    function easeOutBack(t) {
        const c1 = 1.70158;
        const c3 = c1 + 1;
        return 1 + c3 * Math.pow(t - 1, 3) + c1 * Math.pow(t - 1, 2);
    }

    // Kıvılcım / Polen Partikül Sınıfı
    class Spark {
        constructor(x, y) {
            this.x = x;
            this.y = y;
            const angle = Math.random() * Math.PI * 2;
            const speed = Math.random() * 3 + 1;
            this.vx = Math.cos(angle) * speed;
            this.vy = Math.sin(angle) * speed - 0.5;
            this.size = Math.random() * 3 + 1;
            this.color = Math.random() > 0.3 ? '#ffe066' : '#ff7597';
            this.alpha = 1;
            this.decay = Math.random() * 0.015 + 0.008;
        }

        update() {
            this.x += this.vx;
            this.y += this.vy;
            this.vy += 0.02; // Hafif yerçekimi
            this.alpha -= this.decay;
        }

        draw(ctx) {
            if (this.alpha <= 0) return;
            ctx.save();
            ctx.globalAlpha = this.alpha;
            ctx.shadowBlur = 8;
            ctx.shadowColor = this.color;
            ctx.fillStyle = this.color;
            ctx.beginPath();
            ctx.arc(this.x, this.y, this.size, 0, Math.PI * 2);
            ctx.fill();
            ctx.restore();
        }
    }

    function renderFlower() {
        flowerCtx.clearRect(0, 0, width, height);

        if (!bloomState.active) {
            requestAnimationFrame(renderFlower);
            return;
        }

        // Animasyon İlerlemesini Güncelle
        if (bloomState.stemProgress < 1) {
            bloomState.stemProgress += 0.006;
        } else if (bloomState.petalProgress < 1) {
            bloomState.petalProgress += 0.005;
        } else if (bloomState.stamenProgress < 1) {
            bloomState.stamenProgress += 0.01;
            
            // Polen / Kıvılcım Patlaması
            if (bloomState.sparks.length < 50 && Math.random() < 0.4) {
                const flowerY = height > 600 ? height * 0.42 : height * 0.38;
                bloomState.sparks.push(new Spark(width / 2, flowerY));
            }
        } else if (!bloomState.completed) {
            bloomState.completed = true;
            onBloomComplete();
        }

        const stemT = easeOutCubic(Math.min(1, bloomState.stemProgress));
        const petalT = easeOutBack(Math.min(1, bloomState.petalProgress));
        const stamenT = easeOutCubic(Math.min(1, bloomState.stamenProgress));

        // Parametreler & Konumlandırma
        const startX = width / 2;
        const startY = height + 20;
        const targetY = height > 600 ? height * 0.42 : height * 0.38;
        const currentY = startY - (startY - targetY) * stemT;

        // ------------------------------------------------------------------
        // A. Gövde & Yapraklar
        // ------------------------------------------------------------------
        flowerCtx.save();
        
        // Gövde Çizimi (Kıvrımlı Bezier Eğrisi)
        const ctrlX1 = startX - 35 * Math.sin(stemT * Math.PI);
        const ctrlY1 = startY - (startY - targetY) * 0.4 * stemT;
        const ctrlX2 = startX + 25 * Math.sin(stemT * Math.PI * 0.8);
        const ctrlY2 = startY - (startY - targetY) * 0.7 * stemT;

        flowerCtx.beginPath();
        flowerCtx.moveTo(startX, startY);
        flowerCtx.bezierCurveTo(ctrlX1, ctrlY1, ctrlX2, ctrlY2, startX, currentY);
        
        const stemGradient = flowerCtx.createLinearGradient(startX, startY, startX, targetY);
        stemGradient.addColorStop(0, '#10381e');
        stemGradient.addColorStop(0.5, '#236b37');
        stemGradient.addColorStop(1, '#44a35c');

        flowerCtx.strokeStyle = stemGradient;
        flowerCtx.lineWidth = Math.max(4, 8 - 3 * stemT);
        flowerCtx.lineCap = 'round';
        flowerCtx.shadowBlur = 12;
        flowerCtx.shadowColor = 'rgba(68, 163, 92, 0.5)';
        flowerCtx.stroke();

        // Yan Yeşil Yapraklar (Gövde Büyüdükçe Açılır)
        if (stemT > 0.4) {
            const leafProgress = Math.min(1, (stemT - 0.4) / 0.6);
            drawLeaf(flowerCtx, startX - 12, startY - (startY - targetY) * 0.45, -0.8, leafProgress, true);
            drawLeaf(flowerCtx, startX + 10, startY - (startY - targetY) * 0.68, 0.7, leafProgress, false);
        }

        flowerCtx.restore();

        // ------------------------------------------------------------------
        // B. Çiçek Taç Yaprakları (Multi-Layer Petals Bloom)
        // ------------------------------------------------------------------
        if (bloomState.petalProgress > 0) {
            flowerCtx.save();
            flowerCtx.translate(startX, currentY);

            // Yaprak Katman Sayıları
            const layers = [
                { count: 12, radius: 85 * petalT, colorInner: '#e84393', colorOuter: '#ff7597', rotationOffset: 0 },
                { count: 10, radius: 65 * petalT, colorInner: '#d63031', colorOuter: '#ff4757', rotationOffset: Math.PI / 10 },
                { count: 8,  radius: 45 * petalT, colorInner: '#ff4757', colorOuter: '#ffe066', rotationOffset: Math.PI / 8 },
                { count: 6,  radius: 25 * petalT, colorInner: '#ffe066', colorOuter: '#ffffff', rotationOffset: Math.PI / 6 }
            ];

            layers.forEach(layer => {
                const angleStep = (Math.PI * 2) / layer.count;

                for (let i = 0; i < layer.count; i++) {
                    const angle = i * angleStep + layer.rotationOffset + (1 - petalT) * 0.3;
                    
                    flowerCtx.save();
                    flowerCtx.rotate(angle);

                    // Tek Bir Taç Yaprağı Çizimi (Bezier Şekli)
                    flowerCtx.beginPath();
                    flowerCtx.moveTo(0, 0);
                    flowerCtx.bezierCurveTo(
                        -layer.radius * 0.45, -layer.radius * 0.4,
                        -layer.radius * 0.3, -layer.radius * 1.1,
                        0, -layer.radius
                    );
                    flowerCtx.bezierCurveTo(
                        layer.radius * 0.3, -layer.radius * 1.1,
                        layer.radius * 0.45, -layer.radius * 0.4,
                        0, 0
                    );

                    const petalGrad = flowerCtx.createRadialGradient(
                        0, 0, 5,
                        0, -layer.radius * 0.6, layer.radius
                    );
                    petalGrad.addColorStop(0, layer.colorInner);
                    petalGrad.addColorStop(0.7, layer.colorOuter);
                    petalGrad.addColorStop(1, 'rgba(255, 255, 255, 0.9)');

                    flowerCtx.fillStyle = petalGrad;
                    flowerCtx.shadowBlur = 15;
                    flowerCtx.shadowColor = layer.colorOuter;
                    flowerCtx.fill();

                    // İnce Altın Damar Çizgisi
                    flowerCtx.beginPath();
                    flowerCtx.moveTo(0, 0);
                    flowerCtx.lineTo(0, -layer.radius * 0.8);
                    flowerCtx.strokeStyle = 'rgba(255, 255, 255, 0.3)';
                    flowerCtx.lineWidth = 1;
                    flowerCtx.stroke();

                    flowerCtx.restore();
                }
            });

            // ------------------------------------------------------------------
            // C. Çiçek Tohum Göbeği & Polen Çubukları (Stamens)
            // ------------------------------------------------------------------
            if (stamenT > 0) {
                const stamenCount = 18;
                const stamenAngleStep = (Math.PI * 2) / stamenCount;

                for (let i = 0; i < stamenCount; i++) {
                    const angle = i * stamenAngleStep;
                    const len = 18 * stamenT;

                    flowerCtx.save();
                    flowerCtx.rotate(angle);

                    flowerCtx.beginPath();
                    flowerCtx.moveTo(0, 0);
                    flowerCtx.lineTo(0, -len);
                    flowerCtx.strokeStyle = 'rgba(255, 224, 102, 0.8)';
                    flowerCtx.lineWidth = 1.5;
                    flowerCtx.stroke();

                    // Çubuk Başındaki Altın Polen Yuvarlağı
                    flowerCtx.beginPath();
                    flowerCtx.arc(0, -len, 2.5 * stamenT, 0, Math.PI * 2);
                    flowerCtx.fillStyle = '#ffffff';
                    flowerCtx.shadowBlur = 10;
                    flowerCtx.shadowColor = '#ffe066';
                    flowerCtx.fill();

                    flowerCtx.restore();
                }

                // Parlak Orta Çekirdek Glow
                flowerCtx.beginPath();
                flowerCtx.arc(0, 0, 10 * stamenT, 0, Math.PI * 2);
                const coreGrad = flowerCtx.createRadialGradient(0, 0, 0, 0, 0, 10 * stamenT);
                coreGrad.addColorStop(0, '#ffffff');
                coreGrad.addColorStop(0.5, '#ffe066');
                coreGrad.addColorStop(1, 'rgba(255, 101, 132, 0)');
                flowerCtx.fillStyle = coreGrad;
                flowerCtx.fill();
            }

            flowerCtx.restore();
        }

        // Sparkle / Polen Parçacıklarını Güncelle & Çiz
        for (let i = bloomState.sparks.length - 1; i >= 0; i--) {
            const spark = bloomState.sparks[i];
            spark.update();
            spark.draw(flowerCtx);
            if (spark.alpha <= 0) {
                bloomState.sparks.splice(i, 1);
            }
        }

        requestAnimationFrame(renderFlower);
    }

    // Gövde Yan Yaprağı Çizici
    function drawLeaf(ctx, x, y, angle, progress, isLeft) {
        ctx.save();
        ctx.translate(x, y);
        ctx.rotate(angle);
        ctx.scale(progress, progress);

        const leafLen = 45;
        ctx.beginPath();
        ctx.moveTo(0, 0);
        ctx.quadraticCurveTo(isLeft ? -25 : 25, -leafLen * 0.5, 0, -leafLen);
        ctx.quadraticCurveTo(isLeft ? 15 : -15, -leafLen * 0.5, 0, 0);

        const leafGrad = ctx.createLinearGradient(0, 0, 0, -leafLen);
        leafGrad.addColorStop(0, '#1b4d2e');
        leafGrad.addColorStop(0.7, '#348e4e');
        leafGrad.addColorStop(1, '#52c472');

        ctx.fillStyle = leafGrad;
        ctx.shadowBlur = 8;
        ctx.shadowColor = 'rgba(82, 196, 114, 0.4)';
        ctx.fill();

        ctx.restore();
    }

    renderFlower();

    // ==========================================================================
    // 3. İNTERAKTİF TIKLAMA / DOKUNMA KALP PARÇACIK EFEKTİ
    // ==========================================================================
    let floatingHearts = [];

    class FloatingHeart {
        constructor(x, y) {
            this.x = x;
            this.y = y;
            this.size = Math.random() * 18 + 14;
            this.speedY = Math.random() * 2 + 1;
            this.speedX = (Math.random() - 0.5) * 1.5;
            this.rotation = (Math.random() - 0.5) * 0.5;
            this.alpha = 1;
            this.color = Math.random() > 0.3 ? '#ff6584' : '#ff2a6d';
        }

        update() {
            this.y -= this.speedY;
            this.x += this.speedX;
            this.rotation += 0.02;
            this.alpha -= 0.012;
        }

        draw(ctx) {
            if (this.alpha <= 0) return;
            ctx.save();
            ctx.globalAlpha = this.alpha;
            ctx.translate(this.x, this.y);
            ctx.rotate(this.rotation);
            ctx.shadowBlur = 10;
            ctx.shadowColor = this.color;
            ctx.fillStyle = this.color;
            ctx.font = `${this.size}px sans-serif`;
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            ctx.fillText('❤️', 0, 0);
            ctx.restore();
        }
    }

    function renderHearts() {
        heartCtx.clearRect(0, 0, width, height);

        for (let i = floatingHearts.length - 1; i >= 0; i--) {
            const h = floatingHearts[i];
            h.update();
            h.draw(heartCtx);
            if (h.alpha <= 0) {
                floatingHearts.splice(i, 1);
            }
        }

        requestAnimationFrame(renderHearts);
    }

    renderHearts();

    function spawnHeartBurst(x, y) {
        for (let i = 0; i < 5; i++) {
            floatingHearts.push(new FloatingHeart(
                x + (Math.random() - 0.5) * 20,
                y + (Math.random() - 0.5) * 20
            ));
        }
    }

    window.addEventListener('pointerdown', (e) => {
        // Buton veya modal haricinde ekrana dokunulduğunda kalpler fırlat
        if (!e.target.closest('button') && !e.target.closest('.modal-card')) {
            spawnHeartBurst(e.clientX, e.clientY);
        }
    });

    // ==========================================================================
    // 4. WEB AUDIO API - ROMANTİK AMBİYANS MÜZİK SENTEZLEYİCİ
    // ==========================================================================
    let audioCtx = null;
    let isAudioPlaying = false;
    let audioInterval = null;

    function initAudio() {
        if (!audioCtx) {
            const AudioContext = window.AudioContext || window.webkitAudioContext;
            audioCtx = new AudioContext();
        }
        if (audioCtx.state === 'suspended') {
            audioCtx.resume();
        }
    }

    // Yumuşak Piyano / Çan Akor Notaları (Fmaj7, Cmaj7, Am, G)
    const romanticNotes = [
        [349.23, 440.00, 523.25, 659.25], // Fmaj7
        [261.63, 329.63, 392.00, 493.88], // Cmaj7
        [220.00, 261.63, 329.63, 440.00], // Am
        [196.00, 246.94, 293.66, 392.00]  // G
    ];

    function playSoftNote(freq, delay = 0) {
        if (!audioCtx || !isAudioPlaying) return;

        setTimeout(() => {
            if (!isAudioPlaying) return;

            const osc = audioCtx.createOscillator();
            const gain = audioCtx.createGain();

            osc.type = 'sine';
            osc.frequency.setValueAtTime(freq, audioCtx.currentTime);

            // Zarf (Attack & Decay)
            const now = audioCtx.currentTime;
            gain.gain.setValueAtTime(0, now);
            gain.gain.linearRampToValueAtTime(0.08, now + 0.1);
            gain.gain.exponentialRampToValueAtTime(0.0001, now + 3.0);

            osc.connect(gain);
            gain.connect(audioCtx.destination);

            osc.start(now);
            osc.stop(now + 3.2);
        }, delay);
    }

    let chordIdx = 0;
    function startMusicLoop() {
        if (audioInterval) clearInterval(audioInterval);
        isAudioPlaying = true;
        audioToggleBtn.classList.add('active');
        audioToggleBtn.style.color = 'var(--accent-pink)';

        audioInterval = setInterval(() => {
            if (!isAudioPlaying) return;

            const chord = romanticNotes[chordIdx];
            chord.forEach((note, i) => {
                playSoftNote(note, i * 220);
            });

            chordIdx = (chordIdx + 1) % romanticNotes.length;
        }, 3200);
    }

    function stopMusicLoop() {
        isAudioPlaying = false;
        if (audioInterval) clearInterval(audioInterval);
        audioToggleBtn.classList.remove('active');
        audioToggleBtn.style.color = '#ffffff';
    }

    audioToggleBtn.addEventListener('click', () => {
        initAudio();
        if (isAudioPlaying) {
            stopMusicLoop();
        } else {
            startMusicLoop();
        }
    });

    // ==========================================================================
    // 5. ANİMASYON & ETKİLEŞİM AKIŞ KONTROLÜ
    // ==========================================================================

    function startBloomAnimation() {
        startOverlay.classList.remove('active');
        messageContainer.classList.add('hidden');
        messageContainer.classList.remove('visible');

        bloomState = {
            progress: 0,
            stemProgress: 0,
            petalProgress: 0,
            stamenProgress: 0,
            active: true,
            completed: false,
            sparks: []
        };

        // Otomatik Müziği Başlatmayı Deneyin
        try {
            initAudio();
            startMusicLoop();
        } catch (err) {
            console.log('Audio init skipped until user interaction');
        }
    }

    function onBloomComplete() {
        // Çiçek tamamen açıldığında mesaj kartını yumuşakça belirginleştir
        setTimeout(() => {
            messageContainer.classList.remove('hidden');
            messageContainer.classList.add('visible');
            
            // Ekranın ortasından kutlama kalpleri patlat
            spawnHeartBurst(width / 2, height * 0.4);
        }, 600);
    }

    // Buton Dinleyicileri
    startBtn.addEventListener('click', () => {
        startBloomAnimation();
    });

    replayBtn.addEventListener('click', () => {
        startBloomAnimation();
    });

    letterBtn.addEventListener('click', () => {
        letterModal.classList.add('active');
    });

    closeModalBtn.addEventListener('click', () => {
        letterModal.classList.remove('active');
    });

    letterModal.addEventListener('click', (e) => {
        if (e.target === letterModal) {
            letterModal.classList.remove('active');
        }
    });

    window.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && letterModal.classList.contains('active')) {
            letterModal.classList.remove('active');
        }
    });
});
