# 🤖 Discord Priv Sunucu Hepsi-Bir-Arada Botu

![Node.js](https://img.shields.io/badge/Node.js-v18%2B-brightgreen?style=for-the-badge&logo=node.js)
![Discord.js](https://img.shields.io/badge/Discord.js-v14-blue?style=for-the-badge&logo=discord)
![License](https://img.shields.io/badge/License-MIT-orange?style=for-the-badge)
![Developer](https://img.shields.io/badge/Developer-%C4%B0brahim%20Etem%20Boz-purple?style=for-the-badge)

**Discord Priv Sunucu Hepsi-Bir-Arada Botu**; gelişmiş **Kayıt (Register)**, **Moderasyon & Ceza**, **Kategori & Kanal İzin Yönetimi (Perm Bot)**, **Yetkili Takip (Staff)**, **Sunucu Koruması (Guard)**, **Spotify & Goygoy (.spo)** sistemlerini tek bir bot ve tek bir token altında toplayan, dahili **Web Yönetim Paneline** sahip modüler bir Discord botudur.

---

## 👨‍💻 Geliştirici Bilgisi

Bu proje **İbrahim Etem Boz** tarafından geliştirilmiştir.

- **Geliştirici:** İbrahim Etem Boz
- **Lisans:** MIT License
- **Mimari:** Modüler Event & Komut Yükleyici, Bellek Dostu Önbellek Yönetimi, Dahili Web Dashboard

---

## ✨ Öne Çıkan Özellikler

### 1. 📝 Kayıt (Register) Modülü
- `.e @üye İsim Yaş` / `.k @üye İsim Yaş` (Erkek/Kadın Kayıt)
- Otomatik İsim Formatı (`• İsim | Yaş`)
- `.isimler @üye` (İsim geçmişi sorgulama)
- `.kayitsiz @üye` (Kayıtsıza atma)
- **Şüpheli Hesap Tespiti:** 7 günden yeni açılmış hesaplara otomatik Şüpheli rolü tanımlama.
- **Karşılama Kartı:** Kayıt kanalında Canvas tabanlı hoş geldin kartı gösterimi.

### 2. 🛡️ Moderasyon & Ceza Sistemi
- `.ban @üye [Sebep]` / `.unban [ID/Üye]`
- `.jail @üye [Süre] [Sebep]` / `.mute @üye [Süre] [Sebep]`
- `.sicil @üye` (Kullanıcının geçmiş tüm cezalarını ve puan durumunu sorgulama)
- **Rol Hiyerarşisi Koruması:** Yetkililerin kendi üstlerindeki kişilere ceza vermesini engelleme.

### 3. 🔒 Kategori & Kanal İzin Yönetimi (Perm Guard)
- `.lock` / `.unlock` (Kanal mesaj gönderimini kilitleme veya kilidi açma)
- `.permsync` (Kanal izinlerini ait olduğu kategori ile anında eşitleme)
- **Akıllı İzin Koruması (Perm Guard):** Beyaz listede olmayan bir yetkili izinsiz kanal/kategori izinlerini değiştirdiğinde izinler **anında eski haline getirilir** ve eylemi yapan kişinin yetkileri çekilir.

### 4. 👥 Yetkili Takip (Staff) Modülü
- `.yetkilisay` (Toplam yetkili, ses kanallarındaki yetkili ve aktif yetkili istatistikleri)
- `.yetkilidurum @üye` (Yetkilinin kayıt sayısı, ceza sayısı ve kazandığı puan takibi)

### 5. 🛡️ Guard (Sunucu Koruma) Modülü
- **Kanal Silme Koruması:** Silinen kanalları anında aynı izinlerle geri oluşturma.
- **Rol Silme Koruması:** Silinen rolleri anında geri yükleme.
- **İzinsiz Bot Ekleme Koruması:** Eklenecek izinsiz botları ve ekleyen kullanıcıyı engelleme/banlama.
- `.whitelist ekle/çıkar/liste` (Dinamik Beyaz Liste Yönetimi)

### 6. 🎧 Spotify & Goygoy Modülü (.spo)
- `.spo [@üye]` (Kullanıcının dinlediği Spotify şarkısını, albüm kapağını ve canlı ilerleme çubuğunu özel Canvas kartı olarak oluşturur ve sunar)
- `.avatar [@üye]` & `.banner [@üye]`
- `.rolmenu` (Gelişmiş Butonlu/Menülü Rol Alma Sistemleri)

### 7. 🌐 Dahili Web Yönetim Paneli (Web Dashboard)
- Bot çalıştığında `http://localhost:3000` adresinde dahili web yönetim paneli aktif olur.
- **Özellikler:**
  - Canlı sunucu istatistikleri ve aktif bellek (RAM) kullanımı.
  - Guard modüllerini tek tıkla açıp kapatma.
  - Dinamik Beyaz Liste (Whitelist) ekleme ve temizleme.
  - Bot Prefix ve Token canlı yapılandırması.

### 8. ⚡ Otomatik Yeniden Başlatıcı (`baslat.bat`)
- Windows ortamında tek tıkla çalıştırılabilir.
- Olası bellek dolmalarında veya çökme durumlarında botu 3 saniye içerisinde otomatik olarak yeniden başlatır.

---

## 🚀 Kurulum ve Çalıştırma

### 1. Gereksinimler
- **Node.js** (v18.0.0 veya üzeri)
- **Git**

### 2. Projeyi Klonlama
```bash
git clone https://github.com/KULLANICI_ADI/PROJECT_NAME.git
cd "Discord priv sunucu botu"
```

### 3. Bağımlılıkları Yükleme
```bash
npm install
```

### 4. Yapılandırma (Çevre Değişkenleri & Ayarlar)
1. Kök dizindeki `.env.example` dosyasını `.env` olarak kopyalayın:
   ```env
   BOT_TOKEN=YOUR_BOT_TOKEN_HERE
   PREFIX=.
   GUILD_ID=YOUR_GUILD_ID_HERE
   ```
2. `settings.example.json` dosyasını `settings.json` adıyla kaydedin ve kendi sunucu Rol ID, Kanal ID ve Yetkili ID değerlerinizi girin.

### 5. Botu Başlatma
- **Windows (Önerilen):** `baslat.bat` dosyasına çift tıklayın.
- **Terminal:**
  ```bash
  npm start
  ```

---

## ⚙️ Discord Developer Portal Ayarları

Botun tüm Guard, Kayıt ve Spotify özelliklerinin tam performanslı çalışabilmesi için [Discord Developer Portal](https://discord.com/developers/applications) üzerinden aşağıdaki **Privileged Gateway Intents** seçeneklerini aktif etmeniz gerekir:

- ✅ **PRESENCE INTENT** (Spotify aktivitelerini okumak için)
- ✅ **SERVER MEMBERS INTENT** (Kayıt ve üye olayları için)
- ✅ **MESSAGE CONTENT INTENT** (Prefix komutlarını işlemek için)

> **Not:** Bot rolünüzün sunucu rol sıralamasında en üst seviyede ve **Yönetici (Administrator)** yetkisine sahip olduğundan emin olun.

---

## 📄 Lisans

Bu proje **MIT Lisansı** altında lisanslanmıştır. Detaylar için `LICENSE` dosyasına bakabilirsiniz.

---

<div align="center">
  <sub>İbrahim Etem Boz tarafından geliştirilmiştir. All Rights Reserved.</sub>
</div>
