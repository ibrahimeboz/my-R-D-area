@echo off
title Priv Discord Botu ve Web Panel Dashboard
color 0A

:start
cls
echo ================================================================
echo               PRIV DISCORD BOTU VE WEB PANEL
echo               Gelistirici: Ibrahim Etem Boz
echo ================================================================
echo.
echo  [*] Bot ve Dahili Web Yonetim Paneli Baslatiliyor...
echo  [*] Web Panel Adresi: http://localhost:3000
echo.
echo ================================================================
echo.

node --expose-gc index.js

echo.
echo ================================================================
echo  [!] Bot kapandi veya bellek korumasi icin yeniden baslatiliyor!
echo  [*] 3 saniye icinde otomatik olarak yeniden baslatiliyor...
echo ================================================================
timeout /t 3 /nobreak > nul
goto start
