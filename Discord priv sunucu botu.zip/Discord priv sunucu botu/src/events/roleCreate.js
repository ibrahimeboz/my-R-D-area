const discordLogger = require("../utils/discordLogger");

module.exports = {
  name: "roleCreate",
  once: false,
  async execute(role, client) {
    if (!role || !role.guild) return;
    await discordLogger.logRoleEvent(client, "create", role).catch(() => {});
  },
};
