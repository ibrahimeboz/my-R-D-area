const discordLogger = require("../utils/discordLogger");

module.exports = {
  name: "messageUpdate",
  once: false,
  async execute(oldMessage, newMessage, client) {
    if (!newMessage || newMessage.author?.bot || !newMessage.guild) return;
    await discordLogger.logMessageUpdate(client, oldMessage, newMessage).catch(() => {});
  },
};
