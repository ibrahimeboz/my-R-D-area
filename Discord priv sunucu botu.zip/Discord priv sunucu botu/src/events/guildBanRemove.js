const { EmbedBuilder } = require("discord.js");
const discordLogger = require("../utils/discordLogger");

module.exports = {
  name: "guildBanRemove",
  once: false,
  async execute(ban, client) {
    const channel = discordLogger.getLogChannel(client, "ban");
    if (!channel) return;

    const user = ban.user;

    const embed = new EmbedBuilder()
      .setTitle("🔓 Üyenin Yasağı Kaldırıldı (Unban)")
      .setColor("#10b981")
      .addFields(
        { name: "👤 Yasağı Kaldırılan", value: `${user.tag} (\`${user.id}\`)`, inline: true },
        { name: "🕒 Zaman", value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: true }
      )
      .setThumbnail(user.displayAvatarURL())
      .setFooter({ text: "Yasak Kaldırma (Unban) Günlüğü" })
      .setTimestamp();

    await channel.send({ embeds: [embed] }).catch(() => {});
  },
};
