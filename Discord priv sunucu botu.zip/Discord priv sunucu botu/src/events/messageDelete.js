const discordLogger = require("../utils/discordLogger");

module.exports = {
  name: "messageDelete",
  once: false,
  async execute(message, client) {
    if (!message || message.author?.bot || !message.guild) return;
    await discordLogger.logMessageDelete(client, message).catch(() => {});
  },
};
