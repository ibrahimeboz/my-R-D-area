const discordLogger = require("../utils/discordLogger");

module.exports = {
  name: "guildMemberRemove",
  once: false,
  async execute(member, client) {
    if (!member || !member.guild) return;
    await discordLogger.logMemberRemove(client, member).catch(() => {});
  },
};
