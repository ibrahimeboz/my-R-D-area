const discordLogger = require("../utils/discordLogger");

module.exports = {
  name: "voiceStateUpdate",
  once: false,
  async execute(oldState, newState, client) {
    if (!oldState.guild && !newState.guild) return;
    await discordLogger.logVoiceState(client, oldState, newState).catch(() => {});
  },
};
