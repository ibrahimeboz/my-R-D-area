const { AuditLogEvent } = require("discord.js");
const db = require("../../database/db");
const guardUtils = require("../../utils/guardUtils");
const embedBuilder = require("../../utils/embedBuilder");

module.exports = {
  name: "channelDelete",
  once: false,
  async execute(channel, client) {
    const config = client.config;
    if (!config.guard?.enabled || !config.guard?.channelGuard) return;

    try {
      const executor = await guardUtils.getAuditExecutor(channel.guild, AuditLogEvent.ChannelDelete);
      if (!executor || executor.id === client.user.id) return;

      const member = await channel.guild.members.fetch(executor.id).catch(() => null);
      const memberRoles = member ? member.roles.cache.map(r => r.id) : [];

      // Whitelist check
      if (db.isWhitelisted(config, executor.id, memberRoles)) {
        return;
      }

      console.warn(`[GUARD CHANNEL DELETE] Kanal silindi! Yapan: ${executor.tag}, Kanal: ${channel.name}`);

      // 1. Kanalı Yeniden Oluştur
      const newChan = await channel.guild.channels.create({
        name: channel.name,
        type: channel.type,
        topic: channel.topic,
        nsfw: channel.nsfw,
        bitrate: channel.bitrate,
        userLimit: channel.userLimit,
        parent: channel.parentId,
        permissionOverwrites: channel.permissionOverwrites.cache,
        reason: "Guard: İzinsiz silinen kanalı geri oluşturma"
      }).catch(() => null);

      // 2. Yapan üyenin yetkilerini al
      if (member) {
        await guardUtils.neutralizeMember(channel.guild, member, "Guard: İzinsiz Kanal Silme");
      }

      // 3. Logla
      const alertEmbed = embedBuilder.guardAlert(
        "Kanal Silme Engellendi",
        executor,
        `#${channel.name} (${channel.id})`,
        `Kanal izinsiz silindi ve bot tarafından ${newChan ? `#${newChan.name} olarak geri oluşturuldu.` : "geri oluşturulmaya çalışıldı."}`
      );

      await guardUtils.sendGuardLog(channel.guild, config, alertEmbed);
    } catch (err) {
      console.error("[GUARD CHANNEL DELETE ERROR]", err);
    }
  },
};
