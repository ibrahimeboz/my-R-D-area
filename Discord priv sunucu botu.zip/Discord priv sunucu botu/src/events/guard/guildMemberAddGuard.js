const { AuditLogEvent } = require("discord.js");
const db = require("../../database/db");
const guardUtils = require("../../utils/guardUtils");
const embedBuilder = require("../../utils/embedBuilder");

module.exports = {
  name: "guildMemberAdd",
  once: false,
  async execute(member, client) {
    // Sadece sunucuya bot katıldığında çalışır
    if (!member.user.bot) return;

    const config = client.config;
    if (!config.guard?.enabled || !config.guard?.botGuard) return;

    try {
      const executor = await guardUtils.getAuditExecutor(member.guild, AuditLogEvent.BotAdd);
      if (!executor || executor.id === client.user.id) return;

      const inviterMember = await member.guild.members.fetch(executor.id).catch(() => null);
      const inviterRoles = inviterMember ? inviterMember.roles.cache.map(r => r.id) : [];

      if (db.isWhitelisted(config, executor.id, inviterRoles)) return;

      console.warn(`[GUARD BOT ADD] İzinsiz bot eklendi! Eklenen: ${member.user.tag}, Ekleyen: ${executor.tag}`);

      // 1. Eklenen izinsiz botu banla
      await member.ban({ reason: "Guard: İzinsiz bot ekleme" }).catch(() => {});

      // 2. Botu ekleyen kullanıcıyı banla veya yetkilerini al
      if (inviterMember) {
        await inviterMember.ban({ reason: "Guard: İzinsiz bot davet etme" }).catch(() => {
          return guardUtils.neutralizeMember(member.guild, inviterMember, "Guard: İzinsiz bot ekleme");
        });
      }

      // 3. Logla
      const alertEmbed = embedBuilder.guardAlert(
        "İzinsiz Bot Ekleme Engellendi",
        executor,
        `Bot: ${member.user.tag} (${member.id})`,
        "Sunucuya izinsiz bot eklendi. Bot ve ekleyen kullanıcı banlandı."
      );

      await guardUtils.sendGuardLog(member.guild, config, alertEmbed);
    } catch (err) {
      console.error("[GUARD BOT ADD ERROR]", err);
    }
  },
};
