const { EmbedBuilder } = require("discord.js");
const discordLogger = require("../utils/discordLogger");

module.exports = {
  name: "guildBanAdd",
  once: false,
  async execute(ban, client) {
    const channel = discordLogger.getLogChannel(client, "ban");
    if (!channel) return;

    const user = ban.user;
    const reason = ban.reason || "Belirtilmedi";

    const embed = new EmbedBuilder()
      .setTitle("🔨 Üye Sunucudan Yasaklandı (Ban)")
      .setColor("#ef4444")
      .addFields(
        { name: "👤 Yasaklanan", value: `${user.tag} (\`${user.id}\`)`, inline: true },
        { name: "📋 Sebep", value: `\`${reason}\``, inline: true },
        { name: "🕒 Zaman", value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: true }
      )
      .setThumbnail(user.displayAvatarURL())
      .setFooter({ text: "Yasaklama (Ban) Günlüğü" })
      .setTimestamp();

    await channel.send({ embeds: [embed] }).catch(() => {});
  },
};
