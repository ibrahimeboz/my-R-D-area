const discordLogger = require("../utils/discordLogger");

module.exports = {
  name: "roleUpdate",
  once: false,
  async execute(oldRole, newRole, client) {
    if (!newRole || !newRole.guild) return;
    let details = "";
    if (oldRole.name !== newRole.name) {
      details += `Eski İsim: \`${oldRole.name}\` ➔ Yeni İsim: \`${newRole.name}\`\n`;
    }
    if (oldRole.hexColor !== newRole.hexColor) {
      details += `Eski Renk: \`${oldRole.hexColor}\` ➔ Yeni Renk: \`${newRole.hexColor}\`\n`;
    }
    await discordLogger.logRoleEvent(client, "update", newRole, { details }).catch(() => {});
  },
};
