const { Client, GatewayIntentBits, Partials, Collection, Options } = require("discord.js");
const fs = require("fs");
const path = require("path");
const { setGlobalDispatcher, ProxyAgent } = require("undici");

class BotClient extends Client {
  constructor(config) {
    super({
      intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMembers,
        GatewayIntentBits.GuildBans,
        GatewayIntentBits.GuildEmojisAndStickers,
        GatewayIntentBits.GuildIntegrations,
        GatewayIntentBits.GuildWebhooks,
        GatewayIntentBits.GuildInvites,
        GatewayIntentBits.GuildVoiceStates,
        GatewayIntentBits.GuildPresences,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.GuildMessageReactions,
        GatewayIntentBits.MessageContent,
      ],
      partials: [
        Partials.User,
        Partials.Channel,
        Partials.GuildMember,
        Partials.Message,
        Partials.Reaction,
      ],
      // Discord.js RAM Tasarrufu ve Önbellek Sınırları
      makeCache: Options.cacheWithLimits({
        MessageManager: 50,         // Her kanalda en fazla son 50 mesajı tut (RAM şişmesini engeller)
        PresenceManager: 500,        // Presence (durum & Spotify) önbelleği
        ReactionManager: 20,       // Reaksiyon önbellek limiti
        UserManager: 1000,
        GuildMemberManager: 1000,
        ThreadManager: 10,
        StageInstanceManager: 0
      }),
      sweepers: {
        ...Options.DefaultSweeperSettings,
        messages: {
          interval: 300,           // Her 5 dakikada bir eski mesajları tara
          lifetime: 900            // 15 dakikadan eski mesajları önbellekten sil
        }
      },
      // Bağlantı zaman aşımı & istek ayarları
      rest: {
        timeout: 30000,
        retries: 4
      }
    });

    this.config = config;

    // Proxy Ayarı (Varsa devreye al)
    const proxyUrl = config.proxy || process.env.HTTPS_PROXY || process.env.HTTP_PROXY;
    if (proxyUrl && proxyUrl.trim().length > 0) {
      try {
        const proxyAgent = new ProxyAgent(proxyUrl.trim());
        setGlobalDispatcher(proxyAgent);
        console.log(`[PROXY AKTİF] Bot bağlantıları şu proxy üzerinden yönlendiriliyor: ${proxyUrl.trim()}`);
      } catch (err) {
        console.error("[PROXY BAĞLANTI HATASI]", err.message);
      }
    }

    this.commands = new Collection();
    this.aliases = new Collection();
    this.isConnecting = false;
    this.lastError = null;
    this.eventsLoaded = false;
    this.commandsLoaded = false;

    // Global Hata Yakalayıcılar (Discord'a Log Gönderimi)
    process.on("unhandledRejection", (reason, promise) => {
      console.error("[UNHANDLED REJECTION]", reason);
      try {
        const discordLogger = require("../utils/discordLogger");
        discordLogger.logError(this, { title: "Unhandled Promise Rejection", error: reason, context: "Global Async Process" });
      } catch (e) {}
    });

    process.on("uncaughtException", (err, origin) => {
      console.error("[UNCAUGHT EXCEPTION]", err);
      try {
        const discordLogger = require("../utils/discordLogger");
        discordLogger.logError(this, { title: "Uncaught Exception", error: err, context: origin || "Global Exception" });
      } catch (e) {}
    });
  }

  loadCommands() {
    this.commands.clear();
    this.aliases.clear();

    const commandsPath = path.join(__dirname, "../commands");
    if (!fs.existsSync(commandsPath)) return;

    const categories = fs.readdirSync(commandsPath);

    for (const category of categories) {
      const categoryPath = path.join(commandsPath, category);
      if (!fs.statSync(categoryPath).isDirectory()) continue;

      const commandFiles = fs.readdirSync(categoryPath).filter(file => file.endsWith(".js"));

      for (const file of commandFiles) {
        const filePath = path.join(categoryPath, file);
        try {
          delete require.cache[require.resolve(filePath)];
          const command = require(filePath);

          if (command.name) {
            command.category = category;
            this.commands.set(command.name.toLowerCase(), command);

            if (command.aliases && Array.isArray(command.aliases)) {
              for (const alias of command.aliases) {
                this.aliases.set(alias.toLowerCase(), command.name.toLowerCase());
              }
            }
          }
        } catch (err) {
          console.error(`[COMMAND YÜKLEME HATASI] ${file}:`, err);
        }
      }
    }
    this.commandsLoaded = true;
    console.log(`[KOMUTLAR] Toplam ${this.commands.size} komut başarıyla yüklendi.`);
  }

  loadEvents() {
    if (this.eventsLoaded) return; // Çift listener oluşmasını engelle

    const eventsPath = path.join(__dirname, "../events");
    if (!fs.existsSync(eventsPath)) return;

    const loadDirectory = (dir) => {
      const files = fs.readdirSync(dir);

      for (const file of files) {
        const filePath = path.join(dir, file);
        const stat = fs.statSync(filePath);

        if (stat.isDirectory()) {
          loadDirectory(filePath);
        } else if (file.endsWith(".js")) {
          try {
            delete require.cache[require.resolve(filePath)];
            const event = require(filePath);
            
            if (event.name && typeof event.execute === "function") {
              if (event.once) {
                this.once(event.name, (...args) => event.execute(...args, this));
              } else {
                this.on(event.name, (...args) => event.execute(...args, this));
              }
            }
          } catch (err) {
            console.error(`[EVENT YÜKLEME HATASI] ${file}:`, err);
          }
        }
      }
    };

    loadDirectory(eventsPath);
    this.eventsLoaded = true;
    console.log("[EVENTLER] Tüm Discord event dinleyicileri yüklendi.");
  }

  // Kullanıcı dostu hata formatlayıcı
  formatError(err) {
    if (!err) return null;
    const msg = err.message || String(err);
    const code = err.code || "";

    if (
      code === "UND_ERR_CONNECT_TIMEOUT" || 
      code === "ETIMEDOUT" || 
      code === "ECONNRESET" ||
      msg.toLowerCase().includes("timeout") || 
      msg.toLowerCase().includes("timed out") || 
      msg.includes("Opening handshake") || 
      msg.includes("fetch failed") || 
      msg.includes("hang up")
    ) {
      return {
        type: "TIMEOUT",
        title: "Discord API / WebSocket Bağlantı Zaman Aşımı (ISP / DPI Engeli)",
        message: "Node.js Discord API ve WebSocket sunucularına (gateway.discord.gg / discord.com) bağlanırken servis sağlayıcınız (ISP) veya DPI engeli nedeniyle bağlantı el sıkışması (handshake) zaman aşımına uğradı. Masaüstü Discord uygulaması için kullanılan bazı yöntemler (Splitware vb.) yalnızca 'Discord.exe' sürecini hedefler, Node.js sürecini (node.exe) kapsamaz.",
        solution: "1. Cloudflare WARP (1.1.1.1) veya tüm sistem trafiğini tünelleyen bir VPN açın.\n2. GoodbyeDPI kullanıyorsanız tüm sistem modunda çalıştırın.\n3. Ayarlarda / .env dosyasında geçerli bir PROXY adresi tanımlayın."
      };
    }

    if (code === "DisallowedIntents" || msg.includes("intents") || msg.includes("Intents")) {
      return {
        type: "INTENTS",
        title: "Ayrıcalıklı Intent'ler (Privileged Gateway Intents) Kapalı",
        message: "Botun sunucu üyelerini okuyabilmesi ve mesaj içeriklerini görebilmesi için Discord Developer Portal'da intent'lerin açılması gerekir.",
        solution: "Discord Developer Portal -> Applications -> Bot sekmesine gidin: Presence Intent, Server Members Intent ve Message Content Intent seçeneklerini AKTİF (Açık) yapıp kaydedin."
      };
    }

    if (code === "TokenInvalid" || msg.includes("An invalid token was provided") || msg.includes("401: Unauthorized")) {
      return {
        type: "TOKEN",
        title: "Geçersiz Bot Tokeni",
        message: "Girilen Discord Bot Tokeni geçersiz veya sıfırlanmış.",
        solution: "Discord Developer Portal -> Bot sekmesinden 'Reset Token' butonuna basarak yeni bir Token oluşturun ve panele yapıştırıp kaydedin."
      };
    }

    return {
      type: "UNKNOWN",
      title: "Bağlantı Hatası",
      message: msg,
      solution: "Lütfen internet bağlantınızı, Tokeninizi ve Sunucu ID'nizi kontrol edin."
    };
  }

  // Botu Discord'a Bağla / Başlat
  async startBot() {
    const token = this.config.token;
    if (!token || token.trim().length < 30 || token.includes("BURAYA_") || token.includes("YOUR_")) {
      this.lastError = {
        type: "NO_TOKEN",
        title: "Token Girilmedi",
        message: "Henüz geçerli bir Discord Bot Tokeni girilmedi.",
        solution: "Web Panel üzerinden Bot Tokeninizi girin ve 'Botu Başlat' butonuna tıklayın."
      };
      return { success: false, error: this.lastError };
    }

    if (this.user) {
      return { success: true, message: `Bot zaten aktif (${this.user.tag})` };
    }

    this.isConnecting = true;
    this.lastError = null;

    try {
      this.loadCommands();
      this.loadEvents();

      console.log("[BOT] Discord'a bağlanılıyor...");
      await this.login(token.trim());
      this.isConnecting = false;
      this.lastError = null;
      console.log(`[BOT AKTİF] ${this.user.tag} başarıyla bağlandı!`);
      console.log("--------------------------------------------------");
      console.log("👨‍💻 Geliştirici: İbrahim Etem Boz");
      console.log("--------------------------------------------------");
      return { success: true, message: `Bot başarıyla Discord'a bağlandı! (${this.user.tag})` };
    } catch (err) {
      this.isConnecting = false;
      this.lastError = this.formatError(err);
      console.error("\n==================================================================");
      console.error(`❌ [BOT BAĞLANTI HATASI]: ${this.lastError.title}`);
      console.error(`📌  Açıklama: ${this.lastError.message}`);
      console.error(`💡  Çözüm: ${this.lastError.solution}`);
      console.error("==================================================================\n");
      return { success: false, error: this.lastError };
    }
  }

  // Botu Durdur (Graceful Shutdown)
  async stopBot() {
    try {
      if (this.user) {
        const tag = this.user.tag;
        
        // 1. Periyodik Servisleri Güvenle Durdur
        try {
          const { stopScheduler } = require("../utils/scheduler");
          stopScheduler();
        } catch (e) {}

        // 2. WebSocket ve Client Oturumunu Güvenle Kapat
        await this.destroy();
        this.isConnecting = false;
        this.eventsLoaded = false;
        console.log(`[BOT DURDURULDU] ${tag} bağlantısı güvenle kapatıldı.`);
        return { success: true, message: "Bot bağlantısı güvenli bir şekilde kapatıldı." };
      }
      return { success: true, message: "Bot zaten çevrimdışı." };
    } catch (err) {
      console.error("[BOT DURDURMA HATASI]", err);
      return { success: false, error: err.message };
    }
  }

  // Botu Yeniden Başlat (Process seviyesinde tam temizleme ve baslat.bat döngüsüyle baştan başlatma)
  async restartBot(reason = "Manuel Restart") {
    try {
      const croxydb = require("croxydb");
      const memUsage = (process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2);
      croxydb.set("lastRestartAudit", {
        reason,
        uptimeSeconds: Math.floor(process.uptime()),
        memoryMB: memUsage,
        timestamp: Date.now()
      });
    } catch (e) {}

    console.log(`\n==================================================================`);
    console.log(`🔄 [BOT RESTART] Sebep: ${reason}`);
    console.log(`🛡️  Tüm servisler kapatılıyor, baslat.bat botu 3 saniye içinde yeniden başlatacak...`);
    console.log(`==================================================================\n`);

    await this.stopBot();

    setTimeout(() => {
      process.exit(0);
    }, 1000);

    return { success: true, message: "Bot yeniden başlatılıyor... (3 saniye içinde açılacaktır)" };
  }

  // Hot-Reload (Bağlantıyı kesmeden komutları ve ayarları tazeleyen hızlı yenileme)
  reloadBot() {
    this.config.reload();
    this.loadCommands();
    console.log(`[HOT-RELOAD] ${this.commands.size} komut ve yapılandırma tazeledi.`);
    return { success: true, commandsCount: this.commands.size };
  }

  async start() {
    // 1. Komutları ve Eventleri hazırla
    this.loadCommands();
    this.loadEvents();

    // 2. İzin AutoSync Başlatıcısını Devreye Al
    try {
      const permissionEngine = require("../utils/permissionEngine");
      permissionEngine.startAutoSync(this);
    } catch (e) {
      console.error("[AUTOSYNC BAŞLATMA HATASI]", e);
    }
    
    // 3. Dahili Web Dashboard Sunucusunu Başlat (http://localhost:3000)
    try {
      const startDashboard = require("../dashboard/server");
      startDashboard(this);
    } catch (err) {
      console.error("[WEB DASHBOARD BAŞLATMA HATASI]", err);
    }

    // 4. Garbage Collector & RAM Bekçisi (Watchdog) Devreye Al
    try {
      const { startGarbageCollector, startMemoryWatchdog, cleanMemory, getMemoryStats } = require("../utils/garbageCollector");
      this.cleanMemory = () => cleanMemory(this);
      this.getMemoryStats = getMemoryStats;
      startGarbageCollector(this, 10);
      startMemoryWatchdog(this);
    } catch (err) {
      console.error("[RAM BEKÇİSİ / GC BAŞLATMA HATASI]", err);
    }

    // 5. Planlı Bakım Zamanlayıcısını Devreye Al
    try {
      const { startScheduler } = require("../utils/scheduler");
      startScheduler(this);
    } catch (err) {
      console.error("[ZAMANLAYICI BAŞLATMA HATASI]", err);
    }

    // 6. Otomatik Başlatma Aktif ise Botu Bağla
    if (this.config.autoStart !== false) {
      await this.startBot();
    } else {
      console.log("[BİLGİ] Bot otomatik başlatma kapalı. Web paneldeki 'Botu Başlat' butonunu kullanabilirsiniz.");
    }
  }
}

module.exports = BotClient;


