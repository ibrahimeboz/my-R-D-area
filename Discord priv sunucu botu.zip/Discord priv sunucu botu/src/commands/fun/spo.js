const { ActivityType, AttachmentBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require("discord.js");
const embedBuilder = require("../../utils/embedBuilder");
const canvasBuilder = require("../../utils/canvasBuilder");

module.exports = {
  name: "spo",
  aliases: ["spotify"],
  async execute(message, args, client) {
    const user = message.mentions.users.first() || message.author;
    
    // Member ve Presence bilgisini önbellekten al veya güncel durum ile fetch et
    let member = message.guild.members.cache.get(user.id);
    if (!member || !member.presence) {
      member = await message.guild.members.fetch({ user: user.id, withPresences: true }).catch(() => null);
    }

    if (!member || !member.presence) {
      const errReply = await message.reply({ 
        embeds: [embedBuilder.error("Spotify", `**${user.username}** kullanıcısının herhangi bir aktivite veya Spotify durumu bulunamadı.\n*(Kullanıcı çevrimdışı veya gizli modda olabilir)*`)] 
      }).catch(() => null);

      if (errReply) {
        setTimeout(() => {
          errReply.delete().catch(() => {});
          message.delete().catch(() => {});
        }, 5000);
      }
      return;
    }

    const spotifyActivity = member.presence.activities.find(
      a => a.name === "Spotify" || a.type === ActivityType.Listening
    );

    if (!spotifyActivity) {
      const errReply = await message.reply({ 
        embeds: [embedBuilder.error("Spotify", `**${user.username}** şu an Spotify'da herhangi bir şarkı dinlemiyor.`)] 
      }).catch(() => null);

      if (errReply) {
        setTimeout(() => {
          errReply.delete().catch(() => {});
          message.delete().catch(() => {});
        }, 5000);
      }
      return;
    }

    const song = spotifyActivity.details || "Bilinmiyor";
    const artist = spotifyActivity.state || "Bilinmiyor";
    const album = spotifyActivity.assets?.largeText || "Bilinmiyor";
    const trackId = spotifyActivity.syncId;
    const trackUrl = trackId ? `https://open.spotify.com/track/${trackId}` : null;
    
    // Albüm Kapağı URL'si
    let albumArt = null;
    if (spotifyActivity.assets?.largeImage) {
      const imageId = spotifyActivity.assets.largeImage.replace("spotify:", "");
      albumArt = `https://i.scdn.co/image/${imageId}`;
    }

    // Şarkı Süreleri
    let currentMs = 0;
    let totalMs = 0;
    if (spotifyActivity.timestamps?.start && spotifyActivity.timestamps?.end) {
      const startTime = spotifyActivity.timestamps.start.getTime();
      const endTime = spotifyActivity.timestamps.end.getTime();
      totalMs = Math.max(endTime - startTime, 1);
      currentMs = Math.min(Math.max(Date.now() - startTime, 0), totalMs);
    }

    // Canvas Kartını Oluştur
    let attachment = null;
    try {
      const cardBuffer = await canvasBuilder.buildSpotifyCard({
        user,
        song,
        artist,
        album,
        albumArt,
        currentMs,
        totalMs
      });
      attachment = new AttachmentBuilder(cardBuffer, { name: "spotify.png" });
    } catch (err) {
      console.error("[Spotify Canvas Hatası]:", err);
    }

    const components = [];
    if (trackUrl) {
      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setLabel("Spotify'da Dinle")
          .setStyle(ButtonStyle.Link)
          .setURL(trackUrl)
          .setEmoji("🎧")
      );
      components.push(row);
    }

    if (attachment) {
      await message.reply({ files: [attachment], components });
    } else {
      // Fallback: Canvas hatası olursa şık embed gönder
      const embed = embedBuilder.spotify(user, {
        song,
        artist,
        album,
        albumArt,
        trackUrl,
        currentTime: "00:00",
        totalTime: "00:00",
        progressBar: "▶️ ━━━━━━━━━ 🔊"
      });
      await message.reply({ embeds: [embed], components });
    }
  },
};
