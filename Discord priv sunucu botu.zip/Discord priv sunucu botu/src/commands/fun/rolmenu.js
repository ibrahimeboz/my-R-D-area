const { EmbedBuilder, ActionRowBuilder, StringSelectMenuBuilder } = require("discord.js");
const embedBuilder = require("../../utils/embedBuilder");

// Hazır Şablonlar
const TEMPLATES = {
  burc: {
    title: "🔮 Burç Rolünü Seç",
    description: "Aşağıdaki menüden burcunu seçerek rolünü alabilirsin. Tekrar seçersen rol kaldırılır.",
    color: "#9333ea",
    placeholder: "Burcunu seç...",
    maxValues: 1,
    options: [
      { label: "Koç", emoji: "♈", description: "21 Mart - 19 Nisan" },
      { label: "Boğa", emoji: "♉", description: "20 Nisan - 20 Mayıs" },
      { label: "İkizler", emoji: "♊", description: "21 Mayıs - 20 Haziran" },
      { label: "Yengeç", emoji: "♋", description: "21 Haziran - 22 Temmuz" },
      { label: "Aslan", emoji: "♌", description: "23 Temmuz - 22 Ağustos" },
      { label: "Başak", emoji: "♍", description: "23 Ağustos - 22 Eylül" },
      { label: "Terazi", emoji: "♎", description: "23 Eylül - 22 Ekim" },
      { label: "Akrep", emoji: "♏", description: "23 Ekim - 21 Kasım" },
      { label: "Yay", emoji: "♐", description: "22 Kasım - 21 Aralık" },
      { label: "Oğlak", emoji: "♑", description: "22 Aralık - 19 Ocak" },
      { label: "Kova", emoji: "♒", description: "20 Ocak - 18 Şubat" },
      { label: "Balık", emoji: "♓", description: "19 Şubat - 20 Mart" }
    ]
  },
  iliski: {
    title: "💕 İlişki Durumunu Seç",
    description: "Aşağıdaki menüden ilişki durumunu seçerek rolünü alabilirsin.",
    color: "#ec4899",
    placeholder: "İlişki durumunu seç...",
    maxValues: 1,
    options: [
      { label: "Bekar", emoji: "💔", description: "Yalnız ve bağımsız" },
      { label: "İlişkide", emoji: "💑", description: "Mutlu bir ilişkide" },
      { label: "Evli", emoji: "💍", description: "Hayat arkadaşını bulmuş" },
      { label: "Nişanlı", emoji: "💝", description: "Yakında düğün var" },
      { label: "Karışık", emoji: "🤷", description: "Durumlar karışık" },
      { label: "Aramıyor", emoji: "🚫", description: "Kimseyi aramıyor" }
    ]
  },
  oyun: {
    title: "🎮 Oyun Rolünü Seç",
    description: "Aşağıdaki menüden oynadığın oyunları seçerek rollerini alabilirsin. Birden fazla seçebilirsin!",
    color: "#22c55e",
    placeholder: "Oyunlarını seç...",
    maxValues: 5,
    options: [
      { label: "Valorant", emoji: "🎯", description: "Taktiksel FPS" },
      { label: "League of Legends", emoji: "⚔️", description: "MOBA klasiği" },
      { label: "CS2", emoji: "🔫", description: "Counter-Strike 2" },
      { label: "Minecraft", emoji: "⛏️", description: "Sandbox hayatta kalma" },
      { label: "GTA V / FiveM", emoji: "🚗", description: "Açık dünya macera" },
      { label: "Fortnite", emoji: "🏗️", description: "Battle Royale" },
      { label: "Apex Legends", emoji: "🦊", description: "Battle Royale FPS" },
      { label: "Roblox", emoji: "🧱", description: "Sanal dünyalar" },
      { label: "Rocket League", emoji: "⚽", description: "Arabalı futbol" },
      { label: "Pubg", emoji: "🪖", description: "Battle Royale" },
      { label: "Zula", emoji: "💣", description: "Türk yapımı FPS" },
      { label: "Brawl Stars", emoji: "⭐", description: "Mobil aksiyon" }
    ]
  },
  takim: {
    title: "⚽ Futbol Takımını Seç",
    description: "Aşağıdaki menüden tuttuğun takımı seçerek rolünü alabilirsin.",
    color: "#f97316",
    placeholder: "Takımını seç...",
    maxValues: 1,
    options: [
      { label: "Galatasaray", emoji: "🟡", description: "Cim Bom Bom" },
      { label: "Fenerbahçe", emoji: "🔵", description: "Sarı Kanaryalar" },
      { label: "Beşiktaş", emoji: "⚫", description: "Kara Kartal" },
      { label: "Trabzonspor", emoji: "🟤", description: "Bordo Mavililer" },
      { label: "Başakşehir", emoji: "🟠", description: "İstanbul Başakşehir" },
      { label: "Adana Demirspor", emoji: "🔷", description: "Mavi Şimşekler" },
      { label: "Samsunspor", emoji: "🔴", description: "Kırmızı Beyazlılar" },
      { label: "Antalyaspor", emoji: "❤️", description: "Akrepler" },
      { label: "Taraftarım Yok", emoji: "🏳️", description: "Taraf tutmuyorum" }
    ]
  }
};

module.exports = {
  name: "rolmenu",
  aliases: ["rolmenü", "rolemenu", "rmenu"],
  staffOnly: true,
  async execute(message, args, client) {
    const guild = message.guild;
    const mentionedRoles = message.mentions.roles;

    // A) ÖZEL EKLENMİŞ ROLLER İLE MENÜ OLUŞTURMA (.rolmenu @Rol1 @Rol2 veya .rolmenu [Başlık] @Rol1 @Rol2)
    if (mentionedRoles.size > 0) {
      const isMulti = args.some(arg => arg.toLowerCase() === "coklu" || arg.toLowerCase() === "multi");
      const titleArg = args.filter(a => !a.toLowerCase().includes("coklu") && !a.toLowerCase().includes("multi")).join(" ").replace(/<@&\d+>/g, "").trim();
      const menuTitle = titleArg || "🎭 Rol Seçim Menüsü";
      const rolesList = [...mentionedRoles.values()];

      const loadingMsg = await message.reply({
        embeds: [embedBuilder.info("⏳ Menü Hazırlanıyor...", "Etiketlenen roller menüye dönüştürülüyor...")]
      });

      try {
        const menuId = `selectmenu_role_custom_${Date.now()}`;
        const selectOptions = rolesList.slice(0, 25).map(role => ({
          label: role.name,
          value: role.id,
          description: `@${role.name} rolünü seçmek için tıklayın`,
          emoji: "🎭"
        }));

        const selectMenu = new StringSelectMenuBuilder()
          .setCustomId(menuId)
          .setPlaceholder(isMulti ? "Bir veya daha fazla rol seçin..." : "Bir rol seçin...")
          .setMinValues(0)
          .setMaxValues(isMulti ? selectOptions.length : 1)
          .addOptions(selectOptions);

        const row = new ActionRowBuilder().addComponents(selectMenu);

        const embed = new EmbedBuilder()
          .setTitle(menuTitle)
          .setDescription("Aşağıdaki açılır menüden dilediğiniz rolleri seçip alabilir veya bırakabilirsiniz.")
          .setColor("#6366f1")
          .setFooter({ text: `${rolesList.length} rol seçeneği • Tekrar seçerek rolü bırakabilirsiniz` })
          .setTimestamp();

        const sentMsg = await message.channel.send({ embeds: [embed], components: [row] });

        // Config'e kaydet
        const raw = client.config.raw;
        raw.roleMenus = raw.roleMenus || [];
        raw.roleMenus.push({
          menuId,
          templateName: "custom",
          messageId: sentMsg.id,
          channelId: message.channel.id,
          title: menuTitle,
          maxValues: selectOptions.length,
          roles: rolesList.map(r => ({
            roleId: r.id,
            label: r.name,
            emoji: "🎭"
          }))
        });
        client.config.save(raw);

        await loadingMsg.edit({
          embeds: [embedBuilder.success(
            "Rol Menüsü Oluşturuldu ✅",
            `**${menuTitle}** menüsü başarıyla gönderildi!\n` +
            `• **${rolesList.length}** adet etiketlenen rol eklendi.\n` +
            `• Üyeler menüden seçim yaparak rolleri alıp bırakabilir.`
          )]
        });

      } catch (err) {
        console.error("[ÖZEL ROL MENÜ HATASI]", err);
        await loadingMsg.edit({
          embeds: [embedBuilder.error("Hata", `Rol menüsü oluşturulurken hata: ${err.message}`)]
        });
      }
      return;
    }

    // B) HAZIR ŞABLON İLE OLUŞTURMA (.rolmenu burc / iliski / oyun / takim)
    const templateName = (args[0] || "").toLowerCase();

    if (!templateName || !TEMPLATES[templateName]) {
      const availableTemplates = Object.keys(TEMPLATES).map(k => {
        const t = TEMPLATES[k];
        return `• \`.rolmenu ${k}\` → ${t.title}`;
      }).join("\n");

      return message.reply({
        embeds: [embedBuilder.info(
          "Rol Menüsü Oluşturucu 📋",
          `**1) Hazır Şablonlar:**\n${availableTemplates}\n\n` +
          `**2) Kendi Seçtiğin Rollerle Oluşturma:**\n` +
          `• \`.rolmenu @Rol1 @Rol2 @Rol3\`\n` +
          `• \`.rolmenu "Oyun Rolleri" @Rol1 @Rol2 @Rol3\` (Başlıklı)\n\n` +
          `**Örnek:** \`.rolmenu burc\` veya \`.rolmenu @Kırmızı @Mavi @Yeşil\``
        )]
      });
    }

    const template = TEMPLATES[templateName];

    // Yükleniyor mesajı
    const loadingMsg = await message.reply({
      embeds: [embedBuilder.info("⏳ Roller Hazırlanıyor...", "Eksik roller oluşturuluyor ve menü hazırlanıyor...")]
    });

    try {
      // Roller varsa bul, yoksa oluştur
      const roleMap = new Map(); // label -> roleId

      for (const opt of template.options) {
        const roleName = opt.label;
        let existingRole = guild.roles.cache.find(r => r.name.toLowerCase() === roleName.toLowerCase());

        if (!existingRole) {
          // Rolü oluştur
          existingRole = await guild.roles.create({
            name: roleName,
            color: template.color,
            reason: `Rol Menüsü: ${template.title}`,
            mentionable: false,
            hoist: false
          });
          console.log(`[ROL MENÜ] "${roleName}" rolü oluşturuldu.`);
        }

        roleMap.set(roleName, existingRole.id);
      }

      // Select Menu oluştur
      const menuId = `selectmenu_role_${templateName}_${Date.now()}`;
      
      const selectOptions = template.options.map(opt => ({
        label: opt.label,
        value: roleMap.get(opt.label),
        description: opt.description || "",
        emoji: opt.emoji || undefined
      }));

      const selectMenu = new StringSelectMenuBuilder()
        .setCustomId(menuId)
        .setPlaceholder(template.placeholder || "Bir seçenek seç...")
        .setMinValues(0)
        .setMaxValues(template.maxValues || 1)
        .addOptions(selectOptions);

      const row = new ActionRowBuilder().addComponents(selectMenu);

      // Embed
      const embed = new EmbedBuilder()
        .setTitle(template.title)
        .setDescription(template.description)
        .setColor(template.color)
        .setFooter({ text: `${template.options.length} seçenek • Tekrar seçerek rolü bırakabilirsin` })
        .setTimestamp();

      // Gönder
      const sentMsg = await message.channel.send({ embeds: [embed], components: [row] });

      // Config'e kaydet
      const raw = client.config.raw;
      raw.roleMenus = raw.roleMenus || [];
      raw.roleMenus.push({
        menuId,
        templateName,
        messageId: sentMsg.id,
        channelId: message.channel.id,
        title: template.title,
        maxValues: template.maxValues || 1,
        roles: template.options.map(opt => ({
          roleId: roleMap.get(opt.label),
          label: opt.label,
          emoji: opt.emoji
        }))
      });
      client.config.save(raw);

      // Yükleniyor mesajını güncelle
      await loadingMsg.edit({
        embeds: [embedBuilder.success(
          "Rol Menüsü Oluşturuldu ✅",
          `**${template.title}** menüsü başarıyla gönderildi!\n` +
          `• **${roleMap.size}** rol hazırlandı\n` +
          `• Üyeler menüden seçim yaparak rolleri alıp bırakabilir.`
        )]
      });

    } catch (err) {
      console.error("[ROL MENÜ HATASI]", err);
      await loadingMsg.edit({
        embeds: [embedBuilder.error("Hata", `Rol menüsü oluşturulurken hata: ${err.message}`)]
      });
    }
  },
};
