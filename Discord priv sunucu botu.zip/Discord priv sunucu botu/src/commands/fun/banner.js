const { EmbedBuilder } = require("discord.js");

module.exports = {
  name: "banner",
  aliases: ["arkapalan"],
  async execute(message, args, client) {
    const user = message.mentions.users.first() || message.author;
    
    try {
      const fetchedUser = await client.users.fetch(user.id, { force: true });
      const bannerUrl = fetchedUser.bannerURL({ size: 1024, dynamic: true });

      if (!bannerUrl) {
        return message.reply("❌ Bu kullanıcının özel bir banner'ı bulunmuyor.");
      }

      const embed = new EmbedBuilder()
        .setColor(0x5865F2)
        .setTitle(`🖼️ ${user.username} Banner`)
        .setImage(bannerUrl)
        .setFooter({ text: "Priv Discord Bot" });

      message.reply({ embeds: [embed] });
    } catch (err) {
      message.reply("❌ Banner getirilirken bir sorun oluştu.");
    }
  },
};
