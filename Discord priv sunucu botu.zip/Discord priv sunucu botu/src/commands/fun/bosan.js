const { ActionRowBuilder, ButtonBuilder, ButtonStyle, ComponentType } = require("discord.js");
const db = require("../../database/db");
const embedBuilder = require("../../utils/embedBuilder");

module.exports = {
  name: "boşan",
  aliases: ["bosan", "divorce", "ayrıl"],
  async execute(message, args, client) {
    // 1. Evlilik kontrolü
    const marriageData = db.getMarriage(message.author.id);

    if (!marriageData) {
      return message.reply({
        embeds: [embedBuilder.error("Boşanma", "Zaten evli değilsiniz! Kimi boşayacaksınız? 😅")]
      });
    }

    // 2. Eş bilgisini al
    const partnerUser = await client.users.fetch(marriageData.partner).catch(() => null);
    const partnerName = partnerUser ? partnerUser.username : "Eşiniz";

    // 3. Onay Butonlarını Hazırla
    const confirmId = `divorce_confirm_${Date.now()}`;
    const cancelId = `divorce_cancel_${Date.now()}`;

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId(confirmId)
        .setLabel("Evet, Boşan")
        .setStyle(ButtonStyle.Danger)
        .setEmoji("💔"),
      new ButtonBuilder()
        .setCustomId(cancelId)
        .setLabel("Vazgeç")
        .setStyle(ButtonStyle.Secondary)
        .setEmoji("🛡️")
    );

    const confirmEmbed = embedBuilder.warn(
      "⚠️ Boşanma Onayı",
      `**${partnerName}** ile olan evliliğinizi bitirmek istediğinizden emin misiniz?\n\n*Bu işlem tek taraflıdır ve onayladığınız takdirde evliliğiniz sonlandırılacaktır.*`
    );

    const askMsg = await message.reply({
      embeds: [confirmEmbed],
      components: [row]
    }).catch(() => null);

    if (!askMsg) return;

    // 4. Buton Etkileşimi Dinleyicisi (Collector)
    const collector = askMsg.createMessageComponentCollector({
      componentType: ComponentType.Button,
      time: 30000 // 30 saniye
    });

    collector.on("collect", async (interaction) => {
      if (interaction.user.id !== message.author.id) {
        return interaction.reply({
          content: "❌ Bu onay işlemi yalnızca komutu kullanan kişiye aittir.",
          ephemeral: true
        });
      }

      if (interaction.customId === confirmId) {
        collector.stop("confirmed");

        // Veritabanından evliliği sil
        db.divorce(message.author.id);

        // Discord Log Kanalına Bildir
        try {
          const discordLogger = require("../../utils/discordLogger");
          discordLogger.logMarriageEvent(client, "divorce", message.author, partnerUser || { username: partnerName, tag: partnerName }).catch(() => {});
        } catch (e) {}

        const divorcedEmbed = embedBuilder.error(
          "💔 Boşanma Gerçekleşti",
          `**${message.author.username}** ve **${partnerName}** resmen boşandı.\nYollarınız ayrıldı, ikinize de hayatınızda başarılar dileriz.`
        );

        await interaction.update({
          embeds: [divorcedEmbed],
          components: []
        });

      } else if (interaction.customId === cancelId) {
        collector.stop("cancelled");

        const cancelEmbed = embedBuilder.info(
          "🕊️ Boşanma İptal Edildi",
          "Boşanma işleminden vazgeçildi. Evliliğiniz kaldığı yerden devam ediyor! ❤️"
        );

        await interaction.update({
          embeds: [cancelEmbed],
          components: []
        });
      }
    });

    collector.on("end", async (_, reason) => {
      if (reason === "time") {
        const timeoutEmbed = embedBuilder.warn(
          "⌛ Zaman Aşımı",
          "Boşanma onayı için süre doldu, işlem iptal edildi."
        );

        askMsg.edit({
          embeds: [timeoutEmbed],
          components: []
        }).catch(() => {});
      }
    });
  },
};
