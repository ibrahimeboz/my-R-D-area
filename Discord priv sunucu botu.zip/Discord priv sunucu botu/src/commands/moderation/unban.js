const embedBuilder = require("../../utils/embedBuilder");

module.exports = {
  name: "unban",
  aliases: ["yasakkaldir", "bankaldir", "pardon"],
  staffOnly: true,
  description: "Yasaklanmış bir kullanıcının banını kaldırır.",
  usage: ".unban [Kullanıcı ID] [Sebep]",
  async execute(message, args, client) {
    const userId = args[0];
    if (!userId || isNaN(userId)) {
      return message.reply({ embeds: [embedBuilder.error("Hatalı Kullanım", "Lütfen banı açılacak kullanıcının Discord ID'sini girin. Örn: `.unban 123456789012345678 [Sebep]`")] });
    }

    const reason = args.slice(1).join(" ") || "Yetkili tarafından banı açıldı";

    try {
      const ban = await message.guild.bans.fetch(userId).catch(() => null);
      if (!ban) {
        return message.reply({ embeds: [embedBuilder.error("Hata", "Bu ID'ye sahip yasaklanmış bir kullanıcı bulunamadı.")] });
      }

      await message.guild.members.unban(userId, `Unban: ${message.author.tag} - ${reason}`);

      const embed = embedBuilder.success(
        "Yasak Kaldırıldı (Unban) 🔓",
        `**Yasağı Açılan Kullanıcı:** ${ban.user.tag} (\`${userId}\`)\n` +
        `**Yetkili:** ${message.author}\n` +
        `**Sebep:** ${reason}`
      );

      message.reply({ embeds: [embed] });

      const logChannelId = client.config.moderation?.banLogChannel || client.config.moderation?.modLogChannel;
      if (logChannelId) {
        const logChannel = message.guild.channels.cache.get(logChannelId) || await message.guild.channels.fetch(logChannelId).catch(() => null);
        if (logChannel) logChannel.send({ embeds: [embed] }).catch(() => {});
      }
    } catch (err) {
      console.error("[UNBAN ERROR]", err);
      message.reply({ embeds: [embedBuilder.error("Hata", "Ban kaldırılırken bir hata oluştu.")] });
    }
  },
};
