const embedBuilder = require("../../utils/embedBuilder");
const db = require("../../database/db");

module.exports = {
  name: "sicil",
  aliases: ["penalties", "punishments"],
  staffOnly: true,
  async execute(message, args, client) {
    const member = message.mentions.members.first() || message.guild.members.cache.get(args[0]) || message.member;
    const punishments = db.getPunishments(member.id);
    const cezaPuan = db.getCezaPuan(member.id);

    if (punishments.length === 0) {
      return message.reply({ embeds: [embedBuilder.info("Ceza Sicili", `${member} kullanıcısının temiz bir sicili var. Hiç cezası bulunmuyor.`)] });
    }

    const list = punishments.slice(0, 10).map(p => 
      `**#${p.caseId} [${p.type}]** - <@${p.staff}> | **Sebep:** \`${p.reason}\` (${p.date})`
    ).join("\n");

    const embed = embedBuilder.info(
      `${member.user.username} Ceza Sicili (Toplam Puan: ${cezaPuan})`,
      list
    );

    message.reply({ embeds: [embed] });
  },
};
