const { PermissionFlagsBits } = require("discord.js");
const embedBuilder = require("../../utils/embedBuilder");

module.exports = {
  name: "lock",
  aliases: ["kilitle"],
  staffOnly: true,
  async execute(message, args, client) {
    const channel = message.mentions.channels.first() || message.channel;

    try {
      await channel.permissionOverwrites.edit(message.guild.roles.everyone, {
        SendMessages: false,
      });

      const embed = embedBuilder.success(
        "Kanal Kilitlendi 🔒",
        `${channel} kanalı başarıyla kilitlendi. Artık standart üyeler bu kanala mesaj gönderemez.`
      );

      message.reply({ embeds: [embed] });
    } catch (err) {
      console.error("[LOCK ERROR]", err);
      message.reply({ embeds: [embedBuilder.error("Hata", "Kanal kilitlenirken sorun oluştu.")] });
    }
  },
};
