const embedBuilder = require("../../utils/embedBuilder");
const permissionEngine = require("../../utils/permissionEngine");

module.exports = {
  name: "permsync",
  aliases: ["senkronize", "sync"],
  staffOnly: true,
  async execute(message, args, client) {
    const targetChannel = message.mentions.channels.first();

    if (!targetChannel || args[0] === "all" || args[0] === "hepsi") {
      // Tüm Sunucu İzinlerini Senkronize Et
      const loadingMsg = await message.reply({ 
        embeds: [embedBuilder.info("İzin Senkronizasyonu 🔄", "Tüm kategori ve kanalların izin şablonları sunucuya uygulanıyor. Lütfen bekleyin...")] 
      });

      try {
        const result = await permissionEngine.syncPermissions(message.guild, client);
        if (result.success) {
          await loadingMsg.edit({ 
            embeds: [embedBuilder.success("Senkronizasyon Tamamlandı ✅", `Tüm kategori ve kanal izinleri (${result.updatedCount} kanal/kategori) şablonlara göre başarıyla güncellendi!`)] 
          });
        } else {
          await loadingMsg.edit({ 
            embeds: [embedBuilder.error("Hata", result.error || "Senkronizasyon yapılamadı.")] 
          });
        }
      } catch (err) {
        console.error("[PERM SYNC ALL ERROR]", err);
        await loadingMsg.edit({ 
          embeds: [embedBuilder.error("Hata", "İzinler senkronize edilirken bir hata oluştu.")] 
        });
      }
      return;
    }

    // Tek Kanalı Kategoriyle Eşitle
    if (!targetChannel.parent) {
      return message.reply({ embeds: [embedBuilder.error("Hata", "Bu kanal herhangi bir kategoriye bağlı değil.")] });
    }

    try {
      await targetChannel.lockPermissions();

      const embed = embedBuilder.success(
        "Kanal Senkronize Edildi 🔄",
        `${targetChannel} kanalının izinleri üst kategorisi olan **${targetChannel.parent.name}** ile eşitlendi.`
      );

      message.reply({ embeds: [embed] });
    } catch (err) {
      console.error("[PERM SYNC ERROR]", err);
      message.reply({ embeds: [embedBuilder.error("Hata", "Kanal izinleri senkronize edilirken bir hata oluştu.")] });
    }
  },
};
