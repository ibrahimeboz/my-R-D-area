const embedBuilder = require("../../utils/embedBuilder");
const db = require("../../database/db");

module.exports = {
  name: "isimler",
  aliases: ["names", "history"],
  staffOnly: true,
  async execute(message, args, client) {
    const member = message.mentions.members.first() || message.guild.members.cache.get(args[0]) || message.member;
    const history = db.getNameHistory(member.id);

    if (history.length === 0) {
      return message.reply({ embeds: [embedBuilder.info("İsim Geçmişi", `${member} kullanıcısının geçmiş isim kaydı bulunamadı.`)] });
    }

    const formattedList = history.slice(0, 10).map((h, i) => 
      `**${i + 1}.** \`${h.name}\` (${h.role}) - <@${h.staff}> [${h.date}]`
    ).join("\n");

    const embed = embedBuilder.info(
      `${member.user.username} İsim Geçmişi (${history.length} Kayıt)`,
      formattedList
    );

    message.reply({ embeds: [embed] });
  },
};
