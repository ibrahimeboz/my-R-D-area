const { PermissionsBitField, ChannelType } = require("discord.js");
const db = require("../database/db");

let autoSyncInterval = null;

function buildChannelOverwrites(channelType, roles, guildId, P) {
  const r_unregistered = roles.unregistered || [];
  const r_member = roles.member || [];
  const r_vip = roles.vip || [];
  const r_punished = roles.punished || [];
  const r_staff = roles.staff || [];

  const newOverwrites = [];
  const setOverwrite = (roleIdArray, allowPerms, denyPerms) => {
    for (const rId of roleIdArray) {
      if (!rId) continue;
      newOverwrites.push({
        id: rId,
        allow: allowPerms,
        deny: denyPerms,
        type: 0 // 0 = Role
      });
    }
  };

  switch (channelType) {
    case 'chat':
      // Sohbet kanalı: Fotoğraf/dosya ve komutlar yasak (üyeler için), GIF ve Bağlantı Önizleme serbest
      setOverwrite(r_unregistered, [], [P.ViewChannel, P.ManageChannels]);
      setOverwrite(r_punished, [], [P.ViewChannel, P.SendMessages, P.Connect, P.ManageChannels]);
      setOverwrite([...r_member, ...r_vip], 
        [P.ViewChannel, P.SendMessages, P.ReadMessageHistory, P.Connect, P.Speak, P.Stream, P.UseVAD, P.EmbedLinks],
        [P.AttachFiles, P.UseApplicationCommands, P.ManageChannels]
      );
      setOverwrite(r_staff, [P.ViewChannel, P.SendMessages, P.AttachFiles, P.EmbedLinks, P.UseApplicationCommands, P.ManageMessages, P.Connect, P.Speak, P.Stream, P.UseVAD, P.MuteMembers, P.DeafenMembers], []);
      newOverwrites.push({ id: guildId, allow: [], deny: [P.ViewChannel, P.ManageChannels], type: 0 });
      break;

    case 'gallery':
    case 'media':
      // Galeri: Görseller ve medyalara izin verilir
      setOverwrite(r_unregistered, [], [P.ViewChannel, P.ManageChannels]);
      setOverwrite(r_punished, [], [P.ViewChannel, P.SendMessages, P.Connect, P.ManageChannels]);
      setOverwrite([...r_member, ...r_vip],
        [P.ViewChannel, P.SendMessages, P.ReadMessageHistory, P.AttachFiles, P.EmbedLinks, P.AddReactions],
        [P.ManageChannels]
      );
      setOverwrite(r_staff, [P.ViewChannel, P.SendMessages, P.AttachFiles, P.EmbedLinks, P.ManageMessages, P.AddReactions], []);
      newOverwrites.push({ id: guildId, allow: [], deny: [P.ViewChannel, P.ManageChannels], type: 0 });
      break;

    case 'commands':
    case 'bot-commands':
      // Komut kanalı: Komut kullanımı serbest ama FOTOĞRAF YASAK
      setOverwrite(r_unregistered, [], [P.ViewChannel, P.ManageChannels]);
      setOverwrite(r_punished, [], [P.ViewChannel, P.SendMessages, P.Connect, P.ManageChannels]);
      setOverwrite([...r_member, ...r_vip],
        [P.ViewChannel, P.SendMessages, P.ReadMessageHistory, P.UseApplicationCommands],
        [P.AttachFiles, P.EmbedLinks, P.ManageChannels]
      );
      setOverwrite(r_staff, [P.ViewChannel, P.SendMessages, P.UseApplicationCommands, P.AttachFiles, P.EmbedLinks, P.ManageMessages], []);
      newOverwrites.push({ id: guildId, allow: [], deny: [P.ViewChannel, P.ManageChannels], type: 0 });
      break;

    case 'announcement':
      // Duyuru kanalı: Üyeler mesaj yazamaz, sadece yetkililer yazabilir
      setOverwrite(r_unregistered, [], [P.ViewChannel, P.ManageChannels]);
      setOverwrite(r_punished, [], [P.ViewChannel, P.ManageChannels]);
      setOverwrite([...r_member, ...r_vip],
        [P.ViewChannel, P.ReadMessageHistory, P.AddReactions],
        [P.SendMessages, P.ManageChannels]
      );
      setOverwrite(r_staff, [P.ViewChannel, P.SendMessages, P.ReadMessageHistory, P.ManageMessages, P.AddReactions], []);
      newOverwrites.push({ id: guildId, allow: [], deny: [P.ViewChannel, P.ManageChannels], type: 0 });
      break;

    case 'no-media':
      // Görsel yasaklı kanal
      setOverwrite(r_unregistered, [], [P.ViewChannel, P.ManageChannels]);
      setOverwrite(r_punished, [], [P.ViewChannel, P.SendMessages, P.Connect, P.ManageChannels]);
      setOverwrite([...r_member, ...r_vip],
        [P.ViewChannel, P.SendMessages, P.ReadMessageHistory],
        [P.AttachFiles, P.EmbedLinks, P.ManageChannels]
      );
      setOverwrite(r_staff, [P.ViewChannel, P.SendMessages, P.AttachFiles, P.EmbedLinks, P.ManageMessages], []);
      newOverwrites.push({ id: guildId, allow: [], deny: [P.ViewChannel, P.ManageChannels], type: 0 });
      break;

    case 'no-commands':
      // Komut yasaklı kanal
      setOverwrite(r_unregistered, [], [P.ViewChannel, P.ManageChannels]);
      setOverwrite(r_punished, [], [P.ViewChannel, P.SendMessages, P.Connect, P.ManageChannels]);
      setOverwrite([...r_member, ...r_vip],
        [P.ViewChannel, P.SendMessages, P.ReadMessageHistory],
        [P.UseApplicationCommands, P.ManageChannels]
      );
      setOverwrite(r_staff, [P.ViewChannel, P.SendMessages, P.UseApplicationCommands, P.ManageMessages], []);
      newOverwrites.push({ id: guildId, allow: [], deny: [P.ViewChannel, P.ManageChannels], type: 0 });
      break;

    default:
      return null;
  }
  return newOverwrites;
}

/**
 * Kategori izinlerini (deny) koruyarak kanal izinleriyle birleştirir.
 * Jail kategorisi altındaki bir kanala özel tür atandığında, kategorinin
 * deny ettiği izinler (ViewChannel, SendMessages vb.) korunur.
 * Kanal türü sadece EK kısıtlamalar ekler, kategorideki deny'ları asla gevşetmez.
 */
function mergeWithCategoryDenies(channelOverwrites, categoryOverwrites) {
  if (!categoryOverwrites || !channelOverwrites) return channelOverwrites;

  // Kategori deny haritası: roleId -> Set<denyPerm>
  const catDenyMap = new Map();
  for (const catOw of categoryOverwrites) {
    if (catOw.deny && catOw.deny.length > 0) {
      catDenyMap.set(catOw.id, new Set(catOw.deny));
    }
  }

  if (catDenyMap.size === 0) return channelOverwrites;

  // Her kanal overwrite'ını kontrol et
  const merged = channelOverwrites.map(chOw => {
    const catDenies = catDenyMap.get(chOw.id);
    if (!catDenies) return chOw;

    // Kanal allow listesinden, kategorinin deny ettiği izinleri çıkar
    const newAllow = (chOw.allow || []).filter(perm => !catDenies.has(perm));
    // Kanal deny listesine, kategorinin deny ettiği izinleri ekle (benzersiz)
    const denySet = new Set([...(chOw.deny || []), ...catDenies]);

    return {
      ...chOw,
      allow: newAllow,
      deny: [...denySet]
    };
  });

  return merged;
}

async function syncPermissions(guild, client) {
  if (!guild) return { success: false, error: "Sunucu bulunamadı." };

  const currentConfig = client.config.permission || {};
  const categoryMappings = currentConfig.categoryMappings || [];
  const channelMappings = currentConfig.channelMappings || [];
  const roles = currentConfig.roleMappings || {};
  const overwriteMode = (currentConfig.autoSync && currentConfig.autoSync.overwriteMode) || 'merge';

  const r_unregistered = roles.unregistered || [];
  const r_member = roles.member || [];
  const r_vip = roles.vip || [];
  const r_punished = roles.punished || [];
  const r_staff = roles.staff || [];
  const P = PermissionsBitField.Flags;

  const processedChannelIds = new Set();
  // Kategori tiplerini saklayacak harita (categoryId -> categoryOverwrites)
  const categoryOverwritesMap = new Map();
  let updatedCount = 0;

  try {
    await guild.channels.fetch();
  } catch (e) {
    console.warn('[PERM ENGINE] Kanallar fetch edilirken uyarı:', e.message);
  }

  const applyOverwrites = async (targetChannel, customOverwrites = null) => {
    const overwritesToSet = customOverwrites || [];
    const currentOverwrites = targetChannel.permissionOverwrites.cache;
    if (overwriteMode === 'overwrite') {
      await targetChannel.permissionOverwrites.set(overwritesToSet);
    } else {
      const allRolesManagedByUs = [...r_unregistered, ...r_member, ...r_vip, ...r_punished, ...r_staff, guild.id];
      const merged = [];
      currentOverwrites.forEach(overwrite => {
        if (!allRolesManagedByUs.includes(overwrite.id)) {
          merged.push({
            id: overwrite.id,
            allow: overwrite.allow.bitfield,
            deny: overwrite.deny.bitfield,
            type: overwrite.type
          });
        }
      });
      merged.push(...overwritesToSet);
      await targetChannel.permissionOverwrites.set(merged);
    }
    updatedCount++;
  };

  // 1. Kategoriler ve Alt Kanalları Senkronize Et
  for (const mapping of categoryMappings) {
    const categoryId = mapping.id;
    const type = mapping.type;
    if (!categoryId) continue;

    try {
      const categoryChannel = await guild.channels.fetch(categoryId).catch(() => null);
      if (!categoryChannel) continue;

      const categoryOverwrites = [];
      const setCatOverwrite = (roleIdArray, allowPerms, denyPerms) => {
        for (const rId of roleIdArray) {
          if (!rId) continue;
          categoryOverwrites.push({
            id: rId,
            allow: allowPerms,
            deny: denyPerms,
            type: 0 // 0 = Role
          });
        }
      };

      switch (type) {
        case 'register':
          setCatOverwrite(r_unregistered, [P.ViewChannel, P.SendMessages, P.ReadMessageHistory, P.Connect, P.Speak, P.Stream, P.UseVAD], [P.ManageChannels]);
          setCatOverwrite([...r_member, ...r_vip, ...r_punished], [], [P.ViewChannel, P.ManageChannels]);
          setCatOverwrite(r_staff, [P.ViewChannel, P.SendMessages, P.Connect, P.Speak, P.Stream, P.UseVAD], []);
          categoryOverwrites.push({ id: guild.id, allow: [], deny: [P.ViewChannel, P.ManageChannels], type: 0 });
          break;

        case 'public':
          setCatOverwrite(r_unregistered, [], [P.ViewChannel, P.ManageChannels]);
          setCatOverwrite(r_punished, [], [P.ViewChannel, P.SendMessages, P.Connect, P.ManageChannels]);
          setCatOverwrite([...r_member, ...r_vip], [P.ViewChannel, P.SendMessages, P.ReadMessageHistory, P.Connect, P.Speak, P.Stream, P.UseVAD], [P.ManageChannels]);
          setCatOverwrite(r_staff, [P.ViewChannel, P.SendMessages, P.ManageMessages, P.Connect, P.Speak, P.Stream, P.UseVAD, P.MuteMembers, P.DeafenMembers], []);
          categoryOverwrites.push({ id: guild.id, allow: [], deny: [P.ViewChannel, P.ManageChannels], type: 0 });
          break;

        case 'vip':
          setCatOverwrite([...r_unregistered, ...r_member, ...r_punished], [], [P.ViewChannel, P.ManageChannels]);
          setCatOverwrite(r_vip, [P.ViewChannel, P.SendMessages, P.Connect, P.Speak, P.Stream, P.UseVAD], [P.ManageChannels]);
          setCatOverwrite(r_staff, [P.ViewChannel, P.SendMessages, P.Connect, P.Speak, P.Stream, P.UseVAD], []);
          categoryOverwrites.push({ id: guild.id, allow: [], deny: [P.ViewChannel, P.ManageChannels], type: 0 });
          break;

        case 'staff':
          setCatOverwrite([...r_unregistered, ...r_member, ...r_vip, ...r_punished], [], [P.ViewChannel, P.ManageChannels]);
          setCatOverwrite(r_staff, [P.ViewChannel, P.SendMessages, P.ReadMessageHistory, P.Connect, P.Speak, P.Stream, P.UseVAD, P.MuteMembers], []);
          categoryOverwrites.push({ id: guild.id, allow: [], deny: [P.ViewChannel, P.ManageChannels], type: 0 });
          break;

        case 'jail':
          setCatOverwrite([...r_unregistered, ...r_member, ...r_vip], [], [P.ViewChannel, P.ManageChannels]);
          setCatOverwrite(r_punished, [P.ViewChannel, P.ReadMessageHistory], [P.SendMessages, P.Connect, P.Speak, P.ManageChannels]);
          setCatOverwrite(r_staff, [P.ViewChannel, P.SendMessages, P.Connect, P.Speak, P.Stream], []);
          categoryOverwrites.push({ id: guild.id, allow: [], deny: [P.ViewChannel, P.ManageChannels], type: 0 });
          break;

        case 'log':
          setCatOverwrite([...r_unregistered, ...r_member, ...r_vip, ...r_punished], [], [P.ViewChannel, P.ManageChannels]);
          setCatOverwrite(r_staff, [P.ViewChannel, P.ReadMessageHistory], [P.SendMessages]);
          categoryOverwrites.push({ id: guild.id, allow: [], deny: [P.ViewChannel, P.ManageChannels], type: 0 });
          break;
      }

      // Kategori overwrite'larını haritaya kaydet (çocuk kanallar için)
      categoryOverwritesMap.set(categoryId, categoryOverwrites);

      await applyOverwrites(categoryChannel, categoryOverwrites);
      processedChannelIds.add(categoryChannel.id);

      if (categoryChannel.type === ChannelType.GuildCategory) {
        const children = categoryChannel.children ? categoryChannel.children.cache : null;
        if (children) {
          for (const [id, child] of children) {
            try {
              const childMapping = channelMappings.find(cm => cm.id === child.id);
              if (childMapping) {
                const specificOverwrites = buildChannelOverwrites(childMapping.type, roles, guild.id, P);
                if (specificOverwrites) {
                  // ÇAKIŞMA ÇÖZÜMÜ: Kanal şablonunu kategori deny'larıyla birleştir
                  // Kategorinin deny ettiği izinler korunur, kanal türü sadece ek kısıtlama ekler
                  const mergedOverwrites = mergeWithCategoryDenies(specificOverwrites, categoryOverwrites);
                  await applyOverwrites(child, mergedOverwrites);
                } else {
                  await applyOverwrites(child, categoryOverwrites);
                }
              } else {
                await applyOverwrites(child, categoryOverwrites);
              }
              processedChannelIds.add(child.id);
            } catch (e) {
              console.error(`[PERM ENGINE] Alt kanal (${child.name}) hatası:`, e.message);
            }
          }
        }
      }
    } catch (e) {
      console.error(`[PERM ENGINE] Kategori (${categoryId}) hatası:`, e.message);
    }
  }

  // 2. Bağımsız Özel Kanal Tanımlamalarını Senkronize Et
  for (const cMapping of channelMappings) {
    if (processedChannelIds.has(cMapping.id)) continue;
    try {
      const ch = await guild.channels.fetch(cMapping.id).catch(() => null);
      if (!ch) continue;

      const chOverwrites = buildChannelOverwrites(cMapping.type, roles, guild.id, P);
      if (chOverwrites) {
        // Eğer kanal bir kategorinin altındaysa ve o kategorinin izinleri kayıtlıysa
        // çakışma çözümü uygula
        if (ch.parentId && categoryOverwritesMap.has(ch.parentId)) {
          const parentOverwrites = categoryOverwritesMap.get(ch.parentId);
          const mergedOverwrites = mergeWithCategoryDenies(chOverwrites, parentOverwrites);
          await applyOverwrites(ch, mergedOverwrites);
        } else {
          await applyOverwrites(ch, chOverwrites);
        }
      }
    } catch (e) {
      console.error(`[PERM ENGINE] Kanal (${cMapping.id}) hatası:`, e.message);
    }
  }

  return { success: true, updatedCount };
}

function startAutoSync(client) {
  if (autoSyncInterval) {
    clearInterval(autoSyncInterval);
    autoSyncInterval = null;
  }

  const permConfig = client.config.permission || {};
  const autoSync = permConfig.autoSync || {};

  if (autoSync.enabled && autoSync.intervalHours > 0) {
    const ms = autoSync.intervalHours * 3600000;
    console.log(`[PERM ENGINE] AutoSync aktif. Her ${autoSync.intervalHours} saatte bir otomatik senkronize edilecek.`);
    
    autoSyncInterval = setInterval(async () => {
      const guild = client.guilds.cache.get(client.config.guildId) || client.guilds.cache.first();
      if (guild) {
        console.log("[PERM ENGINE] Otomatik izin senkronizasyonu çalıştırılıyor...");
        await syncPermissions(guild, client);
      }
    }, ms);
  }
}

module.exports = {
  buildChannelOverwrites,
  mergeWithCategoryDenies,
  syncPermissions,
  startAutoSync
};
