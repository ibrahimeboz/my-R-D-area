const db = require("../database/db");
const embedBuilder = require("./embedBuilder");

module.exports = {
  /**
   * İzinsiz eylem yapan üyenin tüm rollerini alıp karantinaya (veya rolsüz bırakmaya) çeker.
   */
  async neutralizeMember(guild, member, reason = "Guard: İzinsiz eylem tespiti") {
    if (!member || !member.manageable) return;

    try {
      // Üyenin yönetici yetkili rollerini temizle
      const rolesToRemove = member.roles.cache.filter(role => 
        role.id !== guild.id && 
        (role.permissions.has("Administrator") ||
         role.permissions.has("ManageChannels") ||
         role.permissions.has("ManageRoles") ||
         role.permissions.has("BanMembers") ||
         role.permissions.has("KickMembers") ||
         role.permissions.has("ManageGuild"))
      );

      if (rolesToRemove.size > 0) {
        await member.roles.remove(rolesToRemove, reason);
      }
    } catch (err) {
      console.error(`[GUARD ERROR] ${member.user.tag} yetkileri alınırken hata oluştu:`, err);
    }
  },

  /**
   * Guard Log kanalına bildirim gönderir.
   */
  async sendGuardLog(guild, config, embed) {
    const logChannelId = config.guard?.logChannel;
    if (!logChannelId || logChannelId.includes("KANAL_ID")) return;

    const channel = guild.channels.cache.get(logChannelId);
    if (channel) {
      channel.send({ embeds: [embed] }).catch(() => {});
    }
  },

  /**
   * Audit Log'dan son eylemi yapan kişiyi yakalar.
   */
  async getAuditExecutor(guild, auditType) {
    try {
      const logs = await guild.fetchAuditLogs({ limit: 1, type: auditType });
      const entry = logs.entries.first();
      if (!entry) return null;

      // Son 5 saniye içindeki eylemler geçerlidir
      if (Date.now() - entry.createdTimestamp > 5000) return null;

      return entry.executor;
    } catch (err) {
      return null;
    }
  }
};
