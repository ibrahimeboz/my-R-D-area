const embedBuilder = require("./embedBuilder");
const db = require("../database/db");

class PunishmentManager {
  /**
   * Üyeyi Jail'e atar, eski rollerini yedekler ve jail rolünü verir.
   */
  static async jailMember(guild, member, staff, reason, durationMs = null) {
    const jailRoleId = guild.client.config.moderation?.jailRole;
    if (!jailRoleId || jailRoleId.includes("ROL_ID")) {
      throw new Error("Jail rolü ayarlarda tanımlanmamış.");
    }

    // 1. Üyenin managed ve @everyone olmayan tüm rollerini yedekle
    const rolesToBackup = member.roles.cache
      .filter(r => r.id !== guild.id && !r.managed)
      .map(r => r.id);

    db.raw.set(`jail_backup_roles_${member.id}`, rolesToBackup);

    // 2. Managed rolleri koruyarak sadece Jail rolünü ver
    const managedRoles = member.roles.cache.filter(r => r.managed).map(r => r.id);
    const newRoles = [...managedRoles, jailRoleId];

    await member.roles.set(newRoles, `Jail: ${staff?.tag || staff?.username || "Yetkili"} - ${reason}`);

    // 3. Süreli ceza ise kaydet
    if (durationMs && durationMs > 0) {
      const expiresAt = Date.now() + durationMs;
      db.raw.set(`temp_jail_${member.id}`, {
        guildId: guild.id,
        userId: member.id,
        expiresAt,
        staffId: staff?.id || null,
        reason
      });
    }

    // 4. Sicil kaydı
    const caseId = db.addPunishment(member.id, staff?.id || guild.client.user.id, "JAIL", reason, durationMs ? `${Math.round(durationMs / 60000)}m` : null);
    return { caseId, rolesCount: rolesToBackup.length };
  }

  /**
   * Üyenin Jail cezasını kaldırır ve yedeklenen tüm eski rollerini geri yükler.
   */
  static async unjailMember(guild, member, staff = null, reason = "Ceza süresi bitti / Af edildi") {
    const jailRoleId = guild.client.config.moderation?.jailRole;

    // 1. Yedeklenen eski rolleri çek
    const backupRoles = db.raw.get(`jail_backup_roles_${member.id}`) || [];
    const managedRoles = member.roles.cache.filter(r => r.managed).map(r => r.id);

    if (Array.isArray(backupRoles) && backupRoles.length > 0) {
      // Sunucuda hala mevcut olan ve jail rolü olmayan rolleri filtrele
      const validRoles = backupRoles.filter(roleId => 
        roleId !== jailRoleId && 
        guild.roles.cache.has(roleId)
      );

      const targetRoles = [...managedRoles, ...validRoles];
      await member.roles.set(targetRoles, `Unjail: ${staff?.tag || "Sistem"} - ${reason}`).catch(err => {
        console.error(`[UNJAIL ROLES.SET HATASI] ${member.id}:`, err.message);
      });
    } else {
      // Yedek bulunamadıysa sadece jail rolünü çıkar ve varsayılan üye rolünü ver
      if (jailRoleId && member.roles.cache.has(jailRoleId)) {
        await member.roles.remove(jailRoleId, `Unjail: ${reason}`).catch(() => {});
      }

      const defaultMemberRoles = (guild.client.config.register?.memberRoles || []).filter(rId => rId && !rId.includes("ROL_ID"));
      if (defaultMemberRoles.length > 0) {
        await member.roles.add(defaultMemberRoles).catch(() => {});
      }
    }

    // Veritabanı temizliği
    db.raw.delete(`jail_backup_roles_${member.id}`);
    db.raw.delete(`temp_jail_${member.id}`);

    // Log bildirimi
    const logChannelId = guild.client.config.moderation?.jailLogChannel || guild.client.config.moderation?.modLogChannel;
    if (logChannelId) {
      const logChannel = guild.channels.cache.get(logChannelId) || await guild.channels.fetch(logChannelId).catch(() => null);
      if (logChannel) {
        const embed = embedBuilder.success(
          "Jail Cezası Kaldırıldı 🎉",
          `• **Üye:** ${member} (\`${member.id}\`)\n` +
          `• **Yetkili:** ${staff ? staff : "⏱️ Süre Bitimi (Otomatik)"}\n` +
          `• **Sebep:** ${reason}\n\n` +
          `✅ Kullanıcının ceza almadan önceki tüm eski rolleri başarıyla iade edildi.`
        );
        logChannel.send({ embeds: [embed] }).catch(() => {});
      }
    }

    return true;
  }

  /**
   * Süresi dolan cezaları periyodik olarak kontrol eder ve kaldırır.
   */
  static startInterval(client) {
    setInterval(async () => {
      try {
        const allData = db.raw.all ? db.raw.all() : [];
        const now = Date.now();

        // croxydb all format: { data: ..., key: ... } veya obje
        const tempJailKeys = Array.isArray(allData) 
          ? allData.filter(item => item.ID && item.ID.startsWith("temp_jail_"))
          : Object.keys(allData).filter(k => k.startsWith("temp_jail_")).map(k => ({ ID: k, data: allData[k] }));

        for (const item of tempJailKeys) {
          const jailData = item.data || db.raw.get(item.ID);
          if (jailData && jailData.expiresAt && now >= jailData.expiresAt) {
            const guild = client.guilds.cache.get(jailData.guildId);
            if (guild) {
              const member = guild.members.cache.get(jailData.userId) || await guild.members.fetch(jailData.userId).catch(() => null);
              if (member) {
                await this.unjailMember(guild, member, null, "Jail ceza süresi doldu");
                console.log(`[OTOMATİK UNJAIL] ${member.user.tag} ceza süresi bittiği için eski rolleri iade edildi.`);
              } else {
                db.raw.delete(item.ID);
              }
            }
          }
        }
      } catch (err) {
        console.error("[PUNISHMENT INTERVAL ERROR]", err.message);
      }
    }, 15000); // 15 saniyede bir kontrol et
  }
}

module.exports = PunishmentManager;
