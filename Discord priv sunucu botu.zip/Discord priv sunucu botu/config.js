const fs = require("fs");
const path = require("path");
require("dotenv").config();

const SETTINGS_PATH = path.join(__dirname, "settings.json");
const ENV_PATH = path.join(__dirname, ".env");

// Varsayılan Ayar Şablonu
const defaultSettings = {
  bot: {
    token: (process.env.BOT_TOKEN && !process.env.BOT_TOKEN.includes("YOUR_")) ? process.env.BOT_TOKEN : "",
    prefix: process.env.PREFIX || ".",
    guildId: (process.env.GUILD_ID && !process.env.GUILD_ID.includes("YOUR_")) ? process.env.GUILD_ID : "",
    botOwners: [],
    autoStart: true,
    proxy: process.env.PROXY || ""
  },
  register: {
    welcomeChannel: "",
    logChannel: "",
    manRoles: [],
    womanRoles: [],
    memberRoles: [],
    unregisteredRoles: [],
    staffRoles: [],
    suspectRole: "",
    tag: "•",
    untag: "",
    autoNameFormat: "{tag} {name} | {age}",
    buttonRegisterEnabled: true,
    card: {
      bgColor1: "#10b981",
      titleText: "Hoş Geldin!",
      subtitleText: "Sunucumuza katıldığın için teşekkürler!"
    },
    buttons: {
      maleLabel: "Erkek",
      maleEmoji: "👨",
      femaleLabel: "Kadın",
      femaleEmoji: "👩"
    }
  },
  moderation: {
    jailRole: "",
    chatMuteRole: "",
    voiceMuteRole: "",
    staffRoles: [],
    jailLogChannel: "",
    banLogChannel: "",
    muteLogChannel: "",
    warnLogChannel: "",
    modLogChannel: ""
  },
  staff: {
    staffRoles: [],
    staffLeaderRole: ""
  },
  guard: {
    enabled: true,
    channelGuard: true,
    roleGuard: true,
    botGuard: true,
    webhookGuard: true,
    permGuard: true,
    logChannel: "",
    whitelist: {
      users: [],
      roles: [],
      bots: []
    }
  },
  permission: {
    authorizedRoles: [],
    categoryMappings: [],
    channelMappings: [],
    roleMappings: {
      unregistered: [],
      member: [],
      vip: [],
      punished: [],
      staff: []
    },
    lock: {
      scope: ["text", "voice"],
      exemptRoles: []
    },
    channelGuard: {
      mediaGuard: true,
      commandGuard: true
    },
    autoSync: {
      enabled: false,
      intervalHours: 6,
      overwriteMode: "merge"
    }
  },
  buttonRoles: [],
  roleMenus: []
};

// Derin Nesne Birleştirme Yardımcısı (Deep Merge)
function isObject(item) {
  return (item && typeof item === "object" && !Array.isArray(item));
}

function deepMerge(target, source) {
  const output = Object.assign({}, target);
  if (isObject(target) && isObject(source)) {
    Object.keys(source).forEach(key => {
      if (isObject(source[key])) {
        if (!(key in target)) {
          Object.assign(output, { [key]: source[key] });
        } else {
          output[key] = deepMerge(target[key], source[key]);
        }
      } else {
        Object.assign(output, { [key]: source[key] });
      }
    });
  }
  return output;
}

// Ayarları Dosyadan Yükle (Disk -> Bellek)
function loadSettings() {
  try {
    if (fs.existsSync(SETTINGS_PATH)) {
      const data = fs.readFileSync(SETTINGS_PATH, "utf8");
      if (data && data.trim().length > 0) {
        const parsed = JSON.parse(data);
        return deepMerge(defaultSettings, parsed);
      }
    }
  } catch (err) {
    console.error("[SETTINGS YÜKLEME HATASI]", err);
  }

  // Dosya yoksa veya bozuksa varsayılanı diske yaz
  const fallback = JSON.parse(JSON.stringify(defaultSettings));
  try {
    fs.writeFileSync(SETTINGS_PATH, JSON.stringify(fallback, null, 2), "utf8");
  } catch (e) {}
  return fallback;
}

// Ayarları Dosyaya Kaydet & .env ile Senkronize Et (Bellek -> Disk)
function saveSettings(settingsToSave) {
  try {
    fs.writeFileSync(SETTINGS_PATH, JSON.stringify(settingsToSave, null, 2), "utf8");
    
    // .env dosyasını güncelle
    if (settingsToSave.bot) {
      const lines = [];
      if (settingsToSave.bot.token) lines.push(`BOT_TOKEN=${settingsToSave.bot.token}`);
      if (settingsToSave.bot.prefix) lines.push(`PREFIX=${settingsToSave.bot.prefix}`);
      if (settingsToSave.bot.guildId) lines.push(`GUILD_ID=${settingsToSave.bot.guildId}`);
      fs.writeFileSync(ENV_PATH, lines.join("\n") + "\n", "utf8");
    }
    return true;
  } catch (err) {
    console.error("[SETTINGS KAYDETME HATASI]", err);
    return false;
  }
}

// Canlı Ayar Nesnesi
let activeSettings = loadSettings();

const config = {
  get raw() {
    activeSettings = loadSettings(); // Her zaman diskteki en güncel hali döndür
    return activeSettings;
  },
  get token() {
    const raw = this.raw;
    return raw.bot?.token || process.env.BOT_TOKEN || "";
  },
  set token(val) {
    const raw = this.raw;
    raw.bot = raw.bot || {};
    raw.bot.token = val;
    this.save(raw);
  },
  get prefix() {
    const raw = this.raw;
    return raw.bot?.prefix || process.env.PREFIX || ".";
  },
  set prefix(val) {
    const raw = this.raw;
    raw.bot = raw.bot || {};
    raw.bot.prefix = val;
    this.save(raw);
  },
  get guildId() {
    const raw = this.raw;
    return raw.bot?.guildId || process.env.GUILD_ID || "";
  },
  set guildId(val) {
    const raw = this.raw;
    raw.bot = raw.bot || {};
    raw.bot.guildId = val;
    this.save(raw);
  },
  get botOwners() {
    const raw = this.raw;
    return raw.bot?.botOwners || [];
  },
  set botOwners(val) {
    const raw = this.raw;
    raw.bot = raw.bot || {};
    raw.bot.botOwners = Array.isArray(val) ? val : [val];
    this.save(raw);
  },
  get autoStart() {
    const raw = this.raw;
    return raw.bot?.autoStart !== false;
  },
  set autoStart(val) {
    const raw = this.raw;
    raw.bot = raw.bot || {};
    raw.bot.autoStart = Boolean(val);
    this.save(raw);
  },
  get proxy() {
    const raw = this.raw;
    return raw.bot?.proxy || process.env.PROXY || "";
  },
  set proxy(val) {
    const raw = this.raw;
    raw.bot = raw.bot || {};
    raw.bot.proxy = String(val).trim();
    this.save(raw);
  },
  get register() {
    return this.raw.register;
  },
  set register(val) {
    const raw = this.raw;
    raw.register = val;
    this.save(raw);
  },
  get moderation() {
    return this.raw.moderation;
  },
  set moderation(val) {
    const raw = this.raw;
    raw.moderation = val;
    this.save(raw);
  },
  get staff() {
    return this.raw.staff;
  },
  set staff(val) {
    const raw = this.raw;
    raw.staff = val;
    this.save(raw);
  },
  get guard() {
    return this.raw.guard;
  },
  set guard(val) {
    const raw = this.raw;
    raw.guard = val;
    this.save(raw);
  },
  get permission() {
    return this.raw.permission;
  },
  set permission(val) {
    const raw = this.raw;
    raw.permission = val;
    this.save(raw);
  },
  
  reload() {
    activeSettings = loadSettings();
    return activeSettings;
  },
  save(fullObj) {
    if (fullObj) {
      activeSettings = deepMerge(loadSettings(), fullObj);
    }
    const success = saveSettings(activeSettings);
    return success;
  }
};

module.exports = config;
