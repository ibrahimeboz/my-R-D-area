const BotClient = require("./src/client/BotClient");
const config = require("./config");

// Bot istemcisini başlat
const client = new BotClient(config);

// Yakalanmamış Hataları Engelleme (Botun Çökmesini Önler)
process.on("unhandledRejection", (reason, promise) => {
  console.error("[UNHANDLED REJECTION] Yakalanmamış Söz Hatası:", reason);
});

process.on("uncaughtException", (err, origin) => {
  console.error("[UNCAUGHT EXCEPTION] Yakalanmamış Özel Hata:", err);
});

client.start().catch((err) => {
  console.error("[BOT BAŞLATMA HATASI]", err);
});
